//
// md4ish.cxx
//
// an attempt to centralize the commonality of MD4 like chain hash
// functions
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#include <assert.h>
#include <string.h>
#include "md4ish.hpp"
#include "chmisc.hpp"

MD4ish::MD4ish(const int bitsInHash) : ChainHash(512,bitsInHash)
{
}
 
MD4ish::~MD4ish()
{
}

void MD4ish::ProcessFinalBlock(const void* block, const int bytes)
{
  assert ( bytes>=0 && bytes<=64);
  _bitCount+=(bytes*8);

  int zeroBytesInPad=( bytes<= 55 ) ? 55-bytes: 119-bytes;
  int numBytes=(bytes+9+zeroBytesInPad);

  if ( numBytes==128 )
    {
      u32 bigBuf[32];
      u8* curByte=(u8*) bigBuf;

      memcpy(curByte,block,bytes); curByte+=bytes;
      *(curByte++)=0x80;
      memset(curByte,0,zeroBytesInPad); curByte+=zeroBytesInPad;

      memcpy(curByte,&_bitCount,8); // curByte+=8;

      ProcessBlock(bigBuf);
      ProcessBlock(bigBuf+16);
    }
  else //  numBytes==64 
    {
      u8* curByte=(u8*) buf;

      memcpy(curByte,block,bytes); curByte+=bytes;
      *(curByte++)=0x80;
      memset(curByte,0,zeroBytesInPad); curByte+=zeroBytesInPad;

      memcpy(curByte,&_bitCount,8); // curByte+=8;

      ProcessBlock(buf);
    }
}


/*
void MD4ish::ProcessMiddleBlock(const void* block, const int aligned)
{
  if ( aligned )
    ProcessBlock((const u32*) block);
  else
    {
      memcpy(buf,block,64);
      ProcessBlock(buf);
    }
  _bitCount+=512;
}
*/

void MD4ish::Reset()
{
  ChainHash::Reset();
}

void MD4ish::ChainVariables(void* buffer) const
{
  memcpy(buffer,H,_bitsInHash/8);
}
