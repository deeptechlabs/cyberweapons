//
// sha0g.hpp
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#ifndef _SHA0G_HPP
#define _SHA0G_HPP

#include "shag.hpp"

class SHA0AsmGenerator : public SHAAsmGenerator
{
public:
  SHA0AsmGenerator(ostream& os);
};

#endif
