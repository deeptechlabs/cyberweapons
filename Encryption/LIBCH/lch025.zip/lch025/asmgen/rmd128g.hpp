//
// rmd128g.hpp
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#ifndef _RMD128G_HPP
#define _RMD128G_HPP

#include "asmgen.hpp"

class RMD128AsmGenerator : public AsmGenerator
{
public:
  static const u32 KL[64];
  static const int rl[64];
  static const int sl[64];

  static const u32 KR[64];
  static const int rr[64];
  static const int sr[64];

  RMD128AsmGenerator(ostream& os);
  ~RMD128AsmGenerator() {}

  void PrintLeftRound1();
  void PrintLeftRound2();
  void PrintLeftRound3();
  void PrintLeftRound4();
  
  void PrintReload();
  void PrintSaveLeftResult();

  void PrintRightRound1();
  void PrintRightRound2();
  void PrintRightRound3();
  void PrintRightRound4();

  void PrintCombineHalves();

  void Startup();
  void Body();
  void Cleanup();
};

#endif
