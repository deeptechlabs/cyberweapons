//
// gencast.cpp
//
// Copyright (C) 1997 by Leonard Janke (janke@unixg.ubc.ca)

#include <stdlib.h>
#include <iostream.h>
#include <iomanip.h>
#include <string.h>
#include "cast128e.hpp"
#include "cast128d.hpp"
#include "cbcenc.hpp"
#include "cbcdec.hpp"

const char* encryptECBFunctionName="castEncrypt";
const char* decryptECBFunctionName="castDecrypt";
const char* encryptCBCFunctionName="castEncryptCBC";
const char* decryptCBCFunctionName="castDecryptCBC";
const char* programName="gencast";

enum eModeEnum { ECB, CBC };
enum inlCallConvEnum { cdcl, fstcall };

void INLFileBegin(ostream& os)
{
  os <<"#include \"cast128.h\""<<endl;
  os <<endl;
}

void INLFileEnd(ostream& os)
{
}

void INLFunctionBegin(ostream& os, const char* functionName,
                      eModeEnum eMode,  
                      inlCallConvEnum callingConvention)
{
  os <<"void __declspec(naked) ";

  switch ( callingConvention )
  {
  case cdcl:
    os <<"__cdecl ";
    break;
  case fstcall:
    os <<"__fastcall ";
    break;
  defautl:
    cerr <<"Unrecognized calling convention"<<endl;
    exit(-1);
  }

  os <<functionName;

  switch ( eMode )
  {
  case ECB:
    os <<"(LONG* K, BYTE* data)"<<endl;
    break;
  case CBC:
    os <<"(BYTE* in, BYTE* out, int noByte, LONG* KEY, BYTE* iv)"<<endl;
    break;
  default:
    cerr <<"Unrecognized encryption mode"<<endl;
    exit(-1);
  }

  os <<"{"<<endl;
  os <<"  __asm{"<<endl;
}

void INLFunctionEnd(ostream& os)
{
  os <<"  }"<<endl;
  os <<"}"<<endl;
}

void INLEncryptECBFastcallFunctionBegin(ostream& os)
{
  INLFunctionBegin(os,encryptECBFunctionName,ECB,fstcall);
}

void INLEncryptECBCDeclFunctionBegin(ostream& os)
{
  INLFunctionBegin(os,encryptECBFunctionName,ECB,cdcl);
}

void INLDecryptECBFastcallFunctionBegin(ostream& os)
{
  INLFunctionBegin(os,decryptECBFunctionName,ECB,fstcall);
}

void INLDecryptECBCDeclFunctionBegin(ostream& os)
{
  INLFunctionBegin(os,decryptECBFunctionName,ECB,cdcl);
}

void INLEncryptCBCFastcallFunctionBegin(ostream& os)
{
  INLFunctionBegin(os,encryptCBCFunctionName,CBC,fstcall);
}

void INLEncryptCBCCDeclFunctionBegin(ostream& os)
{
  INLFunctionBegin(os,decryptCBCFunctionName,CBC,cdcl);
}

void INLDecryptCBCFastcallFunctionBegin(ostream& os)
{
  INLFunctionBegin(os,decryptCBCFunctionName,CBC,fstcall);
}

void INLDecryptCBCCDeclFunctionBegin(ostream& os)
{
  INLFunctionBegin(os,decryptCBCFunctionName,CBC,cdcl);
}

void Usage(ostream& os)
{
  os <<"usage: "<<programName<<" (assembly format)"<<endl;
  os <<endl;
  os <<"Where (assembly format) is one of:"<<endl;
  os <<endl;
  os <<"nasm-elf, nasm-aout, nasm-coff, nasm-win32,"<<endl;
  os <<"att-elf, att-aout,  att-coff, att-win32, att-cpp,"<<endl;
  os <<"wasm-register, wasm-cdecl,"<<endl;
  os <<"masm-inl-fastcall, masm-inl-cdecl,"<<endl;
}

int main(int argc, char* argv[])
{
  enum asmFormatEnum { nasm_elf, nasm_aout, nasm_coff, nasm_win32,
                       att_elf, att_aout, att_coff, att_win32, att_cpp,
                       wasm_register, wasm_cdecl,
                       masm_inl_fastcall, masm_inl_cdecl };
  asmFormatEnum asmFormat;
  int masmINL=0;

  if ( argc != 2 )
    {
      Usage(cerr);
      return(1); 
    }

  CAST128EncryptAsmGenerator genEncryptECB(cout);
  CAST128DecryptAsmGenerator genDecryptECB(cout);
  CAST128CBCEncryptAsmGenerator genEncryptCBC(cout);
  CAST128CBCDecryptAsmGenerator genDecryptCBC(cout);

  genEncryptECB.SetCFunctionName(encryptECBFunctionName);
  genDecryptECB.SetCFunctionName(decryptECBFunctionName);
  genEncryptCBC.SetCFunctionName(encryptCBCFunctionName);
  genDecryptCBC.SetCFunctionName(decryptCBCFunctionName);

  if ( !strcmp(argv[1],"nasm-elf") )
    {
      asmFormat=nasm_elf;
      AsmGenerator::syntax=AsmGenerator::NASM;
      AsmGenerator::target=AsmGenerator::ELF;
      AsmGenerator::callingConvention=AsmGenerator::CDECL;
    }
  else if ( !strcmp(argv[1],"nasm-aout") )
    {
      asmFormat=nasm_aout;
      AsmGenerator::syntax=AsmGenerator::NASM;
      AsmGenerator::target=AsmGenerator::AOUT;
      AsmGenerator::callingConvention=AsmGenerator::CDECL;
    }
  else if ( !strcmp(argv[1],"nasm-coff") )
    {
      asmFormat=nasm_coff;
      AsmGenerator::syntax=AsmGenerator::NASM;
      AsmGenerator::target=AsmGenerator::COFF;
      AsmGenerator::callingConvention=AsmGenerator::CDECL;
    }
  else if ( !strcmp(argv[1],"nasm-win32") )
    {
      asmFormat=nasm_win32;
      AsmGenerator::syntax=AsmGenerator::NASM;
      AsmGenerator::target=AsmGenerator::WIN32;
      AsmGenerator::callingConvention=AsmGenerator::CDECL;
    }
  else if ( !strcmp(argv[1],"att-elf") )
    {
      asmFormat=att_elf;
      AsmGenerator::syntax=AsmGenerator::ATT;
      AsmGenerator::target=AsmGenerator::ELF;
      AsmGenerator::callingConvention=AsmGenerator::CDECL;
    }
  else if ( !strcmp(argv[1],"att-aout") )
    {
      asmFormat=att_aout;
      AsmGenerator::syntax=AsmGenerator::ATT;
      AsmGenerator::target=AsmGenerator::AOUT;
      AsmGenerator::callingConvention=AsmGenerator::CDECL;
    }
  else if ( !strcmp(argv[1],"att-coff") )
    {
      asmFormat=att_coff;
      AsmGenerator::syntax=AsmGenerator::ATT;
      AsmGenerator::target=AsmGenerator::COFF;
      AsmGenerator::callingConvention=AsmGenerator::CDECL;
    }
  else if ( !strcmp(argv[1],"att-win32") )
    {
      asmFormat=att_win32;
      AsmGenerator::syntax=AsmGenerator::ATT;
      AsmGenerator::target=AsmGenerator::WIN32;
      AsmGenerator::callingConvention=AsmGenerator::CDECL;
    }
  else if ( !strcmp(argv[1],"att-cpp") )
    {
      asmFormat=att_cpp;
      AsmGenerator::syntax=AsmGenerator::ATT;
      AsmGenerator::target=AsmGenerator::CPP;
      AsmGenerator::callingConvention=AsmGenerator::CDECL;
    }
  else if ( !strcmp(argv[1],"wasm-register") )
    {
      asmFormat=wasm_register;
      AsmGenerator::syntax=AsmGenerator::MASM;
      AsmGenerator::target=AsmGenerator::WIN32;
      AsmGenerator::callingConvention=AsmGenerator::WATCOMREGISTER;
    }
  else if ( !strcmp(argv[1],"wasm-cdecl") )
    {
      asmFormat=wasm_cdecl;
      AsmGenerator::syntax=AsmGenerator::MASM;
      AsmGenerator::target=AsmGenerator::WIN32;
      AsmGenerator::callingConvention=AsmGenerator::CDECL;
    }
  else if ( !strcmp(argv[1],"masm-inl-cdecl") )
    {
      asmFormat=masm_inl_cdecl;
      AsmGenerator::syntax=AsmGenerator::MASM;
      AsmGenerator::target=AsmGenerator::INL;
      AsmGenerator::callingConvention=AsmGenerator::CDECL;
      masmINL=1;
    }
  else if ( !strcmp(argv[1],"masm-inl-fastcall") )
    {
      asmFormat=masm_inl_fastcall;
      AsmGenerator::syntax=AsmGenerator::MASM;
      AsmGenerator::target=AsmGenerator::INL;
      AsmGenerator::callingConvention=AsmGenerator::FASTCALL;
      masmINL=1;
    }
  else
    {
      Usage(cerr);
      return(1);
    }

  if ( asmFormat==masm_inl_fastcall )
  {
    masmINL=1;

    genEncryptECB.CustomFunctionBegin=INLEncryptECBFastcallFunctionBegin;
    genDecryptECB.CustomFunctionBegin=INLDecryptECBFastcallFunctionBegin;
    genEncryptCBC.CustomFunctionBegin=INLEncryptCBCFastcallFunctionBegin;
    genDecryptCBC.CustomFunctionBegin=INLDecryptCBCFastcallFunctionBegin;
  }
  else if ( asmFormat==masm_inl_cdecl )
  {
    masmINL=1;

    genEncryptECB.CustomFunctionBegin=INLEncryptECBCDeclFunctionBegin;
    genDecryptECB.CustomFunctionBegin=INLDecryptECBCDeclFunctionBegin;
    genEncryptCBC.CustomFunctionBegin=INLEncryptCBCCDeclFunctionBegin;
    genDecryptCBC.CustomFunctionBegin=INLDecryptCBCCDeclFunctionBegin;
  }

  if ( masmINL )
  {
    genEncryptECB.CustomFunctionEnd=INLFunctionEnd;
    genDecryptECB.CustomFunctionEnd=INLFunctionEnd;
    genEncryptCBC.CustomFunctionEnd=INLFunctionEnd;
    genDecryptCBC.CustomFunctionEnd=INLFunctionEnd;

    genEncryptECB.CustomFileBegin=INLFileBegin;
    genEncryptECB.CustomFileEnd=INLFileEnd;
  }

  genEncryptECB.FileBegin();
  genEncryptECB.Externals();

  cout <<endl;
  genEncryptECB.FunctionBegin();
  genEncryptECB.Startup();
  genEncryptECB.Body();
  genEncryptECB.Cleanup();
  genEncryptECB.FunctionEnd();
  cout <<endl;
  genDecryptECB.FunctionBegin();
  genDecryptECB.Startup();
  genDecryptECB.Body();
  genDecryptECB.Cleanup();
  genDecryptECB.FunctionEnd();
  cout <<endl;
  genEncryptCBC.FunctionBegin();
  genEncryptCBC.Startup();
  genEncryptCBC.Body();
  genEncryptCBC.Cleanup();
  genEncryptCBC.FunctionEnd();
  cout <<endl;
  genDecryptCBC.FunctionBegin();
  genDecryptCBC.Startup();
  genDecryptCBC.Body();
  genDecryptCBC.Cleanup();
  genDecryptCBC.FunctionEnd();

  genEncryptECB.FileEnd();

  return(0);
}
