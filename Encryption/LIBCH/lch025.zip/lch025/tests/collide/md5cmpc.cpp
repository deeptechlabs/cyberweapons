//
// md5cmpc.cpp
// 
// Demonstrates a collision found in the compression function of MD5
// by Dobbertin.
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#include <string.h>
#include <iostream.h>
#include <iomanip.h>
#include <chnhash/md5.hpp>

int main(int, char**)
{
  u32 B1[16]={ 0xaa1dda5e, 0xd97abff5, 0x55f0e1c1, 0x32774244,
               0x1006363e, 0x7218209d, 0xe01c135d, 0x9da64d0e,
               0x98a1fb19, 0x1fae44b0, 0x236bb992, 0x6b7a669b,
               0x1326ed65, 0xd93e0972, 0xd458c868, 0x6b72746a };
 
  u32 B2[16];
  memcpy(B2,B1,64);
  B2[14]+=512;

  u32 IV[4]={ 0x12ac2375, 0x3b341042, 0x5f62b97c, 0x4ba763ed };

  u32 Res1[4];
  u32 Res2[4];
 
  cout <<"This program is a test and should demonstrate a collision"<<endl;
  cout <<"in MD5's compression function discovered by Hans Dobbertin."<<endl;
  cout <<endl;

  cout <<"b1=";
  for (int i=0; i<16; i++)
    cout <<hex<<setw(8)<<setfill('0')<<B1[i];
  cout <<endl;
  cout <<endl;

  cout <<"b2=";
  for (int j=0; j<16; j++)
    cout <<hex<<setw(8)<<setfill('0')<<B2[j];
  cout <<endl;
  cout <<endl;

  cout <<"These blocks differ by only one bit. Look near the end and"<<endl;
  cout <<"you should see an `868' in one block and an `a68' in the other."<<endl;
  cout <<endl;

  cout <<"IV=";
  for (int k=0; k<4; k++)
    cout <<hex<<setw(8)<<setfill('0')<<IV[k];
  cout <<endl;
  cout <<endl;

  MD5::Compress(IV,B1,Res1);
  MD5::Compress(IV,B2,Res2);

  cout <<"Res1=";
  for (int l=0; l<4; l++)
    cout <<hex<<setw(8)<<setfill('0')<<Res1[l];
  cout <<endl;
  cout <<endl;

  cout <<"Res2=";
  for (int m=0; m<4; m++)
    cout <<hex<<setw(8)<<setfill('0')<<Res2[m];
  cout <<endl;
  cout <<endl;

  if ( memcmp(B1,B2,64) && !memcmp(Res1,Res2,16) )
    { 
      cout <<"Collision as claimed!"<<endl;
      return(0);
    }
  else
    { 
      cout <<"No collision! Bug in the implementation."<<endl;
      return(-1);
    }
  
}

