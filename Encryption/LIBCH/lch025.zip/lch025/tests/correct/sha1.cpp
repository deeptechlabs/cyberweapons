//
// sha1.cxx
// 
// tests the SHA1 implementation
// test data is from FIPS 180-1
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#include <chnhash/sha1.hpp>
#include <iostream.h>
#include <iomanip.h>
#include <string.h>

#define BYTES_IN_HASH 20

int Test0()
{
  const char* t="abc";
  const u8 exp[BYTES_IN_HASH]={ 0xa9, 0x99, 0x3e, 0x36, 0x47, 0x06, 0x81, 0x6a, 0xba, 0x3e, 0x25, 0x71, 0x78, 0x50, 0xc2, 0x6c, 0x9c, 0xd0, 0xd8, 0x9d };
  u8 res[BYTES_IN_HASH];

  SHA1 hashor;

  cout <<"Hashing ->"<<t<<"<-"<<endl;
  hashor.ProcessFinalBlock(t,strlen(t));
  hashor.ChainVariables(res);

  cout <<"res=     0x";
  for (int i=0; i<BYTES_IN_HASH; i++)
    cout <<hex<<setw(2)<<setfill('0')<<int(res[i]);
  cout <<endl;

  if ( memcmp(exp,res,BYTES_IN_HASH) )
    {
      cout <<"*****Failed!*****"<<endl;
      return -1;
    }

 cout <<"*****Passed!*****"<<endl;
 return 0;
}

int Test1()
{
  const char* t="abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq";
  const u8 exp[BYTES_IN_HASH]={ 0x84, 0x98, 0x3e, 0x44, 0x1c, 0x3b, 0xd2, 0x6e, 0xba, 0xae, 0x4a, 0xa1, 0xf9, 0x51, 0x29, 0xe5, 0xe5, 0x46, 0x70, 0xf1 };
  u8 res[BYTES_IN_HASH];

  SHA1 hashor;

  cout <<"Hashing ->"<<t<<"<-"<<endl;
  hashor.ProcessFinalBlock(t,strlen(t));
  hashor.ChainVariables(res);

  cout <<"res=     0x";
  for (int i=0; i<BYTES_IN_HASH; i++)
    cout <<hex<<setw(2)<<setfill('0')<<int(res[i]);
  cout <<endl;

  if ( memcmp(exp,res,BYTES_IN_HASH) )
    {
      cout <<"*****Failed!*****"<<endl;
      return -1;
    }

 cout <<"*****Passed!*****"<<endl;
 return 0;
}

int Test2()
{
  u8 t[64];
  const u8 exp[BYTES_IN_HASH]={ 0x34, 0xaa, 0x97, 0x3c, 0xd4, 0xc4, 0xda, 0xa4, 0xf6, 0x1e, 0xeb, 0x2b, 0xdb, 0xad, 0x27, 0x31, 0x65, 0x34, 0x01, 0x6f };
  u8 res[BYTES_IN_HASH];
  int i;

  SHA1 hashor;
  
  for (i=0; i<64; i++)
    t[i]='a';

  cout <<"Hashing ->one million 'a' 's<-"<<endl;
  for (i=0; i<15625; i++)
    hashor.ProcessMiddleBlock(t);
  hashor.ProcessFinalBlock(NULL,0);
  hashor.ChainVariables(res);

  cout <<"res=     0x";
  for (i=0; i<BYTES_IN_HASH; i++)
    cout <<hex<<setw(2)<<setfill('0')<<int(res[i]);
  cout <<endl;

  if ( memcmp(exp,res,BYTES_IN_HASH) )
    {
      cout <<"*****Failed!*****"<<endl;
      return -1;
    }

 cout <<"*****Passed!*****"<<endl;
 return 0;
}

int main(int, char**)
{
  int failedATest=0;

  cout <<"Testing the SHA1 hash function..."<<endl;
  cout <<endl;
  failedATest|=Test0(); cout <<endl;
  failedATest|=Test1(); cout <<endl;
  failedATest|=Test2(); cout <<endl;

  if ( failedATest )
    {
      cout <<"Oh, oh! Failed a test!"<<endl;
      return(-1);
    }

  cout <<"Passed all tests!"<<endl;
  return(0);
}


