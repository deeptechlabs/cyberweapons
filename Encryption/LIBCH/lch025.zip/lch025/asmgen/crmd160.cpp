//
// crmd160.cpp
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#include <iostream.h>
#include <iomanip.h>
#include <string.h>
#include "rmd160g.hpp"

const char* functionName="RIPEMD160Transform";
const char* programName="crmd160";

void Usage(ostream& os)
{
  os <<"usage: "<<programName<<" (assembly format)"<<endl;
  os <<"where (assembly format) is one of:"<<endl;
  os <<"nasm-elf, nasm-aout, nasm-coff, nasm-win32,"<<endl;
  os <<"att-elf, att-aout,  att-coff, att-win32, att-cpp,"<<endl;
  os <<"wasm-register, wasm-cdecl,"<<endl;
  os <<"masm-inl-fastcall, masm-inl-cdecl"<<endl;
}

int main(int argc, char* argv[])
{
  enum asmFormatEnum { nasm_elf, nasm_aout, nasm_coff, nasm_win32,
                       att_elf, att_aout, att_coff, att_win32, att_cpp,
                       wasm_register, wasm_cdecl,
                       masm_inl_fastcall, masm_inl_cdecl };

  asmFormatEnum asmFormat;

  if ( argc != 2 )
    {
      Usage(cerr);
      return(1); 
    }

  RMD160AsmGenerator genor(cout);
  genor.SetCPU(386);
  genor.SetCFunctionName(functionName);
  int masminl=0;

  if ( !strcmp(argv[1],"nasm-elf") )
    {
      asmFormat=nasm_elf;
      AsmGenerator::syntax=AsmGenerator::NASM;
      AsmGenerator::target=AsmGenerator::ELF;
      AsmGenerator::callingConvention=AsmGenerator::CDECL;
    }
  else if ( !strcmp(argv[1],"nasm-aout") )
    {
      asmFormat=nasm_aout;
      AsmGenerator::syntax=AsmGenerator::NASM;
      AsmGenerator::target=AsmGenerator::AOUT;
      AsmGenerator::callingConvention=AsmGenerator::CDECL;
    }
  else if ( !strcmp(argv[1],"nasm-coff") )
    {
      asmFormat=nasm_coff;
      AsmGenerator::syntax=AsmGenerator::NASM;
      AsmGenerator::target=AsmGenerator::COFF;
      AsmGenerator::callingConvention=AsmGenerator::CDECL;
    }
  else if ( !strcmp(argv[1],"nasm-win32") )
    {
      asmFormat=nasm_win32;
      AsmGenerator::syntax=AsmGenerator::NASM;
      AsmGenerator::target=AsmGenerator::WIN32;
      AsmGenerator::callingConvention=AsmGenerator::CDECL;
    }
  else if ( !strcmp(argv[1],"att-elf") )
    {
      asmFormat=att_elf;
      AsmGenerator::syntax=AsmGenerator::ATT;
      AsmGenerator::target=AsmGenerator::ELF;
      AsmGenerator::callingConvention=AsmGenerator::CDECL;
    }
  else if ( !strcmp(argv[1],"att-aout") )
    {
      asmFormat=att_aout;
      AsmGenerator::syntax=AsmGenerator::ATT;
      AsmGenerator::target=AsmGenerator::AOUT;
      AsmGenerator::callingConvention=AsmGenerator::CDECL;
    }
  else if ( !strcmp(argv[1],"att-coff") )
    {
      asmFormat=att_coff;
      AsmGenerator::syntax=AsmGenerator::ATT;
      AsmGenerator::target=AsmGenerator::COFF;
      AsmGenerator::callingConvention=AsmGenerator::CDECL;
    }
  else if ( !strcmp(argv[1],"att-win32") )
    {
      asmFormat=att_win32;
      AsmGenerator::syntax=AsmGenerator::ATT;
      AsmGenerator::target=AsmGenerator::WIN32;
      AsmGenerator::callingConvention=AsmGenerator::CDECL;
    }
  else if ( !strcmp(argv[1],"att-cpp") )
    {
      asmFormat=att_cpp;
      AsmGenerator::syntax=AsmGenerator::ATT;
      AsmGenerator::target=AsmGenerator::CPP;
      AsmGenerator::callingConvention=AsmGenerator::CDECL;
    }
  else if ( !strcmp(argv[1],"wasm-register") )
    {
      asmFormat=wasm_register;
      AsmGenerator::syntax=AsmGenerator::MASM;
      AsmGenerator::target=AsmGenerator::WIN32;
      AsmGenerator::callingConvention=AsmGenerator::WATCOMREGISTER;
    }
  else if ( !strcmp(argv[1],"wasm-cdecl") )
    {
      asmFormat=wasm_cdecl;
      AsmGenerator::syntax=AsmGenerator::MASM;
      AsmGenerator::target=AsmGenerator::WIN32;
      AsmGenerator::callingConvention=AsmGenerator::CDECL;
    }
  else if ( !strcmp(argv[1],"masm-inl-cdecl") )
    {
      asmFormat=masm_inl_cdecl;
      AsmGenerator::syntax=AsmGenerator::MASM;
      AsmGenerator::target=AsmGenerator::INL;
      AsmGenerator::callingConvention=AsmGenerator::CDECL;
    }
  else if ( !strcmp(argv[1],"masm-inl-fastcall") )
    {
      asmFormat=masm_inl_fastcall;
      AsmGenerator::syntax=AsmGenerator::MASM;
      AsmGenerator::target=AsmGenerator::INL;
      AsmGenerator::callingConvention=AsmGenerator::FASTCALL;
    }
  else
    {
      Usage(cerr);
      return(1);
    }

  switch ( asmFormat )
  {
  case masm_inl_fastcall:
    cout <<"#include \"clink.h\""<<endl;
    cout <<endl;
    cout <<"void __declspec(naked) __fastcall ";
    cout <<functionName<<"(u32* H, const u32* X)"<<endl;
    cout <<"{"<<endl;
    cout <<"  __asm{"<<endl;
    break;
  case masm_inl_cdecl:
    cout <<"#include \"clink.h\""<<endl;
    cout <<endl;
    cout <<"void __declspec(naked) __cdecl ";
    cout <<functionName<<"(u32* H, const u32* X)"<<endl;
    cout <<"{"<<endl;
    cout <<"  __asm{"<<endl;
    break;
  case nasm_elf:
  case nasm_aout:
  case nasm_coff:
  case nasm_win32:
  case att_elf:
  case att_aout:
  case att_coff:
  case att_win32:
  case att_cpp:
  case wasm_register:
  case wasm_cdecl:
    genor.FileBegin();
    break;
  default:
    cerr <<"Unrecognized assembly format. (bug)"<<endl;
    return(1);
  }

  genor.Startup();
  genor.Body();
  genor.Cleanup();

  switch ( asmFormat )
  {
  case masm_inl_fastcall:
  case masm_inl_cdecl:
    cout <<"  }"<<endl;
    cout <<"}"<<endl;
    break;
  case nasm_elf:
  case nasm_aout:
  case nasm_coff:
  case nasm_win32:
  case att_elf:
  case att_aout:
  case att_coff:
  case att_win32:
  case att_cpp:
  case wasm_register:
  case wasm_cdecl:
    genor.FileEnd();
    break;
  default:
    cerr <<"Unrecognized assembly format. (bug)"<<endl;
    return(1);
  }

  return(0);
}
