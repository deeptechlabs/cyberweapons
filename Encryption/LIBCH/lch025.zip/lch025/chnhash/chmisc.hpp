//
// chmisc.hpp
//
// odds and ends
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#ifndef _CHMISC_HPP
#define _CHMISC_HPP

#include <chnhash/chtypes.h>

class CHMisc 
{
public:
  static inline void MemSwap(u32* buffer, const int dwords);

  static inline u32 High32Of64(const u64 x);
  static inline u32 Low32Of64(const u64 x);
};

#include <chnhash/chmisc.inl>

#endif
