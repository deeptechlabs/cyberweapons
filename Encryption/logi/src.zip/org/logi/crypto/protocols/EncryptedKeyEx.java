// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.protocols;
import org.logi.crypto.*;
import org.logi.crypto.keys.*;
import org.logi.crypto.random.Seedable;

/**
 * Ancestor of EncryptedKeyEx classes.
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class EncryptedKeyEx extends Crypto {
    
    protected boolean keyDecided=false;

    protected CipherKey key;         // key used to encrypt/decrypt session-key
    protected SignatureKey signKey;  // key used to sign/verify session-key
    protected Key sessionKey;        // the session key
   
    /**
     * Called from sub-classes.
     */
    protected EncryptedKeyEx(CipherKey key, SignatureKey signKey, Key sessionKey){
        this.key=key;
	this.signKey=signKey;
        this.sessionKey=sessionKey;
    }
    
    /**
     * Returns the key if it has been decided upon,
     * or <code>null</code> otherwise.
     */
    public Key sessionKey(){
        return keyDecided ? sessionKey : null;
    }
    
    /** Returns true iff this end of the protocol i completed. */
    public boolean completed(){
        return keyDecided;
    }

    /**
     * Returns the maximum expected size of a message for this protocol. */
    public int maxMessageSize() {
        return 65536;
    }
   
}
