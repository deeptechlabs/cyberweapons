//
// asmgen.cpp
//
// Copyright (C) 1997 by Leonard Janke (janke@unixg.ubc.ca)

#include <iostream.h>
#include <iomanip.h>
#include <stdlib.h>
#include "asmgen.hpp"

// *****************************************************

// these defaults don't really matter since they can be change at
// runtime

#define DEFAULTSYNTAX MASM
// #define DEFSYNTAX NASM 
// #define DEFSYNTAX ATT

#define DEFAULTTARGET WIN32
// #define DEFAULTTARGET AOUT
// #define DEFAULTTARGET COFF
// #define DEFAULTTARGET CPP

#define DEFAULTCALLINGCONVENTION CDECL
// #define DEFAULTCALLINGCONVENTION=WATCOMREGISTER
// #define DEFAULTCALLINGCONVENTION=FASTCALL

#define DEFAULTCPU 386 
// #define DEFAULTCPU 486
// #define DEFAULTCPU 586

// Some versions of GNU's as and MSVC++ (including version 4.0) do not
// encode rol and ror by 1 properly. Leave this macro defined to work
// around this bug, or leave it defined just to be safe.
//
// Thanks to Peter Gutmann for advice on how to handle this bug. -Leonard

#define ROTATEBY1BUG

// *****************************************************

CSymbol::CSymbol(const char* symbol) : cSymbol(symbol)
{
}

ostream& CSymbol::WriteToStream(ostream& os) const
{
  switch ( AsmGenerator::target )
    {
    case AsmGenerator::WIN32:
    case AsmGenerator::COFF:
    case AsmGenerator::AOUT:
      os <<"_"<<cSymbol;
      break;
    case AsmGenerator::CPP:
      os <<"CSYMBOL("<<cSymbol<<")";
      break;
    case AsmGenerator::ELF:
    case AsmGenerator::INL:
      os <<cSymbol;
      break;
    default:
      cerr <<"Unrecognized calling convention"<<endl;
      exit(-1);
    } 
  return os;
}

ostream& operator<<(ostream& os, const CSymbol& symbol)
{
  return symbol.WriteToStream(os);
}

CPtr::CPtr(const char* cName) : CSymbol(cName)
{
}

// *****************************************************


class Address{
protected:
  virtual ostream& WriteToStream(ostream&) const=0;
public:
  friend ostream& operator<<(ostream& os, const Address& address);
  virtual ~Address() {}
};

ostream& operator<<(ostream& os, const Address& address)
{
  return address.WriteToStream(os);
}

class OffsetAddress : public Address{
protected:
  const s32 _offset;

  OffsetAddress(s32 offset);
public:
  virtual ~OffsetAddress() {}
};

OffsetAddress::OffsetAddress(s32 offset) : Address(), _offset(offset)
{
}


class RegisterOffsetAddress : public OffsetAddress{
private:
  const Register& _base;
  ostream& WriteToStream(ostream&) const;
public:
  ~RegisterOffsetAddress() {}
  RegisterOffsetAddress(const DWordRegister& base, const s32 offset);
};

RegisterOffsetAddress::RegisterOffsetAddress(const DWordRegister& base,
                                             const s32 offset) : 
  OffsetAddress(offset), _base(base)
{
}

ostream& RegisterOffsetAddress::WriteToStream(ostream& os) const
{
  switch ( AsmGenerator::syntax )
    {
    case AsmGenerator::MASM:
    case AsmGenerator::NASM:
      if ( _offset )
	os <<"["<<_base<<"+"<<_offset<<"]";
      else
	os <<"["<<_base<<"]";
      break;
    case AsmGenerator::ATT:
      if (_offset)
	os <<_offset<<"("<<_base<<")";
      else
	os <<"("<<_base<<")";
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }

  return os;
}

class CPtrOffsetAddress : public OffsetAddress{
private:
  const CPtr& _cPtr;
  ostream& WriteToStream(ostream&) const;
public:
  CPtrOffsetAddress(const CPtr& cPtr, const s32 offset);
  ~CPtrOffsetAddress() {}
};

CPtrOffsetAddress::CPtrOffsetAddress(const CPtr& cPtr, const s32 offset) : 
  OffsetAddress(offset) , _cPtr(cPtr)
{ 
}

ostream& CPtrOffsetAddress::WriteToStream(ostream& os) const
{
  switch ( AsmGenerator::syntax )
    {
    case AsmGenerator::NASM:
      if ( _offset )
	os <<"["<<_cPtr<<"+"<<_offset<<"]";
      else
	os <<"["<<_cPtr<<"]";
      break;
    case AsmGenerator::MASM:
    case AsmGenerator::ATT:
      if ( _offset )
	os <<_cPtr<<"["<<_offset<<"]";
      else
	os <<_cPtr;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }

  return os;
}

class ScaledIndexAddress : public Address{
protected:
  const DWordRegister& index;
  int scale;

  ScaledIndexAddress(int scale, const DWordRegister& index);
public:
  ~ScaledIndexAddress() {}
};

ScaledIndexAddress::ScaledIndexAddress(int scale, const DWordRegister& index)
 : Address(), index(index), scale(scale)
{
}

class CPtrScaledIndexAddress : public ScaledIndexAddress{
private:
  const CPtr& cPtr;
  ostream& WriteToStream(ostream&) const;
public:
  CPtrScaledIndexAddress(const CPtr& cPtr, const int scale, 
                          const DWordRegister& index);
  ~CPtrScaledIndexAddress() {}
};

CPtrScaledIndexAddress::CPtrScaledIndexAddress(const CPtr& cPtr, 
 const int scale, const DWordRegister& index) : 
  ScaledIndexAddress(scale,index) , cPtr(cPtr)
{ 
}

ostream& CPtrScaledIndexAddress::WriteToStream(ostream& os) const
{
  switch ( AsmGenerator::syntax )
    {
    case AsmGenerator::NASM:
      if ( scale!=1 )
	os <<"["<<cPtr<<"+"<<index<<"*"<<scale<<"]";
      else
	os <<"["<<cPtr<<"+"<<index<<"]";
      break;
    case AsmGenerator::MASM:
      if ( scale!=1 )
	os <<cPtr<<"["<<index<<"*"<<scale<<"]";
      else
	os <<cPtr<<"["<<index<<"]";
      break;
    case AsmGenerator::ATT:
      os <<cPtr<<"(,"<<index<<","<<scale<<")";
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }

  return os;
}

// *****************************************************

Register::Register(const char* intelSyntaxName, const char* attSyntaxName) :
  _intelSyntaxName(intelSyntaxName), _attSyntaxName(attSyntaxName) 
{
}

DWordRegister::DWordRegister(reg which, const char* intelSyntaxName, 
              const char* attSyntaxName) : 
   Register(intelSyntaxName,attSyntaxName), _register(which)
{
}

ByteRegister::ByteRegister(reg which, const char* intelSyntaxName, 
             const char* attSyntaxName) :
   Register(intelSyntaxName,attSyntaxName), _register(which)
{
}

const DWordRegister eax(DWordRegister::eax,"eax","%eax");
const DWordRegister ebx(DWordRegister::ebx,"ebx","%ebx");
const DWordRegister ecx(DWordRegister::ecx,"ecx","%ecx");
const DWordRegister edx(DWordRegister::edx,"edx","%edx");
const DWordRegister edi(DWordRegister::edi,"edi","%edi");
const DWordRegister esi(DWordRegister::esi,"esi","%esi");
const DWordRegister ebp(DWordRegister::ebp,"ebp","%ebp");
const DWordRegister esp(DWordRegister::esp,"esp","%esp");

const ByteRegister al(ByteRegister::al,"al","%al");
const ByteRegister ah(ByteRegister::ah,"ah","%ah");
const ByteRegister bl(ByteRegister::bl,"bl","%bl");
const ByteRegister bh(ByteRegister::bh,"bh","%bh");
const ByteRegister cl(ByteRegister::cl,"cl","%cl");
const ByteRegister ch(ByteRegister::ch,"ch","%ch");
const ByteRegister dl(ByteRegister::dl,"dl","%dl");
const ByteRegister dh(ByteRegister::dh,"dh","%dh");

AsmGenerator::syntaxEnum 
AsmGenerator::syntax=AsmGenerator::DEFAULTSYNTAX;

AsmGenerator::targetEnum 
AsmGenerator::target=AsmGenerator::DEFAULTTARGET;

AsmGenerator::callingConventionEnum 
AsmGenerator::callingConvention=AsmGenerator::DEFAULTCALLINGCONVENTION;

int AsmGenerator::CPU=DEFAULTCPU;

const char* AsmGenerator::sizeString[3]={ "BYTE", "WORD", "DWORD" };

Register::operator const char*() const
{
  const char* registerName;
  switch ( AsmGenerator::syntax )
    {
    case AsmGenerator::MASM:
    case AsmGenerator::NASM:
      registerName=_intelSyntaxName;
      break;
    case AsmGenerator::ATT:
      registerName=_attSyntaxName;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }

   return registerName;
}

AsmGenerator::AsmGenerator(ostream& os) : os(os), 
  CustomFileBegin(NULL), CustomFileEnd(NULL),
  CustomFunctionBegin(NULL), CustomFunctionEnd(NULL)
{
}

void AsmGenerator::Label(const char* label)
{
  switch ( syntax )
    {
    case NASM:
    case MASM:
    case ATT:
      os <<label<<": ";
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::DeclareExternal(const CPtr& ptr, sizeEnum size,
                                   int number)
{
  switch ( syntax )
    {
    case NASM:
      os <<"[EXTERN "<<ptr<<"]"<<endl;
      break;
    case MASM:
      switch ( target )
        {
        case WIN32:
          os <<"EXTRN "<<ptr<<" : "<<sizeString[size]<<" : "<<number<<endl;
          break;
        case INL:
          break;
        default:
          cerr <<"Target not supported for this syntax"<<endl;
          exit(-1);
        }
      break;
    case ATT:
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }

}

void AsmGenerator::Comment(const char* comment)
{
  switch ( syntax )
    {
    case NASM:
      os <<"; "<<comment<<endl;
      break;
    case MASM:
      switch ( target )
        {
        case WIN32:
          os <<"; "<<comment<<endl;
          break;
        case INL:
          os <<"/* "<<comment<<" */"<<endl;
          break;
        default:
          cerr <<"Target not supported for this syntax"<<endl;
          exit(-1);
        }
      break;
    case ATT:
      os <<"# "<<comment<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::WriteAsmFunctionName()
{
  switch ( target )
    {
    case ELF:
      os <<_cFunctionName;
      break;
    case AOUT:
    case COFF:
    case WIN32:
      switch ( callingConvention )
        {
        case CDECL:
	  os <<"_"<<_cFunctionName;
	  break;
        case WATCOMREGISTER:
	  os <<_cFunctionName<<"_";
	  break;
        default:
          cerr <<"Unrecognized calling convention"<<endl;
          exit(-1);
        }
      break;
    case CPP:
      // Function name will be generated by the C preprocessor using
      // some macros defined in asm.h due to Eric Young and sent to me by  
      // Peter Gutmann. Thanks to Peter Gutmann for suggesting
      // this.  - Leonard
      os <<"FUNCTION("<<_cFunctionName<<")";
      break;
    }
}


void AsmGenerator::Section(const char* name, int number)
{
  switch ( syntax )
    {
    case NASM:
      os <<"; "<<name<<" "<<number<<endl;
      break;
    case MASM:
      switch ( target )
        {
        case WIN32:
          os <<"; "<<name<<" "<<number<<endl;
          break;
        case INL:
          os <<"/* "<<name<<" "<<number<<" */"<<endl;
          break;
        default:
          cerr <<"Target not supported for this syntax"<<endl;
          exit(-1);
        }
      break;
    case ATT:
      os <<"# "<<name<<" "<<number<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::PushIndexedAddress(const DWordRegister& base, 
                                      const int scale, 
				      const DWordRegister& index, 
                                      const s32 offset)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"["<<base;
      if ( scale )
	if ( scale != 1 )
	  os <<"+"<<scale<<"*"<<index;
	else
	  os <<"+"<<index;
      if (offset)
	os <<"+"<<offset;
      os <<"]";
      break;
    case ATT:
      if (offset)
	os <<offset;
      os <<"("<<base;
      if ( scale )
	os <<","<<index<<","<<scale;
      os <<")";
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::Inc(const DWordRegister& dest)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tinc "<<dest<<endl;
      break;
    case ATT:
      os <<"\tincl "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}
 
void AsmGenerator::Neg(const DWordRegister& dest)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tneg "<<dest<<endl;
      break;
    case ATT:
      os <<"\tnegl "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}
 
void AsmGenerator::Jne(const char* label, jumpEnum jumpType)
{
  switch ( syntax )
    {
    case MASM:
    case ATT:
      os <<"\tjne "<<label<<endl;
      break;
    case NASM:
      os <<"\tjne ";
      switch ( jumpType )
      {
      case shortJ:
        break;
      case nearJ:
        os <<"near ";
        break;
      default:
        cerr <<"Unrecognized jump type"<<endl;
        exit(-1);
      }
      os <<label<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::Mov(const DWordRegister& dest, const DWordRegister& src, 
		       const int scale, const DWordRegister& index, 
		       const s32 offset)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tmov "<<dest<<", "; 
      PushIndexedAddress(src,scale,index,offset);
      os <<endl;
      break;
    case ATT:
      os <<"\tmovl ";
      PushIndexedAddress(src,scale,index,offset);
      os <<", "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::Mov(const DWordRegister& dest, const int scale, 
                       const DWordRegister& index, const s32 offset,
                       const DWordRegister& src)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tmov "; PushIndexedAddress(dest,scale,index,offset);
      os <<", "<<src; 
      os <<endl;
      break;
    case ATT:
      os <<"\tmovl "<<src<<", ";
      PushIndexedAddress(dest,scale,index,offset); os <<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::Mov(const DWordRegister& dest, const DWordRegister& src)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tmov "<<dest<<", "<<src<<endl;
      break;
    case ATT:
      os <<"\tmovl "<<src<<", "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::Mov(const ByteRegister& dest, const ByteRegister& src)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tmov "<<dest<<", "<<src<<endl;
      break;
    case ATT:
      os <<"\tmovb "<<src<<", "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::Mov(const DWordRegister& dest, const s32 immediate)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tmov "<<dest<<", "<<immediate<<endl;
      break;
    case ATT:
      os <<"\tmovl $"<<immediate<<", "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::Mov(const DWordRegister& dest, const DWordRegister& src,
		       const s32 offset)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tmov "<<dest<<", "<<RegisterOffsetAddress(src,offset)<<endl;
      break;
    case ATT:
      os <<"\tmovl "<<RegisterOffsetAddress(src,offset)<<", "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::Mov(const ByteRegister& dest, const DWordRegister& src,
		       const s32 offset)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tmov "<<dest<<", "<<RegisterOffsetAddress(src,offset)<<endl;
      break;
    case ATT:
      os <<"\tmovb "<<RegisterOffsetAddress(src,offset)<<", "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::Mov(const DWordRegister& dest, const CPtr& src, 
                       const s32 offset)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tmov "<<dest<<", "<<CPtrOffsetAddress(src,offset)<<endl;
      break;
    case ATT:
      os <<"\tmovl "<<CPtrOffsetAddress(src,offset)<<", "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::Mov(const DWordRegister& dest, const CPtr& src, 
                       const int scale, const DWordRegister& offset)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tmov "<<dest<<", "<<CPtrScaledIndexAddress(src,scale,offset);
      os <<endl;
      break;
    case ATT:
      os <<"\tmovl "<<CPtrScaledIndexAddress(src,scale,offset)<<", "<<dest;
      os <<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}
 
 
void AsmGenerator::Mov(const DWordRegister& dest, const s32 offset, 
		       const DWordRegister& src)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tmov "<<RegisterOffsetAddress(dest,offset)<<", "<<src<<endl;
      break;
    case ATT:
      os <<"\tmovl "<<src<<", "<<RegisterOffsetAddress(dest,offset)<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}
 
void AsmGenerator::Mov(const CPtr& dest, const s32 offset, 
		       const DWordRegister& src)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tmov "<<CPtrOffsetAddress(dest,offset)<<", "<<src<<endl;
      break;
    case ATT:
      os <<"\tmovl "<<src<<", "<<CPtrOffsetAddress(dest,offset)<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}
 
void AsmGenerator::And(const DWordRegister& dest, const DWordRegister& src)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tand "<<dest<<", "<<src<<endl;
      break;
    case ATT:
      os <<"\tandl "<<src<<", "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::And(const DWordRegister& dest, const s32 immediate)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tand "<<dest<<", "<<immediate<<endl;
      break;
    case ATT:
      os <<"\tandl $"<<immediate<<", "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}
 
void AsmGenerator::Or(const DWordRegister& dest, const DWordRegister& src)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tor "<<dest<<", "<<src<<endl;
      break;
    case ATT:
      os <<"\torl "<<src<<", "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}
 
void AsmGenerator::Xor(const DWordRegister& dest, const DWordRegister& src)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\txor "<<dest<<", "<<src<<endl;
      break;
    case ATT:
      os <<"\txorl "<<src<<", "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}
 
void AsmGenerator::Xor(const DWordRegister& dest, const s32 immediate)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\txor "<<dest<<", "<<immediate<<endl;
      break;
    case ATT:
      os <<"\txorl $"<<immediate<<", "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}
 
void AsmGenerator::Add(const DWordRegister& dest, const DWordRegister& src)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tadd "<<dest<<", "<<src<<endl;
      break;
    case ATT:
      os <<"\taddl "<<src<<", "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::Add(const DWordRegister& dest, const DWordRegister& src, 
		       const s32 offset)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tadd "<<dest<<", "<<RegisterOffsetAddress(src,offset)<<endl;
      break;
    case ATT:
      os <<"\taddl "<<RegisterOffsetAddress(src,offset)<<", "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::Add(const DWordRegister& dest, const CPtr& src, 
		       const s32 offset)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tadd "<<dest<<", "<<CPtrOffsetAddress(src,offset)<<endl;
      break;
    case ATT:
      os <<"\taddl "<<CPtrOffsetAddress(src,offset)<<", "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::Add(const DWordRegister& dest, const s32 immediate)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tadd "<<dest<<", "<<immediate<<endl;
      break;
    case ATT:
      os <<"\taddl $"<<immediate<<", "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::Add(const ByteRegister& dest, const s8 immediate)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tadd "<<dest<<", "<<int(immediate)<<endl;
      break;
    case ATT:
      os <<"\taddb $"<<int(immediate)<<", "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}
 

void AsmGenerator::Adc(const DWordRegister& dest, const DWordRegister& src)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tadc "<<dest<<", "<<src<<endl;
      break;
    case ATT:
      os <<"\tadcl "<<src<<", "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::Adc(const ByteRegister& dest, const ByteRegister& src)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tadc "<<dest<<", "<<src<<endl;
      break;
    case ATT:
      os <<"\tadcb "<<src<<", "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::Adc(const DWordRegister& dest, const DWordRegister& src, 
		       const s32 offset)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tadc "<<dest<<", "<<RegisterOffsetAddress(src,offset)<<endl;
      break;
    case ATT:
      os <<"\tadcl "<<RegisterOffsetAddress(src,offset)<<", "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::Adc(const DWordRegister& dest, const CPtr& src, 
		       const s32 offset)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tadc "<<dest<<", "<<CPtrOffsetAddress(src,offset)<<endl;
      break;
    case ATT:
      os <<"\tadcl "<<CPtrOffsetAddress(src,offset)<<", "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}
 
void AsmGenerator::Adc(const DWordRegister& dest, const s32 immediate)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tadc "<<dest<<", "<<immediate<<endl;
      break;
    case ATT:
      os <<"\tadcl $"<<immediate<<", "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::Sub(const DWordRegister& dest, const s32 immediate)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tsub "<<dest<<", "<<immediate<<endl;
      break;
    case ATT:
      os <<"\tsubl $"<<immediate<<", "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::Sub(const DWordRegister& dest, const DWordRegister& src)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tsub "<<dest<<", "<<src<<endl;
      break;
    case ATT:
      os <<"\tsubl "<<src<<", "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::MulD(const CPtr& src, const s32 offset)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tmul dword ptr "<<CPtrOffsetAddress(src,offset)<<endl;
      break;
    case ATT:
      os <<"\tmull "<<CPtrOffsetAddress(src,offset)<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::MulD(const DWordRegister& src, const s32 offset)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tmul dword ptr "<<RegisterOffsetAddress(src,offset)<<endl;
      break;
    case ATT:
      os <<"\tmull "<<RegisterOffsetAddress(src,offset)<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}
 
void AsmGenerator::Rol(const DWordRegister& dest, const int immediate) 
{
  switch ( syntax )
    {
    case MASM:
#if defined(ROTATEBY1BUG)
    if ( target != INL || immediate!=1 )
      os <<"\trol "<<dest<<", "<<immediate<<endl;
    else
    {
      os <<"\t_emit 0xd1"<<endl;
      os <<"\t_emit 0xc"<<RegCode(dest)<<endl;
    }
#else
      os <<"\trol "<<dest<<", "<<immediate<<endl;
#endif
     break;
    case NASM:
      os <<"\trol "<<dest<<", "<<immediate<<endl;
      break;
    case ATT:

#if defined(ROTATEBY1BUG)
      if ( immediate!=1 )
	os <<"\troll $"<<immediate<<", "<<dest<<endl;
      else
	os <<"\t.byte 0xd1, 0xc"<<RegCode(dest)<<endl;
#else
      os <<"\troll $"<<immediate<<", "<<dest<<endl;
#endif
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::Rol(const DWordRegister& dest, const ByteRegister& src)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\trol "<<dest<<", "<<src<<endl;
     break;
    case ATT:
      os <<"\troll "<<src<<", "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::Ror(const DWordRegister& dest, const int immediate)
{
  switch ( syntax )
    {
    case MASM:
#if defined(ROTATEBY1BUG)
      if ( target != INL || immediate!=1 )
        os <<"\tror "<<dest<<", "<<immediate<<endl;
      else
      {
        os <<"\t_emit 0xd1"<<endl;
        os <<"\t_emit "<<(12*16+8+RegCode(dest))<<endl;
      }
#else
        os <<"\tror "<<dest<<", "<<immediate<<endl;
#endif
      break;
    case NASM:
      os <<"\tror "<<dest<<", "<<immediate<<endl;
      break;
    case ATT:
#if defined(ROTATEBY1BUG)
      if ( immediate!=1 )
	os <<"\trorl $"<<immediate<<", "<<dest<<endl;
      else
	os <<"\t.byte 0xd1, "<<(12*16+8+RegCode(dest))<<endl;
#else
      os <<"\trorl $"<<immediate<<", "<<dest<<endl;
#endif
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::Shr(const DWordRegister& dest, const int immediate)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tshr "<<dest<<", "<<immediate<<endl;
      break;
    case ATT:
      os <<"\tshrl $"<<immediate<<", "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}


void AsmGenerator::BSwap(const DWordRegister& dest)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tbswap "<<dest<<endl;
      break;
    case ATT:
      os <<"\tbswapl "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}
 
void AsmGenerator::Push(const DWordRegister& src)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tpush "<<src<<endl;
      break;
    case ATT:
      os <<"\tpushl "<<src<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}
 
void AsmGenerator::Pop(const DWordRegister& dest)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tpop "<<dest<<endl;
      break;
    case ATT:
      os <<"\tpopl "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::Nop()
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
    case ATT:
      os <<"\tnop"<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::Ret(const s32 adjustment)
{
  os <<"\tret "<<adjustment<<endl;
}
 
void AsmGenerator::Ret()
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tret"<<endl;
      break;
    case ATT:
      os <<"\tret"<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}
 
void AsmGenerator::Lea(const DWordRegister& dest, const DWordRegister& src, 
		       const int scale, const DWordRegister& index, 
		       const s32 offset)
{
  switch ( syntax )
    {
    case MASM:
    case NASM:
      os <<"\tlea "<<dest<<", "; 
      PushIndexedAddress(src,scale,index,offset);
      os <<endl;
      break;
    case ATT:
      os <<"\tleal ";
      PushIndexedAddress(src,scale,index,offset);
      os <<", "<<dest<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::FileBegin()
{
  Copyright();
  
  if ( CustomFileBegin )
  {
    CustomFileBegin(os);
    return;
  }


  switch ( syntax )
    {
    case MASM:
      os <<"."<<CPU<<endl;
      os <<".MODEL FLAT"<<endl;
      os <<"_TEXT SEGMENT"<<endl;
      break;
    case NASM:
      os <<"[BITS 32]"<<endl;
      os <<"[SECTION .text]"<<endl;
      break;
    case ATT:
      switch ( target )
	{
	case ELF:
	case AOUT:
	case COFF:
        case WIN32: 
	  os <<".text"<<endl;
	  break;
	case CPP:  
          // Use the C preprocessor to help generate the function beginning,
          // using some macros defined in asm.h due to Eric Young and 
          // sent to me by  Peter Gutmann. Thanks to Peter Gutmann for 
          // suggesting this.  - Leonard

	  os <<"#include \"asm.h\""<<endl;
          os <<endl;
	  os <<".text"<<endl;
	  break;
	default:
	  cerr <<"Unrecognized target"<<endl;
	  exit(-1);
	}
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl; exit(-1);
    }
}

void AsmGenerator::FunctionBegin()
{
  if ( CustomFunctionBegin )
  {
    CustomFunctionBegin(os);
    return;
  }

  switch ( syntax )
    {
    case MASM:
      os <<"PUBLIC "; WriteAsmFunctionName(); os <<endl;
      WriteAsmFunctionName(); os <<" PROC"<<endl;
      break;
    case NASM:
      os <<"[GLOBAL "; WriteAsmFunctionName(); os <<"]"<<endl;
      WriteAsmFunctionName(); os <<":"<<endl;
      break;
    case ATT:
      switch ( target )
	{
	case ELF:
	case AOUT:
	case COFF:
        case WIN32: 
	  os <<".globl "; WriteAsmFunctionName(); os <<endl;
	  os <<".align "<<((target==ELF) ? 16 : 4)<<endl;
	  WriteAsmFunctionName(); os <<":"<<endl;
	  break;
	case CPP:  
          // Use the C preprocessor to help generate the function beginning,
          // using some macros defined in asm.h due to Eric Young and 
          // sent to me by  Peter Gutmann. Thanks to Peter Gutmann for 
          // suggesting this.  - Leonard

	  os <<".globl FUNCTION("<<_cFunctionName<<")"<<endl;
	  os <<".align ALIGN"<<endl;
	  os <<"FUNCTION("<<_cFunctionName<<"):"<<endl;
	  break;
	default:
	  cerr <<"Unrecognized target"<<endl;
	  exit(-1);
	}
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl; exit(-1);
    }
}

void AsmGenerator::FunctionEnd()
{
  if ( CustomFunctionEnd )
  {
    CustomFunctionEnd(os);
    return;
  }

  switch ( syntax )
    {
    case NASM:
    case ATT:
      break;
    case MASM:
      WriteAsmFunctionName(); os <<" ENDP"; os <<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

void AsmGenerator::FileEnd()
{
  if ( CustomFileEnd )
  {
    CustomFileEnd(os);
    return;
  }

  switch ( syntax )
    {
    case NASM:
    case ATT:
      break;
    case MASM:
      os <<"_TEXT ENDS"<<endl;
      os <<"END"<<endl;
      break;
    default:
      cerr <<"Unrecognized syntax"<<endl;
      exit(-1);
    }
}

int RegCode(const DWordRegister& which)
{
  int rv;
  switch ( which._register )
    {
    case DWordRegister::eax:
      rv=0;
      break;
    case DWordRegister::ebx:
      rv=3;
      break;
    case DWordRegister::ecx:
      rv=1;
      break;
    case DWordRegister::edx:
      rv=2;
      break;
    case DWordRegister::edi:
      rv=7;
      break;
    case DWordRegister::esi:
      rv=6;
      break;
    case DWordRegister::ebp:
      rv=5;
      break;
    case DWordRegister::esp:
      rv=4;
      break;
    default:
      cerr <<"Ain't no register I ever heard about before."<<endl;
      exit(-1);
    }

  return rv;
}

int RegCode(const ByteRegister& which)
{
  int rv;
  switch ( which._register )
    {
    case ByteRegister::al:
      rv=0;
      break;
    case ByteRegister::bl:
      rv=3;
      break;
    case ByteRegister::cl:
      rv=1;
      break;
    case ByteRegister::dl:
      rv=2;
      break;
    case ByteRegister::bh:
      rv=7;
      break;
    case ByteRegister::dh:
      rv=6;
      break;
    case ByteRegister::ch:
      rv=5;
      break;
    case ByteRegister::ah:
      rv=4;
      break;
    default:
      cerr <<"Ain't no register I ever heard about before."<<endl;
      exit(-1);
    }

  return rv;
}
