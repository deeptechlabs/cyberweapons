//
// sha0.cxx
// 
// tests the SHA0 implementation
// test data is from FIPS180
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#include <chnhash/sha0.hpp>
#include <iostream.h>
#include <iomanip.h>
#include <string.h>

#define BYTES_IN_HASH 20

int Test0()
{
  const char* t="abc";
  const u8 exp[BYTES_IN_HASH]={ 0x01, 0x64, 0xb8, 0xa9, 0x14, 0xcd, 0x2a, 0x5e, 0x74, 0xc4, 0xf7, 0xff, 0x08, 0x2c, 0x4d, 0x97, 0xf1, 0xed, 0xf8, 0x80 };
  u8 res[BYTES_IN_HASH];

  SHA0 hashor;

  cout <<"Hashing ->"<<t<<"<-"<<endl;
  hashor.ProcessFinalBlock(t,strlen(t));
  hashor.ChainVariables(res);

  cout <<"res=     0x";
  for (int i=0; i<BYTES_IN_HASH; i++)
    cout <<hex<<setw(2)<<setfill('0')<<int(res[i]);
  cout <<endl;

  if ( memcmp(exp,res,BYTES_IN_HASH) )
    {
      cout <<"*****Failed!*****"<<endl;
      return -1;
    }

 cout <<"*****Passed!*****"<<endl;
 return 0;
}

int Test1()
{
  const char* t="abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq";
  const u8 exp[BYTES_IN_HASH]={ 0xd2, 0x51, 0x6e, 0xe1, 0xac, 0xfa, 0x5b, 0xaf, 0x33, 0xdf, 0xc1, 0xc4, 0x71, 0xe4, 0x38, 0x44, 0x9e, 0xf1, 0x34, 0xc8 };
  u8 res[BYTES_IN_HASH];

  SHA0 hashor;

  cout <<"Hashing ->"<<t<<"<-"<<endl;
  hashor.ProcessFinalBlock(t,strlen(t));
  hashor.ChainVariables(res);

  cout <<"res=     0x";
  for (int i=0; i<BYTES_IN_HASH; i++)
    cout <<hex<<setw(2)<<setfill('0')<<int(res[i]);
  cout <<endl;

  if ( memcmp(exp,res,BYTES_IN_HASH) )
    {
      cout <<"*****Failed!*****"<<endl;
      return -1;
    }

 cout <<"*****Passed!*****"<<endl;
 return 0;
}

int Test2()
{
  u8 t[64];
  const u8 exp[BYTES_IN_HASH]={ 0x32, 0x32, 0xaf, 0xfa, 0x48, 0x62, 0x8a, 0x26, 0x65, 0x3b, 0x5a, 0xaa, 0x44, 0x54, 0x1f, 0xd9, 0x0d, 0x69, 0x06, 0x03 };
  int i;

  u8 res[BYTES_IN_HASH];

  SHA0 hashor;
  
  for (i=0; i<64; i++)
    t[i]='a';

  cout <<"Hashing ->one million 'a' 's<-"<<endl;
  for (i=0; i<15625; i++)
    hashor.ProcessMiddleBlock(t);
  hashor.ProcessFinalBlock(NULL,0);
  hashor.ChainVariables(res);

  cout <<"res=     0x";
  for (i=0; i<BYTES_IN_HASH; i++)
    cout <<hex<<setw(2)<<setfill('0')<<int(res[i]);
  cout <<endl;

  if ( memcmp(exp,res,BYTES_IN_HASH) )
    {
      cout <<"*****Failed!*****"<<endl;
      return -1;
    }

 cout <<"*****Passed!*****"<<endl;
 return 0;
}

int main(int, char**)
{
  int failedATest=0;

  cout <<"Testing the SHA0 hash function..."<<endl;
  cout <<endl;
  failedATest|=Test0(); cout <<endl;
  failedATest|=Test1(); cout <<endl;
  failedATest|=Test2(); cout <<endl;

  if ( failedATest )
    {
      cout <<"Oh, oh! Failed a test!"<<endl;
      return(-1);
    }

  cout <<"Passed all tests!"<<endl;
  return(0);
}


