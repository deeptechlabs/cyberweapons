// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.io;
import org.logi.crypto.*;
import org.logi.crypto.keys.*;
import org.logi.crypto.modes.*;
import org.logi.crypto.protocols.*;

import java.io.*;

/**
 * This class can be used to apply an interactive key exchange protocol to a
 * pair of streams and then encrypt all data going through them with the session
 * key exchanged.
 * <p>
 * It can also execute interactive protocols on the streams once they are
 * initialized.
 * <p>
 * This class expects to talk to an equivalent client class.
 *
 * @see org.logi.crypto.io.CipherStreamClient
 * @version 1.0.6
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class CipherStreamServer extends CipherStream {
    
    /**
     * Create a new CipherStreamServer object and ecxhange keys.
     * <p>
     * Create a new object which uses <code>kex</code> to exchange keys with
     * a remote client and then <code>encrypt</code> to encrypt the data to
     * <code>out</code> and <code>decrypt</code> to decrypt data from
     * <code>in</code> and <code>out</code>.
     * <p>
     * if <code>kex==null</code> then the key-exchange step is skipped and
     * the <code>encrypt</code> and <code>decrypt</code> objects must have
     * been initialized with a key beforethis call.
     *
     * @exception CryptoProtocolException if there is a problem exchanging keys.
     * @exception IOException if there is a problem with the underlying streams.
     */
   public CipherStreamServer(InputStream in, OutputStream out, InterKeyExServer kex, EncryptSession encrypt, DecryptSession decrypt) throws CryptoProtocolException, IOException {
      this.in  = in;
      this.out = out;
      if(kex!=null){
	 execute(kex, false);
	 CipherKey key;
	 try{
	    key=(CipherKey)kex.sessionKey();
	    encrypt.setKey(key);
	    decrypt.setKey(key);
	 } catch (ClassCastException cce){
	    throw new CryptoProtocolException("The exchanged Key was not a CipherKey.");
	 } catch (CryptoException ce) {
	    throw new CryptoProtocolException(ce.getMessage());
	 }
      }
      cOut = new EncryptStream(out, null, encrypt);
      cIn = new DecryptStream(in, null, decrypt);
   }

   /**
    * Executes an interactive key-exchange protocol. If encrypt is true,
    * messages will be sent through the encrypted channel. This induces a
    * flush of the outgoing stream and causes the incoming stream to be
    * drained.
    * <p>
    * After the protocol has been executed, the exchanged key will be used
    * for encryption.
    * 
    * @exception IOException if there is a low-level problem.
    * @exception CryptoProtocolException if the protocol could not execute.
    */
   public void reKey(InterKeyExServer kex, boolean encrypt) throws IOException, CryptoProtocolException {
      execute(kex, false);
      try{
	 CipherKey key=(CipherKey)kex.sessionKey();
	 if(key==null)
	   throw new CryptoProtocolException("A non-interactive protocol should only need one message.");
	 cIn.setKey(key);
	 cOut.setKey(key);
      } catch (ClassCastException e){
	 throw new CryptoProtocolException("The key-exchange protocol proposes to use a non-cipher key for decryption.");
      } catch (CryptoException ke) {
	 throw new CryptoProtocolException(ke.getMessage());
      }
   }
   
    /**
     * Executes an interactive protocol. If encrypt is true, then the
     * protocol will be executed through the encrypted link. This requires
     * the object to have been initialized with a key to use.
     * 
     * @exception CryptoProtocolException if there is a problem with the protocol keys.
     * @exception IOException if there is a problem with the underlying streams.
     */
    public void execute(InterProtocolServer prot, boolean encrypt) throws IOException, CryptoProtocolException{
        InputStream  i = encrypt ? cIn  : in;
        OutputStream o = encrypt ? cOut : out;
        byte[] msg=null;
        while(true) {
            int l=readInt(i);
	    if(l<0 || l>prot.maxMessageSize())
	        throw new CryptoProtocolException(l+" is not a valid message size for this protocol.");
            if((msg==null) || (msg.length!=l))
                msg=new byte[l];
            l=i.read(msg);
            if(l<0)
                throw new CryptoProtocolException("Client broke connection");
            msg=prot.message(msg);
            if(msg==null)
                break;
            writeInt(o,msg.length);
            o.write(msg);
	    o.flush();
            if(prot.completed())
                break;
        }
    }

}
