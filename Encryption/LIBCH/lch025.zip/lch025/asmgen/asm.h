/* Preprocessor file to convert generic AT&T assembler syntax code to OS-
   specific variants, based on a version by Eric Young.

   Sent to me by Peter Gutmann -Leonard */

#ifndef _ASM_H
#define _ASM_H

#if !( defined( ASM_OUT ) || defined( ASM_BSDI ) || defined( ASM_ELF ) || \
	   defined( ASM_SOLARIS ) )
  #error You need to define one of ASM_OUT, ASM_BSDI, ASM_ELF, or ASM_SOLARIS
#endif /* Check for missing defines */

#define TYPE( a, b )	.type a, b
#define SIZE( a, b )	.size a, b

/* a.out (older Linux, FreeBSD).  Underscores on names, align to word
   boundaries */

#ifdef ASM_OUT
  #define FUNCTION( name )	_name
  #define ALIGN				4
#endif /* ASM_OUT */

/* BSDI.  As a.out, but with an archaic version of as */

#ifdef ASM_BSDI
  #define FUNCTION( name )	_name
  #define ALIGN				4
  #undef SIZE
  #undef TYPE
#endif /* ASM_BSDI */

/* ELF (newer Linux, NetBSD, DG-UX), Solaris (as ELF but with strange comment
   lines).  No underscores on names, align to paragraph boundaries */

#if defined( ASM_ELF ) || defined( ASM_SOLARIS )
  #define FUNCTION( name )	name
  #define ALIGN				16
#endif /* ASM_ELF || ASM_SOLARIS */

#endif /* _ASM_H */
