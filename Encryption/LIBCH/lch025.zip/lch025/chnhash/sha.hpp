//
// sha.hpp
//
// Abstract base class for the two versions of the NIST/NSA's 
// Secure Hash Algorithm (first defined in FIPS180 but  
// modified in FIPS180-1)
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#ifndef _SHA_HPP
#define _SHA_HPP

#include <chnhash/chnhash.hpp>
#include <chnhash/chmisc.hpp>

class SHA : public ChainHash 
{
protected:
  virtual void ProcessBlock(const u32* X)=0;

  u32 H[5];
  u32 buf[16];
public:
  SHA();
  virtual ~SHA();

  inline void ProcessMiddleBlock(const void* block, const int aligned=0);
  void ProcessFinalBlock(const void* block, const int size);

  void Reset();

  void ChainVariables(void* buffer) const;

  static const u32 H0;
  static const u32 H1;
  static const u32 H2;
  static const u32 H3;
  static const u32 H4;
};

void SHA::ProcessMiddleBlock(const void* block, const int aligned)
{
  if ( aligned )
    ProcessBlock((const u32*) block);
  else
    {
      memcpy(buf,block,64);   
      ProcessBlock(buf);
    }

  _bitCount+=512;
}

#endif
