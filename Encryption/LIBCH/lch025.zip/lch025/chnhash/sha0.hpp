//
// sha0.hpp
//
// The NIST/NSA's Secure Hash Algorithm as defined in FIPS 180.
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#ifndef _SHA0_HPP
#define _SHA0_HPP

#include <chnhash/sha.hpp>

class SHA0 : public SHA 
{
private:
  void ProcessBlock(const u32* X);
public:
  SHA0();
  ~SHA0();

  static void Compress(const u32* iv, const u32* block, u32* result);
  static void Compress(const void* iv, const void* block, void* result);
};

#endif
