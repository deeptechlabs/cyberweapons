// Copyright (C) 2000 Logi Ragnarsson

package org.logi.crypto.sign;
import org.logi.crypto.*;

import java.io.*;
/**
 * This class is used to hold a blinded fingerprint of a particular data
 * buffer.<p>

 * This blinded fingerprint is calculated from a normal Fingerprint with a
 * blinding function. It can then be signed with a signature key using an
 * algorithm matching the blinding function, whereafter the signature can
 * be un-blinded by the person who blinded the fingerprint. The un-blinded
 * signature can be checked against the original fingerprint directly.<p>

 * In this library the blinding functions correspond to keys implementing
 * the BlindSignatureKey class.

 * (the following uses the &lt;sub&gt; and &lt;sup&gt; HTML tags, so if it
 * looks unintelligeble and you think you should understand the mathematics,
 * your browser probably doesn't support them.)<p>

 * For example in the case of RSA blind signatures, the process is the
 * following: We have an RSA key with public exponent <i>e</i>, secret
 * exponent <i>d</i>, and modulus <i>n</i> and wish to sign a message
 * <i>m</i>. First we calculate a fingerprint <i>f&nbsp;= h(m)</i>, where
 * <i>h</i> is a hash-function, probably SHA-1. Next we blind this
 * fingerprint using a random number <i>r</i> in <i>f'&nbsp;=
 * fr<sup>e</sup></i>. This fingerprint is signed normally by the owner of
 * the key-pair and we get the blind signature <i>s'&nbsp;=
 * f'<sup>d</sup>&nbsp;= (fr<sup>e</sup>)<sup>d</sup>&nbsp;=
 * f<sup>d</sup>(r<sup>e</sup>)<sup>d</sup>&nbsp;= f<sup>d</sup>r</i>.
 * Finally we can un-blind this signature to get <i>s&nbsp;= s'/r&nbsp;=
 * f<sup>d</sup></i> which is a standard signature.<p>

 * This is secure because multiplication with an element from the modulus
 * group is a one-to-one function and an <i>r</i> exists to convert
 * <i>s'</i> to a signature for any fingerprint <i>f</i>, but it is
 * infeasible to find without knowing the secret modulus <i>d</i>. This
 * means that the signer can not know what he is signing and yet that the
 * person submitting a blinded fingerprint <i>f'</i> to be signed can't
 * convert it to a (blind) signature for another fingerprint <i>f</i>.<p>
 
 * Also, the use of the hash function <i>h</i> ensures that the
 * multiplicative property of RSA does not cause problems, since if
 * <i>s<sub>1</sub>&nbsp;= f<sub>1</sub><sup>d</sup></i> and
 * <i>s<sub>2</sub>&nbsp;= f<sub>2</sub><sup>d</sup></i> we will have
 * <i>s&nbsp;= s<sub>1</sub>s<sub>2</sub>&nbsp;=
 * f<sub>1</sub><sup>d</sup>f<sub>2</sub><sup>d</sup>&nbsp;=
 * f<sup>d</sup></i> for <i>f&nbsp;= f<sub>1</sub>f<sub>2</sub></i> which
 * could be a major security flaw if the messages were signed directly, but
 * we still have the problem of producing a message <i>m</i> with
 * <i>h(m)&nbsp;= f</i>.
 
 * @see org.logi.crypto.sign.Fingerprint
 * @see org.logi.crypto.keys.BlindSignatureKey
 * @see org.logi.crypto.keys.BlindingFactor
 * @see org.logi.crypto.sign.BlindSignature
 * @see org.logi.crypto.sign.Signature
 * @see org.logi.crypto.keys.RSAKey
 * @version 1.1.0
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a> (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class BlindFingerprint extends Fingerprint {

   String blindFunc;
   
   public BlindFingerprint(String hashFunc, String blindFunc, byte[] fp){
      this(hashFunc, blindFunc, fp, 0, fp.length);
   }
   
   public BlindFingerprint(String hashFunc, String blindFunc, byte[] fp, int offset, int n){
      super(hashFunc, fp, offset, n);
      this.blindFunc=blindFunc;
   }
   
    /**
     * Return the name of the function used to blind the fingerprint.
     */
    public String getBlindFunc(){
        return blindFunc;
    }

   /**
    * Used by Crypto.fromString when parsing a CDS.<p>

    * A valid CDS can be created by calling the toString() method.

    * @exception InvalidCDSException if the CDS is malformed.
    * @see org.logi.crypto.Crypto#fromString(String)
    */
   public static Fingerprint parseCDS(String[] param) throws InvalidCDSException{
      if(param.length!=3)
	throw new InvalidCDSException("invalid number of parameters in the CDS BlindFingerprint(hashFunc,blindFunc,fingerprint)");
      return new BlindFingerprint(param[0], param[1], fromHexString(param[2]));
   }

    /**
     * Test for equality with another object. Returns true if <code>obj</code>
     * is a Fingerprint equal to <code>this</code>.
     */
    public boolean equals(Object obj){
        if (obj==null)
            return false;
        if (obj instanceof BlindFingerprint)
            return false;
        // It's the same class
        
        BlindFingerprint f=(BlindFingerprint)obj;
        if (!f.hashFunc.equals(hashFunc))
            return false;
        if (!f.blindFunc.equals(blindFunc))
            return false;
        // It's the same algorithms.
        
        for (int i=fp.length-1; i>=0; i--)
            // this.fp[j] == fp[j] for j=0, 1, ..., i-1.
            if (fp[i]!=f.fp[i])
                return false;
        
        return true;
    }
    
    /**
     * Return a hash-code based on the bytes of the
     * fingerprint and the algorithm names.
     */
    public int hashCode(){
       return super.hashCode() ^ blindFunc.hashCode();
    }
    
    /**
     * Return a CDS for this fingerprint.
     */
    public String toString(){
        return "BlindFingerprint("+hashFunc+","+blindFunc+","+hexString(fp)+")";
    }
   
   /**
    * Print this object to out, indented with ind tabs, going down at most
    * rec levels of recursion. */
   public void prettyPrint(PrintWriter out, int ind, int rec) throws IOException {
      if(rec<0)
	return;
      for(int i=0; i<ind; i++)
	out.print('\t');
      out.println("BlindFingerprint(");
      
      for(int i=0; i<=ind; i++)
	out.print('\t');
      out.print(hashFunc==null ? "null" : hashFunc);
      out.println(",");
      
      for(int i=0; i<=ind; i++)
	out.print('\t');
      out.print(blindFunc==null ? "null" : blindFunc);
      out.println(",");
      
      for(int i=0; i<=ind; i++)
	out.print('\t');
      out.print(fp==null ? "null" : hexString(fp));
      out.println();
      
      for(int i=0; i<ind; i++)
	out.print('\t');
      out.print(")");
   }

}

