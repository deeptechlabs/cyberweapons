// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.keys;
import org.logi.crypto.*;
import org.logi.crypto.hash.*;

/**
 * This abstract class implements some of the methods from the Key interface.
 * It is used as the superclass of all the key classes in logi.crypto.
 * <p>
 * You should (probably) never declare variables of this type, but rather of the
 * more abstract Key interface, since there might be key objects which do not
 * inherit from this class.
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public abstract class K extends Crypto implements Key {
  
  // -----------------------------------------------------------
  // INSTANCE VARIABLES

  // The key's default fingerprint or null.
  protected Fingerprint fingerprint;

  // The default fingerprint of the other key in the pair or null.
  protected Fingerprint otherFingerprint;

  // -----------------------------------------------------------
  // INSTANCE METHODS
  
  /** 
   * Calculate the fingerprint for this key or the other in the pair. */
  protected abstract Fingerprint calcFingerprint(boolean other, String algorithm) throws InvalidCDSException;

  /** Return the key's fingerprint using the default hash function. */
  public final Fingerprint getFingerprint(){
      String defaultHash = HashState.getDefaultHashFunction();
      if (fingerprint==null || !fingerprint.getName().equals(defaultHash))
          try{
              fingerprint=calcFingerprint(false, defaultHash);
          } catch (InvalidCDSException e){
              throw new CryptoCorruptError("The HashState object for "+defaultHash+" has disappeared.");
          }
      return fingerprint;
  }
  
  /** 
   * Return the key's fingerprint using the named hash function.
   
   * @exception InvalidCDSException if the specified hash function is not
   * available. */
  public final Fingerprint getFingerprint(String algorithm) throws InvalidCDSException {
      if(algorithm.equals(HashState.getDefaultHashFunction()))
          return getFingerprint();
      else
          return calcFingerprint(false, algorithm);
  }
  
  /**
   * Returns the default fingerprint of the matching key in the key-pair. */
  public Fingerprint matchFingerprint(){
      String defaultHash = HashState.getDefaultHashFunction();
      if (fingerprint==null || !fingerprint.getName().equals(defaultHash))
          try{
              fingerprint=calcFingerprint(true, defaultHash);
          } catch (InvalidCDSException e){
              throw new CryptoCorruptError("The HashState object for "+defaultHash+" has disappeared.");
          }
      return fingerprint;
  }
  
  /**
   * Returns the default fingerprint of the matching key in the key-pair.
   
   * @exception InvalidCDSException if the specified hash function is not
   * available. */
  public Fingerprint matchFingerprint(String algorithm) throws InvalidCDSException {
      if(algorithm.equals(HashState.getDefaultHashFunction()))
          return getFingerprint();
      else
          return calcFingerprint(true, algorithm);
  }
  
  /**
   * Return a hash-code based on the keys SHA1 fingerprint. */
  public final int hashCode(){
    return getFingerprint().hashCode();
  }
  
}
