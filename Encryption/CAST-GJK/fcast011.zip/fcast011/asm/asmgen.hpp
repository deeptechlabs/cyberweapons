//
// asmgen.hpp
//
// Copyright (C) 1997 by Leonard Janke (janke@unixg.ubc.ca)

#ifndef _ASMGEN_HPP
#define _ASMGEN_HPP

typedef long s32;
typedef char s8;

class ostream;

class Register
{
public:
  Register(const char* intelSyntaxName, const char* attSyntaxName);
  operator const char*() const;

protected:
  const char* _intelSyntaxName;
  const char* _attSyntaxName;
};

class DWordRegister : public Register
{
public:
  enum reg { eax, ebx, ecx, edx, edi, esi, ebp, esp };
  reg _register;

  DWordRegister(reg which, const char* intelSyntaxName, 
                const char* attSyntaxName);
};

class ByteRegister : public Register
{
public:
  enum reg { al, ah, bl, bh, cl, ch, dl, dh };
  reg _register;

  ByteRegister(reg which, const char* intelSyntaxName, 
               const char* attSyntaxName);
};

extern const DWordRegister eax, ebx, ecx, edx, edi, esi, ebp, esp;
extern const ByteRegister   al,  ah,  bl,  bh,  cl,  ch,  dl,  dh;

class CSymbol
{
protected:
  const char* cSymbol; 
  virtual ostream& WriteToStream(ostream& os) const;
public:
  CSymbol(const char* symbol);
  virtual ~CSymbol() {}

  friend ostream& operator<<(ostream& os, const CSymbol& symbol);
};

ostream& operator<<(ostream& os, const CSymbol& symbol);

class CPtr : public CSymbol
{
public:
  CPtr(const char* cName);
  ~CPtr() {}
};

class AsmGenerator
{
private:
  const char* _cFunctionName;

  void WriteAsmFunctionName();
protected:
  static int CPU;
  enum sizeEnum  { byte=0, word=1, dword=2 };
  enum jumpEnum { shortJ=0, nearJ=1 };
  static const char* sizeString[3]; 

  void DeclareExternal(const CPtr& symbol, sizeEnum size, int number);
  void Section(const char* name, int number);
  void Label(const char* label);

  void PushIndexedAddress(const DWordRegister& base, const int scale, 
			  const DWordRegister& index, const s32 offset);
  // that's "push" onto the output stream 

  void Neg(const DWordRegister& dest);
  void Inc(const DWordRegister& dest);
  void Jne(const char* label, jumpEnum jumpType=shortJ);
  void Mov(const DWordRegister& dest, const DWordRegister& src);
  void Mov(const ByteRegister& dest, const ByteRegister& src);
  void Mov(const DWordRegister& dest, const CPtr& src, const s32 offset);
  void Mov(const DWordRegister& dest, const CPtr& src, const int scale,
           const DWordRegister& index);
  void Mov(const DWordRegister& dest, const s32 immediate);
  void Mov(const CPtr& dest, const s32 offset, const DWordRegister& src);
  void Mov(const DWordRegister& dest, const DWordRegister& src, 
           const s32 offset);
  void Mov(const DWordRegister& dest, const DWordRegister& src, 
           const int scale, const DWordRegister& index, const s32 offset);
  void Mov(const DWordRegister& dest, const int scale, 
           const DWordRegister& index, const s32 offset, 
           const DWordRegister& src);
  void Mov(const ByteRegister& dest, const DWordRegister& src, 
           const s32 offset);
  void Mov(const DWordRegister& dest, const s32 offset, 
           const DWordRegister& src);
  void And(const DWordRegister& dest, const DWordRegister& src);
  void And(const DWordRegister& dest, const s32 immediate);
  void Or(const DWordRegister& dest, const DWordRegister& src);
  void Xor(const DWordRegister& dest, const DWordRegister& src);
  void Xor(const DWordRegister& dest, const s32 immediate);
  void Add(const DWordRegister& dest, const DWordRegister& src);
  void Add(const DWordRegister& dest, const CPtr& src, const s32 offset);
  void Add(const DWordRegister& dest, const DWordRegister& src, 
           const s32 offset);
  void Add(const DWordRegister& dest, const s32 immediate);
  void Add(const ByteRegister& dest, const s8 immediate);
  void Adc(const DWordRegister& dest, const DWordRegister& src);
  void Adc(const ByteRegister& dest, const ByteRegister& src);
  void Adc(const DWordRegister& dest, const CPtr& src, const s32 offset);
  void Adc(const DWordRegister& dest, const DWordRegister& src, 
           const s32 offset);
  void Adc(const DWordRegister& dest, const s32 immediate);
  void Sub(const DWordRegister& dest, const DWordRegister& src);
  void Sub(const DWordRegister& dest, const s32 immediate);
  void MulD(const CPtr& src, const s32 offset);
  void MulD(const DWordRegister& src, const s32 offset);
  void Shr(const DWordRegister& dest, const int immediate);
  void Rol(const DWordRegister& dest, const ByteRegister& src);
  void Rol(const DWordRegister& dest, const int immediate);
  void Ror(const DWordRegister& dest, const int immediate);
  void Push(const DWordRegister& src);
  void Pop(const DWordRegister& dest);
  void Lea(const DWordRegister& dest, const DWordRegister& src, 
           const int scale, const DWordRegister& index, const s32 offset);
  void BSwap(const DWordRegister& dest);
  void Nop();
  void Ret(const s32 adjustment);
  void Ret();

  ostream& os;
public:
  enum syntaxEnum { MASM, NASM, ATT };
  enum targetEnum { ELF, AOUT, COFF, CPP, WIN32, INL };
  enum callingConventionEnum { CDECL, WATCOMREGISTER, FASTCALL };

  static syntaxEnum syntax;
  static targetEnum target;
  static callingConventionEnum callingConvention;

  AsmGenerator(ostream& os);
  virtual ~AsmGenerator() {}

  void Comment(const char* comment);
  void SetCFunctionName(const char* cFunctionName) 
   { _cFunctionName=cFunctionName; } 

  // You will need to define both of these if you want inline MASM code, 
  // otherwise, the default file beginning and endings should be ok.
  void (*CustomFunctionBegin)(ostream&);
  void (*CustomFunctionEnd)(ostream&);
  void (*CustomFileBegin)(ostream&);
  void (*CustomFileEnd)(ostream&);

  virtual void Copyright() {}

  virtual void FileBegin();
  virtual void Externals() {}
  virtual void FunctionBegin();
  virtual void Startup()=0;
  virtual void Body()=0;
  virtual void Cleanup()=0;
  virtual void FunctionEnd();
  virtual void FileEnd();
};

int RegCode(const DWordRegister& which);
int RegCode(const ByteRegister& which);

#endif
