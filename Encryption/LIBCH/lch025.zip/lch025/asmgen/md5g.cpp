//
// md5g.cpp
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#include <stdlib.h>
#include <iomanip.h>
#include "a2r128.hpp"
#include "md5g.hpp"

const u32 MD5AsmGenerator::K[64]={
  // round 1  
  0xd76aa478, 0xe8c7b756, 0x242070db, 0xc1bdceee,
  0xf57c0faf, 0x4787c62a, 0xa8304613, 0xfd469501,
  0x698098d8, 0x8b44f7af, 0xffff5bb1, 0x895cd7be,
  0x6b901122, 0xfd987193, 0xa679438e, 0x49b40821,

  // round 2
  0xf61e2562, 0xc040b340, 0x265e5a51, 0xe9b6c7aa,
  0xd62f105d, 0x02441453, 0xd8a1e681, 0xe7d3fbc8,
  0x21e1cde6, 0xc33707d6, 0xf4d50d87, 0x455a14ed,
  0xa9e3e905, 0xfcefa3f8, 0x676f02d9, 0x8d2a4c8a,

  // round 3
  0xfffa3942, 0x8771f681, 0x6d9d6122, 0xfde5380c,
  0xa4beea44, 0x4bdecfa9, 0xf6bb4b60, 0xbebfbc70,
  0x289b7ec6, 0xeaa127fa, 0xd4ef3085, 0x04881d05,
  0xd9d4d039, 0xe6db99e5, 0x1fa27cf8, 0xc4ac5665,

  // round 4
  0xf4292244, 0x432aff97, 0xab9423a7, 0xfc93a039,
  0x655b59c3, 0x8f0ccc92, 0xffeff47d, 0x85845dd1,
  0x6fa87e4f, 0xfe2ce6e0, 0xa3014314, 0x4e0811a1,
  0xf7537e82, 0xbd3af235, 0x2ad7d2bb, 0xeb86d391
};

const int MD5AsmGenerator::r[64]={
  0, 1, 2, 3,
  4, 5, 6, 7,
  8, 9, 10, 11,
  12, 13, 14, 15,

  1, 6, 11, 0,
  5, 10, 15, 4,
  9, 14, 3, 8,
  13, 2, 7, 12,

  5, 8, 11, 14,
  1, 4, 7, 10,
  13, 0, 3, 6,
  9, 12, 15, 2,

  0, 7, 14, 5,
  12, 3, 10, 1,
  8, 15, 6, 13,
  4, 11, 2, 9
};

const int MD5AsmGenerator::s[64]={
  7, 12, 17, 22,
  7, 12, 17, 22,
  7, 12, 17, 22,
  7, 12, 17, 22,

  5, 9, 14, 20,
  5, 9, 14, 20,
  5, 9, 14, 20,
  5, 9, 14, 20,

  4, 11, 16, 23,
  4, 11, 16, 23,
  4, 11, 16, 23,
  4, 11, 16, 23,

  6, 10, 15, 21,
  6, 10, 15, 21,
  6, 10, 15, 21,
  6, 10, 15, 21
};

MD5AsmGenerator::MD5AsmGenerator(ostream& os) : AsmGenerator(os)
{
}

void MD5AsmGenerator::Startup()
{
  os <<endl;

  Push(ebp);
  Push(esi);
  Push(edi);
  Push(ebx);
  
  switch ( callingConvention )
  {
  case WATCOMREGISTER:
    Push(ecx);
    Push(eax);
    Mov(edi,eax);
    Mov(esi,edx);
    break;
  case FASTCALL: 
    Push(ecx);
    Mov(edi,ecx);
    Mov(esi,edx);
    break;
  case CDECL:
    Mov(edi,esp,4+16);
    Mov(esi,esp,8+16);
    break;
  default:
    cerr <<"Unrecognized calling convention"<<endl;
    exit(-1);
  }
  os <<endl;

  Mov(eax,edi,0);
  Mov(ebx,edi,4);
  Mov(ecx,edi,8);
  Mov(edx,edi,12);
}

void MD5AsmGenerator::PrintRound1()
{
  a2r128 reg;

  Mov(edi,reg[C]);
  Mov(ebp,esi,r[0]*4);
  for (int i=0; i<16; i++)
    {
      // a=b+(a+(d^(b&(c^d)))+M+k)<<<s

      Subround(i);

      Xor(edi,reg[D]);

      And(edi,reg[B]);
      Lea(reg[A],reg[A],1,ebp,K[i]); 

      Xor(edi,reg[D]);
      Mov(ebp,esi,r[i+1]*4);

      Add(reg[A],edi);
      Mov(edi,reg[B]);

      Rol(reg[A],s[i]);

      Add(reg[A],reg[B]);
      os <<endl;

      reg.Circulate();
    }
}

void MD5AsmGenerator::PrintRound2()
{
  a2r128 reg;

  for (int i=16; i<32; i++)
    {
      // a=b+(a+(c^(d&(b^c)))+M+k)<<<s

      Subround(i);

      Xor(edi,reg[B]);

      And(edi,reg[D]);
      Lea(reg[A],reg[A],1,ebp,K[i]);

      Xor(edi,reg[C]);
      Mov(ebp,esi,r[i+1]*4);

      Add(reg[A],edi);
      Mov(edi,reg[B]);

      Rol(reg[A],s[i]);

      Add(reg[A],reg[B]);

      os <<endl;
      reg.Circulate();
    }
}

void MD5AsmGenerator::PrintRound3()
{
  a2r128 reg; 

  for (int i=32; i<48; i+=2)
    {
      // a=b+(a+(b^c^d)+M+k)<<<s
      int subround=i;

      Subround(subround);

      Xor(edi,reg[D]);

      Xor(edi,reg[B]);
      Lea(reg[A],reg[A],1,ebp,K[subround]);

      Add(reg[A],edi);
      Mov(ebp,esi,r[subround+1]*4);

      Rol(reg[A],s[subround]);

      Add(reg[A],reg[B]);
      Mov(edi,reg[B]);

      os <<endl;
      reg.Circulate();

      // a=b+(a+(b^c^d)+M+k)<<<s

      subround++;
      Subround(subround);

      Xor(edi,reg[D]);
      Lea(reg[A],reg[A],1,ebp,K[subround]);

      Xor(edi,reg[B]);
      Mov(ebp,esi,r[subround+1]*4);

      Add(reg[A],edi);
      if ( subround!=47 )
        Mov(edi,reg[B]);
      else
        Mov(edi,reg[C]);

      Rol(reg[A],s[subround]);

      Add(reg[A],reg[B]);

      os <<endl;
      reg.Circulate();
    }
}
 
void MD5AsmGenerator::PrintRound4()
{
  a2r128 reg; 

  Nop();

  for (int i=48; i<64; i++)
    {
      // a=b+(a+(c^(b|~d))+M+k)<<<s
      Subround(i);
      Xor(edi,-1);

      Or(edi,reg[B]);
      Lea(reg[A],reg[A],1,ebp,K[i]);

      Xor(edi,reg[C]);
      Mov(ebp,esi,r[i+1]*4);

      Add(reg[A],edi);
      Mov(edi,reg[C]);

      Rol(reg[A],s[i]);

      Add(reg[A],reg[B]);

      os <<endl;
      reg.Circulate();
    }
}

void MD5AsmGenerator::Body()
{
  PrintRound1();
  PrintRound2();
  PrintRound3();
  PrintRound4();
}

void MD5AsmGenerator::Cleanup()
{
  switch ( callingConvention )
  {
  case WATCOMREGISTER: 
  case FASTCALL:
    Pop(edi);
    break;
  case CDECL:
    Mov(edi,esp,4+16);
    break;
  default:
    cerr <<"Unrecognized calling convention"<<endl;
    exit(-1);
  }

  Mov(ebp,edi,0);
  Mov(esi,edi,4);

  Add(eax,ebp);
  Add(ebx,esi);

  Mov(edi,0,eax);
  Mov(edi,4,ebx);

  Mov(eax,edi,8);
  Mov(ebx,edi,12);

  Add(ecx,eax);
  Add(edx,ebx);

  Mov(edi,8,ecx);
  Mov(edi,12,edx);
  os <<endl;
  if ( callingConvention==WATCOMREGISTER )
    Pop(ecx);
  Pop(ebx);
  Pop(edi);
  Pop(esi);
  Pop(ebp);
  os <<endl;
  Ret();
}
