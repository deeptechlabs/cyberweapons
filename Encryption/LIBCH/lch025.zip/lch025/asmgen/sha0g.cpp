//
// sha0g.cpp
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#include "sha0g.hpp"

SHA0AsmGenerator::SHA0AsmGenerator(ostream& os) : SHAAsmGenerator(os, 0)
{
}
