package org.logi.crypto.demo;

import org.logi.crypto.sign.*;
import java.io.*;

/**
 * Compute a hash of the data on standard in and
 * write it to standard out. The name of the hash
 * function is taken on the command line, but defaults
 * to SHA1
 * 
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class hash {

   private hash(){ }

   public static void help(String msg) {
      if(msg!=null)
	System.err.println(msg);
      System.err.println();
      System.err.println("use: java org.logi.crypto.demo.hash [-a <algorithm>] <filename>*");
      System.err.println("     algorithm ::= MD5|SHA1");
      System.err.println();
      System.err.println("All files named on the commandline will be hashed with the selected hash");
      System.err.println("function and the results written to standard output. If no filename is specified");
      System.err.println("input will be taken from standard input. The default hash function is SHA1");
      System.err.println();
      System.exit(1);
   }
   
   public static Fingerprint hashIt(InputStream in, String algorithm) throws Exception {
      HashState state = HashState.create(algorithm);
      byte[] buf = new byte[state.blockSize()];
      int n=in.read(buf);
      while (n!=-1) {
	 state.update(buf,0,n);
	 n=in.read(buf);
      }
      return(state.calculate());
   }
   
   public static void main (String arg[]) throws Exception {
      org.logi.crypto.Crypto.initRandom();
      
      String algorithm="SHA1";

      int i=0;
      while(i<arg.length && arg[i].charAt(0)=='-') {
	 if(arg[i].equals("-a")) {
	    if(arg.length<i+1) {
	       help("Missing argument to "+arg[i]);
	    }
	    algorithm = arg[i+1];
	    i++;
	 } else {
	    help("Unknown argument "+arg[i]);
	 }
	 i++;
      }

      if(i==arg.length) {
	 // there are no input files fiven
	 System.out.println(hashIt(System.in, algorithm));
      } else while(i<arg.length) {
	 System.out.print(hashIt(new FileInputStream(arg[i]), algorithm));
	 System.out.print(' ');
	 System.out.println(arg[i]);
	 i++;
      }
      
   }
    
}
