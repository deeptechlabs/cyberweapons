//
// sha0.cxx
//
// The NIST/NSA's Secure Hash Algorithm as defined in FIPS 180.
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#include <string.h>
#include "sha0.hpp"
#include "chmisc.hpp"
#include "clink.h"

SHA0::SHA0() : SHA()
{
}

SHA0::~SHA0()
{
}

void SHA0::Compress(const u32* iv, const u32* block, u32* result)
{
  memcpy(result,iv,20);
  SHA0Transform(result,block);
}

void SHA0::Compress(const void* iv, const void* block, void* result)
{
  u32 Block[16];
  u32 Result[5];

  memcpy(Result,iv,20);
  CHMisc::MemSwap(Result,5);

  memcpy(Block,block,64);

  SHA0Transform(Result,Block);

  CHMisc::MemSwap(Result,5);
  memcpy(result,Result,20);
}

void SHA0::ProcessBlock(const u32* block)
{
  SHA0Transform(H,block);
}
