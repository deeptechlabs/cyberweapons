//
// cbcdec.hpp
//
// Copyright (C) 1997 by Leonard Janke (janke@unixg.ubc.ca)

#ifndef _CBCDEC_HPP 
#define _CBCDEC_HPP

#include "cast128d.hpp"

class CAST128CBCDecryptAsmGenerator : public CAST128DecryptAsmGenerator
{
private:
  static const char* loopBeginLabel;

  int counter;
  int in;
  int out;
  int iv;
  int nextIVR;
  int nextIVL;
  int thisIVR;
  int thisIVL;

  int localVarsSize;
 
  void LoopBegin();
  void LoopEnd();
public:
  CAST128CBCDecryptAsmGenerator(ostream& os);

  void Startup();
  void Body();
  void Cleanup();
};

#endif
