// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.test;

import org.logi.crypto.*;
import org.logi.crypto.keys.*;
import org.logi.crypto.sign.*;
import org.logi.crypto.io.*;

import java.io.*;

/**
 * This application passes everything on standard input to a SignStream
 * and then on through a VerifyStream and onto standard output. This is a
 * very complicated way to achieve nothing at all.
 * <p>
 * It tests the SignStream, VerifyStream, Signature,
 * RSAKey, SHA1State and other classes.
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class TestSign extends Crypto{
    
    private TestSign(){}
    
    static void copyStream(InputStream in, OutputStream out) throws IOException {
        byte[] buf=new byte[1];
        int l;
        while((l=in.read(buf))!=-1)
            out.write(buf,0,l);
    }
    
    static class VerifyThread extends Thread{
        
        InputStream in;
        
        public VerifyThread(InputStream in){
            this.in = in;
        }
        
        public void run(){
            try {
                copyStream(in,System.out);
            } catch (IOException e) {
                e.printStackTrace(System.err);
            }
        }
        
    }
    
    public static void main(String[] arg) throws Exception {
        Crypto.initRandom();
        
        System.out.println("Generating RSA Keys");
        KeyPair kp = RSAKey.createKeys(512);
        SignatureKey pub = (SignatureKey)kp.getPublic();
        SignatureKey pri = (SignatureKey)kp.getPrivate();
        
        System.out.println("Please enter or pipe something to standard input");
        PipedInputStream pin = new PipedInputStream();
        PipedOutputStream pout = new PipedOutputStream(pin);
        
        new VerifyThread(new VerifyStream(pin,
                                          512,
                                          pub,
                                          new SHA1State()
                                         )).start();
        
        OutputStream out = new SignStream(pout,
                                          512,
                                          pri,
                                          new SHA1State()
                                         );
        copyStream(System.in,out);
        out.close();
    }
    
}
