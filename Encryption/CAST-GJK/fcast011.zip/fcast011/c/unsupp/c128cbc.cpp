#include "cast.h"
#include "modes.h"

#include <iostream.h>
#include <iomanip.h>
#include <string.h>

typedef unsigned char BYTE;
typedef unsigned long LONG;

void main( void )
{
  BYTE key[ 16 ] = { 0x01, 0x23, 0x45, 0x67, 0x12, 0x34, 0x56, 0x78,
                     0x23, 0x45, 0x67, 0x89, 0x34, 0x56, 0x78, 0x9A };

  BYTE plain[ 8*8 ] = { 
                        0x01, 0x23, 0x45, 0x67, 
                        0x89, 0xAB, 0xCD, 0xEF,
                        0xFE, 0xCD, 0xAB, 0x89,
                        0x67, 0x45, 0x23, 0x01,
                        0x10, 0x32, 0x54, 0x76,
                        0x98, 0xBA, 0xDC, 0xFE,
                        0xEF, 0xDC, 0xBA, 0x98,
                        0x76, 0x54, 0x32, 0x10,

                        0x76, 0x54, 0x32, 0x10,
                        0xEF, 0xDC, 0xBA, 0x98,
                        0x98, 0xBA, 0xDC, 0xFE,
                        0x10, 0x32, 0x54, 0x76,
                        0x67, 0x45, 0x23, 0x01,
                        0xFE, 0xCD, 0xAB, 0x89,
                        0x89, 0xAB, 0xCD, 0xEF,
                        0x01, 0x23, 0x45, 0x67, 
                         };

  BYTE cipher[ 8*8 ];
  BYTE iv[8]={ 0xEF, 0xCD, 0xAB, 0x89, 0x67, 0x45, 0x23, 0x01 };
  int i, j;

  memset(cipher,0,8*8);

  CAST128Encryption encipheror(key);
  CBCEncryption cbcor(encipheror,iv);

  /* CBC test */

  cout <<"key"<<endl;
  for (i=0; i<16; i++)
   cout <<hex<<setw(2)<<setfill('0')<<int(key[i])<<" ";
  cout <<endl;

  cout <<"iv"<<endl;
  for (i=0; i<8; i++)
   cout <<hex<<setw(2)<<setfill('0')<<int(iv[i])<<" ";
  cout <<endl;

  for (i=0; i<8; i++)
    cbcor.ProcessBlock(plain+8*i,cipher+8*i);

  cout <<"plaintext"<<endl;
  for (j=0; j<8; j++)
    {
      for (i=0; i<8; i++)
        cout <<hex<<setw(2)<<setfill('0')<<int(plain[8*j+i])<<" ";
      cout <<endl;
    }
  
  cout <<"ciphertext"<<endl;
  for (j=0; j<8; j++)
    {
      for (i=0; i<8; i++)
        cout <<hex<<setw(2)<<setfill('0')<<int(cipher[8*j+i])<<" ";
      cout <<endl;
    }
}
