// Copyright (C) 1998-2000 Logi Ragnarsson

package org.logi.crypto.test;
import org.logi.crypto.*;

import java.io.*;
import java.util.*;

/**
 * This application runs all the different tests.
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class TestIterate extends Crypto{

   private TestIterate(){}
   
   private static char[] metricPrefix= { 'a', 'p', 'n', 'm', ' ', 'K', 'M', 'G', 'T' };
   private static int prefixNeutral = 4;
   private static int prefixMax     = metricPrefix.length-prefixNeutral-1;
   
   public static String metricString(double x, int base){
      if (x==0)
	return "0";
      int unit = 0;
      while(x>10*base && unit<prefixMax){
	 x/= base;
	 unit+=1;
      }
      while(x<base/10 && unit>-prefixNeutral){
	 x*=base;
	 unit-=1;
      }
      String r = String.valueOf((int)(x+0.5))+" ";
      if (unit==0)
	return r;
      if (-prefixNeutral<unit && unit < prefixMax)
	return r+metricPrefix[unit+prefixNeutral];
      return r+"e"+(3*unit)+" ";
   }

   private static void help(){
      System.err.println("Iterate the tests in TestKey and TestMode over");
      System.err.println("all possible key and mode combinations.");
      System.err.println();
      System.err.println("Use: java org.logi.crypto.test.TestIterate <parameter>*");
      System.err.println("  <parameter> ::= +v | -v | -R | -r n");
      System.err.println("                | +T | -T | +t <test> | -t <test>");
      System.err.println("                | +K | -K | +k <key-type> | -k <key-type>");
      System.err.println("                | +M | -M | +m <mode> | -m <mode>");
      System.err.println("  <test>      ::= CDS | Crypt | Vector | Sign | BlindSign");
      System.err.println("  <key-type>  ::= Caesar | DES | TriDES | Blowfish | RSA | DH");
      System.err.println("  <mode>      ::= ECB | CBC | CFB | OFB");
      System.err.println();
      System.err.println("Where:");
      System.err.println("  -v +v   select/unselect verbose mode.");
      System.err.println("  +n -n   toggle nervous mode, i.e. bailing on error.");
      System.err.println("  -R      specifies to run indefinately.");
      System.err.println("  -r n    specifies to run n iterations.");
      System.err.println("  +K -K   enable/disable all key classes.");
      System.err.println("  +k name enable specific key class.");
      System.err.println("  -k name disable specific key class.");
      System.err.println("  +M -M   enable/disable all modes.");
      System.err.println("  +m name enable specific mode.");
      System.err.println("  -m name disable specific mode.");
      System.err.println();
      System.err.println("The defaults correspond to:");
      System.err.println("  -v -n -r 1 +T +K -k Caesar +M");
      System.exit(0);
   }
   
   public static void main(String[] arg) throws Exception {
      Crypto.initRandom();
      PrintWriter summary = new PrintWriter(System.out, true);
      PrintWriter details=null;
      
      int repeat=1;
      boolean nervous=false;

      Hashtable keys = new Hashtable();
      keys.put("DES", "DES");
      keys.put("TriDES", "TriDES");
      keys.put("Blowfish", "Blowfish");
      keys.put("RSA", "RSA");
      keys.put("DH", "DH");

      Hashtable modes = new Hashtable();
      modes.put("ECB", "ECB");
      modes.put("CBC", "CBC");
      modes.put("CFB", "CFB");
      modes.put("OFB", "OFB");
      
      Hashtable tests = new Hashtable();
      tests.put("CDS","CDS");
      tests.put("Crypt","Crypt");
      tests.put("Vector","Vector");
      tests.put("Sign","Sign");
      tests.put("BlindSign","BlindSign");
		
      for(int i=0; i<arg.length; i++) {
	 if (arg[i].equals("+v")) {
	    details=summary;
	 } else if (arg[i].equals("-v")) {
	    details=null;
	 } else if (arg[i].equals("+n")) {
	    nervous=true;
	 } else if (arg[i].equals("-n")) {
	    nervous=false;
	 } else if (arg[i].equals("-R")) {
	    repeat=-1;
	 } else if (arg[i].equals("+T")) {
	    tests.put("CDS","CDS");
	    tests.put("Crypt","Crypt");
	    tests.put("Vector","Vector");
	    tests.put("Sign","Sign");
	    tests.put("BlindSign","BlindSign");
	 } else if (arg[i].equals("-T")) {
	    tests.clear();
	 } else if (arg[i].equals("+K")) {
	    keys.put("Caesar", "Caesar");
	    keys.put("DES", "DES");
	    keys.put("TriDES", "TriDES");
	    keys.put("Blowfish", "Blowfish");
	    keys.put("RSA", "RSA");
	    keys.put("DH", "DH");
	 } else if (arg[i].equals("-K")) {
	    keys.clear();
	 } else if (arg[i].equals("+M")) {
	    modes.put("ECB", "ECB");
	    modes.put("CBC", "CBC");
	    modes.put("CFB", "CFB");
	    modes.put("OFB", "OFB");
	 } else if (arg[i].equals("-M")) {
	    modes.clear();
	 } else {
	    // the other parameters require a sub-parameter
	    if(i+1 == arg.length) {
	       System.err.println("Syntax error");
	       help();
	    }
	    if (arg[i].equals("+t")) {
	       tests.put(arg[i+1],arg[i+1]);
	    } else if (arg[i].equals("-t")) {
	       tests.remove(arg[i+1]);
	    } else if (arg[i].equals("+k")) {
	       keys.put(arg[i+1],arg[i+1]);
	    } else if (arg[i].equals("-k")) {
	       keys.remove(arg[i+1]);
	    } else if (arg[i].equals("+m")) {
	       modes.put(arg[i+1],arg[i+1]);
	    } else if (arg[i].equals("-m")) {
	       modes.remove(arg[i+1]);
	    } else if (arg[i].equals("-r")) {
	       try {
		  repeat = Integer.parseInt(arg[i+1]);
	       } catch (Exception e) {
		  help();
	       }
	       if(repeat<0)
		  help();
	    } else {
	       help();
	    }
	    i++;
	 }
      }
      
      boolean ok = true;

	{
	   System.out.print("tests=");
	   Enumeration tit=tests.elements();
	   while(tit.hasMoreElements())
	     System.out.print(tit.nextElement()+" ");
	   System.out.println();
	}
	{
	   System.out.print("keys=");
	   Enumeration kit=keys.elements();
	   while(kit.hasMoreElements())
	     System.out.print(kit.nextElement()+" ");
	   System.out.println();
	}
	{
	   System.out.print("modes=");
	   Enumeration mit=modes.elements();
	   while(mit.hasMoreElements())
	     System.out.print(mit.nextElement()+" ");
	   System.out.println();
	}
      if(repeat>0)
	System.out.println("itrations="+repeat);
      else
	System.out.println("itrations=infinite");
      System.out.println("verbose="+(details!=null));
      System.out.println("nervous="+nervous);
      
      for(int r=0; r!=repeat && (ok || !nervous); r++) {

	 System.out.println();
	 System.out.println("=====================================================");
	 System.out.print("== STARTING ROUND "+(r+1));
	 if(repeat>0)
	   System.out.print("/"+repeat);
	 System.out.print(" OF TESTING, ");
	 if(ok) 
	   System.out.print("NO ");
	 System.out.println("ERRORS FOUND");
	 System.out.println("=====================================================");
	 System.out.println();
	 
	 Enumeration kit=keys.elements();
	 while(kit.hasMoreElements() && (ok || !nervous)) {
	    String key=(String)kit.nextElement();
	    ok &= TestKey.test(key,tests,modes, details,summary);
	 }
      }

      if(ok) {
	 summary.println();
	 summary.println("All tests passed");
      } else {
	 summary.println();
	 summary.println("Some tests failed\07\07\07");
      }

      System.exit(ok ? 0 : 1);
      
   }
    
}
