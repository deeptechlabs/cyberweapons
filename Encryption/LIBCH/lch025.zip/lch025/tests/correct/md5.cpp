//
// md5.cxx
// 
// MD5 test data taken from RFC 1321 
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#include <iostream.h>
#include <iomanip.h>
#include <string.h>
#include <chnhash/md5.hpp>

#define BYTES_IN_HASH 16 

int Test0()
{
  const char* t="";
  const u8 exp[BYTES_IN_HASH]={ 0xd4, 0x1d, 0x8c, 0xd9, 0x8f, 0x00, 0xb2, 
				0x04, 0xe9, 
		      0x80, 0x09, 0x98, 0xec, 0xf8, 0x42, 0x7e};
  u8 res[BYTES_IN_HASH];

  MD5 hashor;

  cout <<"Hashing ->"<<t<<"<-"<<endl;
  hashor.ProcessFinalBlock(t,strlen(t));
  hashor.ChainVariables(res);

  cout <<"res=     0x";
  for (int i=0; i<BYTES_IN_HASH; i++)
    cout <<hex<<setw(2)<<setfill('0')<<int(res[i]);
  cout <<endl;

  if ( memcmp(exp,res,BYTES_IN_HASH) )
    {
      cout <<"*****Failed!*****"<<endl;
      return -1;
    }

 cout <<"*****Passed!*****"<<endl;
 return 0;
}


int Test1()
{
  const char* t="a";
  const u8 exp[BYTES_IN_HASH]={ 0x0c, 0xc1, 0x75, 0xb9, 0xc0, 0xf1, 0xb6, 0xa8, 0x31, 0xc3, 0x99, 0xe2, 0x69, 0x77, 0x26, 0x61 };
  u8 res[BYTES_IN_HASH];

  MD5 hashor;

  cout <<"Hashing ->"<<t<<"<-"<<endl;
  hashor.ProcessFinalBlock(t,strlen(t));
  hashor.ChainVariables(res);

  cout <<"res=     0x";
  for (int i=0; i<BYTES_IN_HASH; i++)
    cout <<hex<<setw(2)<<setfill('0')<<int(res[i]);
  cout <<endl;
  if ( memcmp(exp,res,BYTES_IN_HASH) )
    {
      cout <<"*****Failed!*****"<<endl;
      return -1;
    }

 cout <<"*****Passed!*****"<<endl;
 return 0;
}

int Test2()
{
  const char* t="abc";
  const u8 exp[BYTES_IN_HASH]={ 0x90, 0x01, 0x50, 0x98, 0x3c, 0xd2, 0x4f, 0xb0, 0xd6, 0x96, 0x3f, 0x7d, 0x28, 0xe1, 0x7f, 0x72 };
  u8 res[BYTES_IN_HASH];

  MD5 hashor;

  cout <<"Hashing ->"<<t<<"<-"<<endl;
  hashor.ProcessFinalBlock(t,strlen(t));
  hashor.ChainVariables(res);

  cout <<"res=     0x";
  for (int i=0; i<BYTES_IN_HASH; i++)
    cout <<hex<<setw(2)<<setfill('0')<<int(res[i]);
  cout <<endl;

  if ( memcmp(exp,res,BYTES_IN_HASH) )
    {
      cout <<"*****Failed!*****"<<endl;
      return -1;
    }

 cout <<"*****Passed!*****"<<endl;
 return 0;
}

int Test3()
{
  const char* t="message digest";
  const u8 exp[BYTES_IN_HASH]={ 0xf9, 0x6b, 0x69, 0x7d, 0x7c, 0xb7, 0x93, 0x8d, 0x52, 0x5a, 0x2f, 0x31, 0xaa, 0xf1, 0x61, 0xd0 };
  u8 res[BYTES_IN_HASH];

  MD5 hashor;

  cout <<"Hashing ->"<<t<<"<-"<<endl;
  hashor.ProcessFinalBlock(t,strlen(t));
  hashor.ChainVariables(res);

  cout <<"res=     0x";
  for (int i=0; i<BYTES_IN_HASH; i++)
    cout <<hex<<setw(2)<<setfill('0')<<int(res[i]);
  cout <<endl;

  if ( memcmp(exp,res,BYTES_IN_HASH) )
    {
      cout <<"*****Failed!*****"<<endl;
      return -1;
    }

 cout <<"*****Passed!*****"<<endl;
 return 0;
}

int Test4()
{
  const char* t="abcdefghijklmnopqrstuvwxyz";
  const u8 exp[BYTES_IN_HASH]={ 0xc3, 0xfc, 0xd3, 0xd7, 0x61, 0x92, 0xe4, 0x00, 0x7d, 0xfb, 0x49, 0x6c, 0xca, 0x67, 0xe1, 0x3b };
  u8 res[BYTES_IN_HASH];

  MD5 hashor;

  cout <<"Hashing ->"<<t<<"<-"<<endl;
  hashor.ProcessFinalBlock(t,strlen(t));
  hashor.ChainVariables(res);

  cout <<"res=     0x";
  for (int i=0; i<BYTES_IN_HASH; i++)
    cout <<hex<<setw(2)<<setfill('0')<<int(res[i]);
  cout <<endl;

  if ( memcmp(exp,res,BYTES_IN_HASH) )
    {
      cout <<"*****Failed!*****"<<endl;
      return -1;
    }

 cout <<"*****Passed!*****"<<endl;
 return 0;
}

int Test5()
{
  const char* t="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  const u8 exp[BYTES_IN_HASH]={ 0xd1, 0x74, 0xab, 0x98, 0xd2, 0x77, 0xd9, 0xf5, 0xa5, 0x61, 0x1c, 0x2c, 0x9f, 0x41, 0x9d, 0x9f };
  u8 res[BYTES_IN_HASH];

  MD5 hashor;

  cout <<"Hashing ->"<<t<<"<-"<<endl;
  hashor.ProcessFinalBlock(t,strlen(t));
  hashor.ChainVariables(res);

  cout <<"res=     0x";
  for (int i=0; i<BYTES_IN_HASH; i++)
    cout <<hex<<setw(2)<<setfill('0')<<int(res[i]);
  cout <<endl;

  if ( memcmp(exp,res,BYTES_IN_HASH) )
    {
      cout <<"*****Failed!*****"<<endl;
      return -1;
    }

 cout <<"*****Passed!*****"<<endl;
 return 0;
}

int Test6()
{
  char* t="12345678901234567890123456789012345678901234567890123456789012345678901234567890";
  u8 exp[BYTES_IN_HASH]={ 0x57, 0xed, 0xf4, 0xa2, 0x2b, 0xe3, 0xc9, 0x55, 0xac, 0x49, 0xda, 0x2e, 0x21, 0x07, 0xb6, 0x7a };
  u8 res[BYTES_IN_HASH];

  MD5 hashor;
  hashor.Reset();

  cout <<"Hashing ->"<<t<<"<-"<<endl;
  hashor.ProcessMiddleBlock(t);
  hashor.ProcessFinalBlock(t+64,16);
  hashor.ChainVariables(res);

  cout <<"res=     0x";
  for (int i=0; i<BYTES_IN_HASH; i++)
    cout <<hex<<setw(2)<<setfill('0')<<int(res[i]);
  cout <<endl;

  if ( memcmp(exp,res,BYTES_IN_HASH) )
    {
      cout <<"*****Failed!*****"<<endl;
      return -1;
    }

 cout <<"*****Passed!*****"<<endl;
 return 0;
}

int main(int, char**)
{
  int failedATest=0;

  cout <<"Testing the MD5 hash function..."<<endl;
  cout <<endl;

  failedATest|=Test0(); cout <<endl;
  failedATest|=Test1(); cout <<endl;
  failedATest|=Test2(); cout <<endl;
  failedATest|=Test3(); cout <<endl;
  failedATest|=Test4(); cout <<endl;
  failedATest|=Test5(); cout <<endl;
  failedATest|=Test6(); cout <<endl;

  if ( failedATest )
    {
      cout <<"Oh, oh! Failed a test!"<<endl;
      return(-1);
    }

  cout <<"Passed all tests!"<<endl;
  return(0);
}

