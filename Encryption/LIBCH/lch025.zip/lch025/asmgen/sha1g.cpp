//
// sha1g.cpp
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#include "sha1g.hpp"

SHA1AsmGenerator::SHA1AsmGenerator(ostream& os) : SHAAsmGenerator(os, 1)
{
}
