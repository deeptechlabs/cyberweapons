// Copyright (C) 2000 Logi Ragnarsson

package org.logi.crypto.demo;
import org.logi.crypto.*;
import org.logi.crypto.secretshare.*;

import java.io.*;

/**
 * Retrieve a secret shared f.ex. with the ShareSecret program.
 *
 * @see org.logi.crypto.demo.ShareSecret
 */
public class RetrieveSecret extends Crypto{
   
   private static void error(Object msg) {
      if(msg!=null) {
	 System.err.println(msg);
	 System.err.println();
      }
      System.err.println("Use: java org.logi.crypto.demo.RetrieveSecret");
      System.err.println();
      System.err.println("Shares such as those produced by ShareSecret are read from");
      System.err.println("standard in and an attempt is made to retrieve the secret.");
      System.exit(1);
   }
   
   public static void main(String[] arg) throws Exception {
      Crypto.initRandom();

      if(arg.length!=0)
	 error("No parameters expected");

      try {
	 BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
	 SecretShare[] shares;
	 
	   {
	      // Read each line on standard input into the strings array.
	      String[] strings = new String[16];
	      int numStrings = 0;
	      String line = in.readLine();
	      while(line!=null) {
		 strings = ensureArrayLength(strings, numStrings, numStrings+1);
		 strings[numStrings++] = line;
		 line = in.readLine();
	      }
	      
	      // Convert the just-read strings into SecretShare objects
	      shares = new SecretShare[numStrings];
	      for(int i=0; i<numStrings; i++)
		shares[i] = (SecretShare)Crypto.fromString(strings[i]);
	   }
	 
	 // Retreive secret
	 byte[] secret = SecretShare.retrieve(shares);
	 
	 // Print secret
	 System.out.write(secret);
	 
      } catch (Exception e) {
	 error(e);
      }
   }
   
}
