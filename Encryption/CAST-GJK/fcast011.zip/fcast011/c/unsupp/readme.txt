Files I use when testing out the library. Included for your (possible)
interest, but not needed to build or use the library. c128cbc.cpp uses
Crypto++ 2.2.

Leonard Janke (janke@unixg.ubc.ca)
