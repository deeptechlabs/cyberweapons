package org.logi.crypto.test;

import java.io.OutputStream;

/**
 * Anything written to instances of this class
 * is counted and discarded.
 */
public class BitBucket extends OutputStream{
   
   private int count=0;
   
   public BitBucket(){
      super();
   }
   
   public void close(){
   }
   
   public void flush(){
   }
   
   public void write(byte[] buf){
      count += buf.length;
   }
   
   public void write(byte[] buf, int off, int len){
      count += len;
   }
   
   public void write(int x){
      count += 1;
   }
   
   public int getCount(){
      return count;
   }
   
}
