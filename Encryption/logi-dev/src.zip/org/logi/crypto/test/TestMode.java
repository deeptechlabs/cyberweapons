// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.test;
import org.logi.crypto.*;
import org.logi.crypto.keys.*;
import org.logi.crypto.modes.*;

import java.util.Random;
import java.io.*;

/**
 * This application tests the various encryption-mode classes.
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 *
 * @see org.logi.crypto.modes.EncryptSession
 */
public class TestMode extends Crypto{
    
    private TestMode(){}
    
    // Insecure but fast pseud-random number generator
    private static Random rand=new Random();  

    private static void help(PrintWriter writer){
        writer.println("Use: java org.logi.crypto.test.TestKey <key-type> <mode>");
        writer.println("  <key-type> ::= Caesar|DES|TriDES|Blowfish|RSA|DH");
        writer.println("  <mode>     ::= ECB|CBC|CFB|OFB.");
    }

    private static EncryptSession createEncrypt(String mode, CipherKey pub, CipherKey pri, PrintWriter details, PrintWriter summary) throws CryptoException {
        if (mode.equals("ECB")){
            return new EncryptECB(pub);
        } else if (mode.equals("CBC")){
            return new EncryptCBC(pub);
        } else if (mode.equals("CFB")){
            return new EncryptCFB(pri);
        } else if (mode.equals("OFB")){
            return new EncryptOFB(pri,1024);
        }
       
        help(summary);
        return null;
    }
    
    private static DecryptSession createDecrypt(String mode, CipherKey pub, CipherKey pri, PrintWriter details, PrintWriter summary) throws CryptoException {
        if (mode.equals("ECB")){
            return new DecryptECB(pri);
        } else if (mode.equals("CBC")){
            return new DecryptCBC(pri);
        } else if (mode.equals("CFB")){
            return new DecryptCFB(pri);
        } else if (mode.equals("OFB")){
            return new DecryptOFB(pri,1024);
        }
       
        help(summary);
        return null;
    }
    
    private static boolean test(EncryptSession em, DecryptSession dm, int size, PrintWriter details, PrintWriter summary){
       long start=System.currentTimeMillis();
       details.println();
       summary.println("TESTING MODE");
       details.println("Plain/cipher block sizes = "
		       +em.getKey().plainBlockSize()+" B, "
		       +em.getKey().cipherBlockSize()+" B");
       details.println("Buffer size = "+TestIterate.metricString(size,1024)+"B");

       Random rand = new Random();
       byte[] plain1  = new byte[size];
       byte[] plain2  = new byte[size];
       byte[] cipher = new byte[8];
       rand.nextBytes(plain1);

       details.print("Encrypting 0%\r");
       int i=0;
       int j=0;
       while(i<plain1.length){
	  // plain1[0..i-1] has been encrypted and put in cipher[0..j-1]
	  int n = Math.min(rand.nextInt()%32+32, plain1.length-i);
	  byte[] t1;
	  if(i+n<plain1.length) {
	     t1 = em.encrypt(plain1,i,n);
	  } else {
	     t1 = em.flush(plain1,i,n);
	  }
	  i+=n;
	  cipher = ensureArrayLength(cipher, j, j+t1.length);
	  System.arraycopy(t1,0, cipher,j, t1.length);
	  j+=t1.length;
          details.print("Encrypting "+(100*i/plain1.length)+"%\r");
	  details.flush();
       }
       cipher = trimArrayLength(cipher, j);
       details.println();
       
       details.print("Decrypting 0%\r");
       i=0;
       j=0;
       while(j<cipher.length){
	  // cipher[0..j-1] has been encrypted and put in plain2[0..i-1]
	  int n = Math.min(rand.nextInt()%32+32, cipher.length-j);
	  byte[] t1 = dm.decrypt(cipher,j,n);
	  plain2 = ensureArrayLength(plain2, i, i+t1.length);  // to take random padding if any
	  System.arraycopy(t1,0, plain2,i, t1.length);
	  j+=n;
	  i+=t1.length;
          details.print("Decrypting "+(100*j/cipher.length)+"%\r");
	  details.flush();
       }
       details.println();
       
       details.print("Checking 0%\r");
       details.flush();
       for(i=0; i<plain1.length; i++) {
	  if (plain1[i]!=plain2[i]) {
	     summary.println("Error at offset "+i);
	     return false;
	  }
	  if((plain1.length-i+1)%Math.max(1,(size/100)) == 0) {
	     details.print("Checking "+(100*j/cipher.length)+"%\r");
	     details.flush();
	  }
       }
       
       long stop=System.currentTimeMillis();
       details.println("\nTime="+(stop-start)+"ms");
       return true;
    }
    
    public static boolean test(String keyType, String mode, PrintWriter details, PrintWriter summary) throws Exception {
        if(details==null)
	    details=new PrintWriter(new BitBucket());

        summary.println("============================================================");
        summary.println("TESTING "+keyType+" KEYS IN "+mode+" MODE");

        if(keyType.equals("DH")) {
	   if(mode.equals("CFB") || mode.equals("OFB")) {
	      summary.println("DH is a probabilistic encryption algorithm and");
	      summary.println("can't be used in OFB or CFB mode. This is not a bug.");
	      return true;
	   }
	}
       
        KeyPair kp = TestKey.createKeys(keyType,details,summary);
        if (kp==null)
            return false;
        
        // For asymmetric ciphers, pub will be a public key. Other wise pub==pri.
        Key pub = kp.getPublic();
        Key pri = kp.getPrivate();
        
        EncryptSession em = createEncrypt(mode,(CipherKey)pub,(CipherKey)pri,details,summary);
        if (em==null)
            return false;
        DecryptSession dm = createDecrypt(mode,(CipherKey)pub,(CipherKey)pri,details,summary);
        if (em==null)
            return false;
        
        int size = pub.isPrivate() ? 16384 : 4096;
        if (mode.equals("CFB"))
	    // CFB takes too long
	    size /= Math.max(1,em.getKey().getSize()/8);
        boolean ok = test(em,dm,size,details,summary);
       
        em.close();
        dm.close();
        
        return ok;
    }
    
    public static void main(String[] arg) throws Exception {
        Crypto.initRandom();
        
        PrintWriter w = new PrintWriter(System.out, true);
        if(arg.length<2){
            help(w);
            return;
        }

        boolean ok = test(arg[0], arg[1], w,w);
        System.out.println();
        if(ok)
            System.out.println("All tests passed");
        else
            System.out.println("Some tests failed");
       
       // To give the Producer threads a chance to die by them selves.
       // Without this, they'll die because of their daemon status, but we
       // want to test their termination logic.
       Thread.sleep(100); 
    }

}
