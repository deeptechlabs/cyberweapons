// 
// cast128g.cpp
//
// Copyright (C) 1997 Peter Gutmann (pgut001@cs.auckland.ac.nz),
//                    Leonard Janke (janke@unixg.ubc.ca),
//                    and Vesa Karvonen (vkarvone@mail.student.oulu.fi).

#include <iostream.h>
#include <iomanip.h>
#include <stdlib.h>
#include "cast128g.hpp"

const DWordRegister& CAST128AsmGenerator::K=ebp;

const DWordRegister& CAST128AsmGenerator::cnt=ecx;
const ByteRegister& CAST128AsmGenerator::cntl=cl;
const ByteRegister& CAST128AsmGenerator::cnth=ch;

const DWordRegister& CAST128AsmGenerator::rx0=eax;
const ByteRegister& CAST128AsmGenerator::rx0l=al;
const ByteRegister& CAST128AsmGenerator::rx0h=ah;

const DWordRegister& CAST128AsmGenerator::rx1=edx;
const ByteRegister& CAST128AsmGenerator::rx1l=dl;
const ByteRegister& CAST128AsmGenerator::rx1h=dh;

const DWordRegister& CAST128AsmGenerator::rx2=ebx;
const ByteRegister& CAST128AsmGenerator::rx2l=bl;
const ByteRegister& CAST128AsmGenerator::rx2h=bh;

const CPtr CAST128AsmGenerator::S1("S1"); 
const CPtr CAST128AsmGenerator::S2("S2"); 
const CPtr CAST128AsmGenerator::S3("S3"); 
const CPtr CAST128AsmGenerator::S4("S4"); 

void CAST128AsmGenerator::Copyright()
{
  Comment("Copyright (C) 1996-7 by Peter Gutmann (pgut001@cs.auckland.ac.nz),");
  Comment("                        Leonard Janke (janke@unixg.ubc.ca), and");
  Comment("                        Vesa Karvonen (vkarvone@mail.student.oulu.fi).");

}

void CAST128AsmGenerator::Swap(const DWordRegister*& x, const DWordRegister*& y)
{
  const DWordRegister* temp=x;
  x=y;
  y=temp;
}

CAST128AsmGenerator::CAST128AsmGenerator(ostream& os) : 
  AsmGenerator(os), src(&esi), dst(&edi)
{
  CPU=486;
}

void CAST128AsmGenerator::Externals()
{
  DeclareExternal(S1,dword,256);
  DeclareExternal(S2,dword,256);
  DeclareExternal(S3,dword,256);
  DeclareExternal(S4,dword,256);
}

void CAST128AsmGenerator::Link(int n, OpPtr op1, OpPtr op2, OpPtr op3, 
                               LinkEnum linkType)  
{
  Comment("ooooooo");
  Section("link",n);
  Comment("ooooooo");

  Mov(rx0,K,4*n);	
  if ( linkType!=top )
    Xor(*dst,rx1);  // left over from previous link 
  Mov(cntl,K,4*(16+n));
  if ( linkType!=top ) 
    Swap(src,dst);

  (this->*op3)(rx0,*src);	
  Add(cntl,16);

  Rol(rx0,cntl);

  Xor(rx1,rx1); 
  Xor(cnt,cnt);

  Mov(rx1l,rx0h);
  Mov(cntl,rx0l);

  Shr(rx0,16);
  Xor(rx2,rx2);

  Mov(rx2l,rx0h);
  Mov(rx1,S1,4,rx1);

  And(rx0,0xffl);
  Mov(cnt,S2,4,cnt);

  (this->*op1)(rx1,cnt);
  Mov(rx2,S3,4,rx2);

  (this->*op2)(rx1,rx2);
  Mov(rx0,S4,4,rx0); 

  (this->*op3)(rx1,rx0);

  if ( linkType==bottom )
    Xor(*dst,rx1);       
  // else leave the xor for the next link
}

void CAST128AsmGenerator::Startup()
{
  os <<endl;

  Push(ebp);
  Push(esi);
  Push(edi);
  Push(ebx);
  if ( callingConvention==WATCOMREGISTER )
    Push(ecx);
  
  switch ( callingConvention )
  {
  case WATCOMREGISTER:
    Mov(K,eax);
    Push(edx);
    break;
  case FASTCALL: 
    Mov(K,ecx);
    Push(edx);
    break;
  case CDECL:
    Mov(K,esp,4+16);
    Mov(edx,esp,8+16);
    break;
  default:
    cerr <<"Unrecognized calling convention"<<endl;
    exit(-1);
  }

  Mov(*dst,edx,0);
  Mov(*src,edx,4);
  BSwap(*src);
  BSwap(*dst);

  os <<endl;
}

void CAST128AsmGenerator::Cleanup()
{
  Swap(src,dst);

  BSwap(*src);
  BSwap(*dst);
  
  switch ( callingConvention )
  {
  case WATCOMREGISTER: 
  case FASTCALL:
    Pop(edx);
    break;
  case CDECL:
    Mov(edx,esp,8+16);
    break;
  default:
    cerr <<"Unrecognized calling convention"<<endl;
    exit(-1);
  }

  Mov(edx,0,*src);
  Mov(edx,4,*dst);
  os <<endl;
  if ( callingConvention==WATCOMREGISTER )
    Pop(ecx);
  Pop(ebx);
  Pop(edi);
  Pop(esi);
  Pop(ebp);
  os <<endl;
  Ret();
}
