// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.keys;

import org.logi.crypto.*;

/**
 * Information used for blinding a fingerprint and unblinding a signature
 * for a particular keypair. Only use a blinding factor once!

 * @version 1.1.0
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a> (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public abstract class BlindingFactor extends Crypto {
}
