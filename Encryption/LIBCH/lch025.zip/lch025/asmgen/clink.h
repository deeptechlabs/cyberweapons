/*
 * clink.h
 *
 * This software was written by Leonard Janke (janke@unixg.ubc.ca)
 * in 1996-7 and is entered, by him, into the public domain.
 */

#ifndef _CLINK_H
#define _CLINK_H

#ifndef U32DEFINED
typedef unsigned long u32;
#define U32DEFINED
#endif

#ifdef __cplusplus
extern "C" {
#endif

#ifdef _MSC_VER
void __fastcall MD5Transform(u32* H, const u32* X); 
void __fastcall RIPEMD128Transform(u32* H, const u32* X);
void __fastcall RIPEMD160Transform(u32* H, const u32* X);
void __fastcall SHA0Transform(u32* H, const u32* X); 
void __fastcall SHA1Transform(u32* H, const u32* X); 
#elif defined(__WATCOMC__) && defined(__SW_3S)
void __cdecl MD5Transform(u32* H, const u32* X); 
void __cdecl RIPEMD128Transform(u32* H, const u32* X);
void __cdecl RIPEMD160Transform(u32* H, const u32* X);
void __cdecl SHA0Transform(u32* H, const u32* X); 
void __cdecl SHA1Transform(u32* H, const u32* X); 
#else
void MD5Transform(u32* H, const u32* X); 
void RIPEMD128Transform(u32* H, const u32* X);
void RIPEMD160Transform(u32* H, const u32* X);
void SHA0Transform(u32* H, const u32* X); 
void SHA1Transform(u32* H, const u32* X); 
#endif

#ifdef __cplusplus
}
#endif

#endif
