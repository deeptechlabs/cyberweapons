//
// chnhash.hpp
//
// Abstract base class for chain hash functions
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#ifndef _CHNHASH_HPP
#define _CHNHASH_HPP

#include <chnhash/chtypes.h>

class ChainHash 
{
protected:
  u64 _bitCount;

  int _bitsPerBlock;
  int _bitsInHash;
public:
  ChainHash(const int bitsPerBlock, const int bitsInHash);
  virtual ~ChainHash();

  inline int bitsPerBlock() const { return _bitsPerBlock; }
  inline int bitsInHash() const { return _bitsInHash; }

  virtual void ProcessMiddleBlock(const void* block, const int aligned=0)=0;
  virtual void ProcessFinalBlock(const void* block, const int bytes)=0;

  virtual void Reset();

  virtual void ChainVariables(void* buffer) const=0;
};

#endif
