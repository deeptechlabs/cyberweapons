//
// rmd128g.cpp
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#include <stdlib.h>
#include <iomanip.h>
#include "a2r128.hpp"
#include "rmd128g.hpp"

RMD128AsmGenerator::RMD128AsmGenerator(ostream& os) : AsmGenerator(os)
{
}

void RMD128AsmGenerator::Startup()
{
  Push(ebp);
  Push(esi);
  Push(edi);
  Push(ebx);
  switch ( callingConvention )
  {
  case WATCOMREGISTER:
    Push(ecx);
    Push(eax);
    Mov(esi,edx);
    break;
  case FASTCALL:
    Mov(eax,ecx);
    Push(ecx);
    Mov(esi,edx);
    break;
  case CDECL:
    Mov(eax,esp,4+16);
    Mov(esi,esp,8+16);
    break;
  default:
    cerr <<"Unrecognized calling convention"<<endl;
    exit(-1);
  }

  Mov(edx,eax,12);
  Mov(ecx,eax,8);
  Mov(ebx,eax,4);
  Mov(eax,eax,0);

  Push(edx);
  Push(ecx);
  Push(ebx);
  Push(eax);
}

void RMD128AsmGenerator::PrintSaveLeftResult()
{
  Push(edx);
  Push(ecx);
  Push(ebx);
  Push(eax);
}

void RMD128AsmGenerator::PrintReload()
{
  Mov(edx,esp,28);
  Mov(ecx,esp,24);
  Mov(ebx,esp,20);
  Mov(eax,esp,16);
}

void RMD128AsmGenerator::PrintCombineHalves()
{
  Push(ebx);

#define DPOS 32
#define CPOS 28
#define BPOS 24
#define APOS 20
#define DLPOS 16
#define CLPOS 12
#define BLPOS 8
#define ALPOS 4
#define BRPOS 0

  // T=B+cl+dr;
  // ebx=C+dl+ar;
  // eax=T;
  // edx=A+bl+cr;
  // ecx=D+al+br;

  Mov(edi,edx);     // T=dr
  Mov(ebp,esp,CLPOS);
 
  Add(edi,ebp);     // T+=cl
  Mov(ebp,esp,BPOS);

  Add(edi,ebp);     // T+=B
  Mov(ebx,eax);     // ebx=ar

  Mov(eax,edi);     // eax=T
  Mov(ebp,esp,DLPOS);

  Add(ebx,ebp);     // ebx+=dl
  Mov(ebp,esp,CPOS);  

  Add(ebx,ebp);     // ebx+=C
  Mov(edx,ecx);     // edx=cr
 
  Mov(ecx,esp,BRPOS);   // ecx=br
  Mov(ebp,esp,BLPOS);   

  Add(edx,ebp);     // edx+=bl
  Mov(ebp,esp,APOS);

  Add(edx,ebp);     // edx+=A
  Mov(ebp,esp,DPOS);

  Add(ecx,ebp);     // ecx+=D
  Mov(ebp,esp,ALPOS);

  Add(ecx,ebp);     // ecx+=al
  Add(esp,36);

  // T=B+cl+dr;
  // ebx=C+dl+ar;
  // eax=T;
  // edx=A+bl+cr;
  // ecx=D+al+br;
}

void RMD128AsmGenerator::Body()
{
  Comment("left half");
  PrintLeftRound1();
  PrintLeftRound2();
  PrintLeftRound3();
  PrintLeftRound4();

  Comment("save left result");
  PrintSaveLeftResult();
  Comment("reloading chain variables");
  PrintReload();

  Comment("right half");
  PrintRightRound1();
  PrintRightRound2();
  PrintRightRound3();
  PrintRightRound4();

  Comment("combine");
  PrintCombineHalves();
}

void RMD128AsmGenerator::Cleanup()
{
  switch ( callingConvention )
  {
  case WATCOMREGISTER:
  case FASTCALL:
    Mov(edi,esp,0);
    Add(esp,4);
    break;
  case CDECL:
    Mov(edi,esp,4+16);
    break;
  default:
    cerr <<"Unrecognized calling convention"<<endl;
    exit(-1);
  }

  Mov(edi,0,eax);
  Mov(edi,4,ebx);
  Mov(edi,8,ecx);
  Mov(edi,12,edx);
  os <<endl;
  if ( callingConvention==WATCOMREGISTER )
    Pop(ecx);
  Pop(ebx);
  Pop(edi);
  Pop(esi);
  Pop(ebp);
  os <<endl;
  Ret();
}

const u32 RMD128AsmGenerator::KL[64]={
  0x00000000, 0x00000000, 0x00000000, 0x00000000,
  0x00000000, 0x00000000, 0x00000000, 0x00000000,
  0x00000000, 0x00000000, 0x00000000, 0x00000000,
  0x00000000, 0x00000000, 0x00000000, 0x00000000,
  0x5a827999, 0x5a827999, 0x5a827999, 0x5a827999,
  0x5a827999, 0x5a827999, 0x5a827999, 0x5a827999,
  0x5a827999, 0x5a827999, 0x5a827999, 0x5a827999,
  0x5a827999, 0x5a827999, 0x5a827999, 0x5a827999,
  0x6ed9eba1, 0x6ed9eba1, 0x6ed9eba1, 0x6ed9eba1,
  0x6ed9eba1, 0x6ed9eba1, 0x6ed9eba1, 0x6ed9eba1,
  0x6ed9eba1, 0x6ed9eba1, 0x6ed9eba1, 0x6ed9eba1,
  0x6ed9eba1, 0x6ed9eba1, 0x6ed9eba1, 0x6ed9eba1,
  0x8f1bbcdc, 0x8f1bbcdc, 0x8f1bbcdc, 0x8f1bbcdc,
  0x8f1bbcdc, 0x8f1bbcdc, 0x8f1bbcdc, 0x8f1bbcdc,
  0x8f1bbcdc, 0x8f1bbcdc, 0x8f1bbcdc, 0x8f1bbcdc,
  0x8f1bbcdc, 0x8f1bbcdc, 0x8f1bbcdc, 0x8f1bbcdc 
};


const int RMD128AsmGenerator::rl[64]={
  0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
  7, 4, 13, 1, 10, 6, 15, 3, 12, 0, 9, 5, 2, 14, 11, 8,
  3, 10, 14, 4, 9, 15, 8, 1, 2, 7, 0, 6, 13, 11, 5, 12,
  1, 9, 11, 10, 0, 8, 12, 4, 13, 3, 7, 15, 14, 5, 6, 2
};

const int RMD128AsmGenerator::sl[64]={
  11, 14, 15, 12, 5, 8, 7, 9, 11, 13, 14, 15, 6, 7, 9, 8,
  7, 6, 8, 13, 11, 9, 7, 15, 7, 12, 15, 9, 11, 7, 13, 12,
  11, 13, 6, 7, 14, 9, 13, 15, 14, 8, 13, 6, 5, 12, 7, 5,
  11, 12, 14, 15, 14, 15, 9, 8, 9, 14, 5, 6, 8, 6, 5, 12
};


void RMD128AsmGenerator::PrintLeftRound1()
{
  a2r128 reg;

  Mov(edi,reg[C]);
  Mov(ebp,esi,rl[0]*4);

  for (int i=0; i<16; i++)
    {
      // a=(a+b^d^c+M)<<<s
      // 4 cycles
      int subround=i;

      Subround(subround);

      Xor(edi,reg[D]);
      Add(reg[A],ebp);

      Xor(edi,reg[B]);
      Mov(ebp,esi,rl[subround+1]*4);

      Add(reg[A],edi);
      Mov(edi,reg[B]);

      Rol(reg[A],sl[i]);
      os <<endl;
      reg.Circulate();
    }
}

void RMD128AsmGenerator::PrintLeftRound2()
{
  a2r128 reg;

  Xor(edi,reg[D]);
  for (int i=16; i<32; i+=2)
    {
      // a=(a+d^(b&(d^c))+K+M)<<<s
      int subround=i;

      Subround(subround);

      And(edi,reg[B]);
      Lea(reg[A],reg[A],1,ebp,KL[subround]);

      Xor(edi,reg[D]);
      Mov(ebp,reg[B]);

      Add(reg[A],edi);
      Mov(edi,esi,rl[subround+1]*4);

      Rol(reg[A],sl[subround]);
      os <<endl;
      reg.Circulate();

      // a=(a+d^(b&(d^c))+K+M)<<<s

      subround++;
      Subround(subround);

      Xor(ebp,reg[D]);
      Lea(reg[A],reg[A],1,edi,KL[subround]);

      And(ebp,reg[B]);
      Mov(edi,reg[B]);

      Xor(ebp,reg[D]);
      if ( subround !=31 )
        Xor(edi,reg[C]);
      else
        Xor(edi,-1);

      Add(reg[A],ebp);
      Mov(ebp,esi,rl[subround+1]*4);

      Rol(reg[A],sl[subround]);
      os <<endl;
      reg.Circulate();
    }
}

void RMD128AsmGenerator::PrintLeftRound3()
{
  a2r128 reg; 

  for (int i=32; i<48; i+=2)
    {
      // a=(a+d^(b|~c)+K+M)<<<s
      int subround=i;

      Subround(subround);

      Or(edi,reg[B]);
      Lea(reg[A],reg[A],1,ebp,KL[subround]);

      Xor(edi,reg[D]);
      Mov(ebp,reg[B]);

      Add(reg[A],edi);
      Mov(edi,esi,rl[subround+1]*4);

      Rol(reg[A],sl[subround]);
      os <<endl;
      reg.Circulate();

      // a=(a+d^(b|~c)+K+M)<<<s
      subround++;

      Subround(subround);
      Xor(ebp,-1);
      Lea(reg[A],reg[A],1,edi,KL[subround]);

      Or(ebp,reg[B]);
      Mov(edi,reg[B]);

      Xor(ebp,reg[D]);
      if ( subround != 47 )
        Xor(edi,-1);

      Add(reg[A],ebp);
      Mov(ebp,esi,rl[subround+1]*4);

      Rol(reg[A],sl[subround]);
      os <<endl;
      reg.Circulate();
    }
}
 
void RMD128AsmGenerator::PrintLeftRound4()
{
  a2r128 reg; 

  for (int i=48; i<64; i++)
    {
      // a=(a+c^(d&(b^c))+K+M)<<<s 

      Subround(i);
      Xor(edi,reg[B]);
      Mov(ebp,esi,rl[i]*4);

      And(edi,reg[D]);
      Add(reg[A],ebp);

      Xor(edi,reg[C]);
      Add(reg[A],long(KL[i]));

      Add(reg[A],edi);
      Mov(edi,reg[B]);

      Rol(reg[A],sl[i]);
      os <<endl;
      reg.Circulate();
    }
}

const u32 RMD128AsmGenerator::KR[64]={
  0x50a28be6, 0x50a28be6, 0x50a28be6, 0x50a28be6,
  0x50a28be6, 0x50a28be6, 0x50a28be6, 0x50a28be6,
  0x50a28be6, 0x50a28be6, 0x50a28be6, 0x50a28be6,
  0x50a28be6, 0x50a28be6, 0x50a28be6, 0x50a28be6,
  0x5c4dd124, 0x5c4dd124, 0x5c4dd124, 0x5c4dd124,
  0x5c4dd124, 0x5c4dd124, 0x5c4dd124, 0x5c4dd124,
  0x5c4dd124, 0x5c4dd124, 0x5c4dd124, 0x5c4dd124,
  0x5c4dd124, 0x5c4dd124, 0x5c4dd124, 0x5c4dd124,
  0x6d703ef3, 0x6d703ef3, 0x6d703ef3, 0x6d703ef3,
  0x6d703ef3, 0x6d703ef3, 0x6d703ef3, 0x6d703ef3,
  0x6d703ef3, 0x6d703ef3, 0x6d703ef3, 0x6d703ef3,
  0x6d703ef3, 0x6d703ef3, 0x6d703ef3, 0x6d703ef3,
  0x00000000, 0x00000000, 0x00000000, 0x00000000,
  0x00000000, 0x00000000, 0x00000000, 0x00000000,
  0x00000000, 0x00000000, 0x00000000, 0x00000000,
  0x00000000, 0x00000000, 0x00000000, 0x00000000
};

const int RMD128AsmGenerator::rr[64]={
  5, 14, 7, 0, 9, 2, 11, 4, 13, 6, 15, 8, 1, 10, 3, 12,
  6, 11, 3, 7, 0, 13, 5, 10, 14, 15, 8, 12, 4, 9, 1, 2,
  15, 5, 1, 3, 7, 14, 6, 9, 11, 8, 12, 2, 10, 0, 4, 13,
  8, 6, 4, 1, 3, 11, 15, 0, 5, 12, 2, 13, 9, 7, 10, 14
};

const int RMD128AsmGenerator::sr[64]={
  8, 9, 9, 11, 13, 15, 15, 5, 7, 7, 8, 11, 14, 14, 12, 6,
  9, 13, 15, 7, 12, 8, 9, 11, 7, 7, 12, 7, 6, 15, 13, 11,
  9, 7, 15, 11, 8, 6, 6, 14, 12, 13, 5, 14, 13, 13, 7, 5, 
  15, 5, 8, 11, 14, 14, 6, 14, 6, 9, 12, 9, 12, 5, 15, 8 
};

void RMD128AsmGenerator::PrintRightRound1()
{
  a2r128 reg;

  Mov(edi,reg[C]);
  Mov(ebp,esi,rr[0]*4);
  
  for (int i=0; i<16; i+=2)
    {
      // a=(a+c^(d&(b^c))+K+M)<<<s 

      int subround=i;
      Subround(subround);

      Xor(edi,reg[B]);
      Lea(reg[A],reg[A],1,ebp,KR[i]);

      And(edi,reg[D]);
      Mov(ebp,reg[B]);

      Xor(edi,reg[C]);
      Nop();

      Add(reg[A],edi);
      Mov(edi,esi,rr[subround+1]*4);

      Rol(reg[A],sr[i]);
      os <<endl;
      reg.Circulate();

      // a=(a+c^(d&(b^c))+K+M)<<<s 

      subround++;
      Subround(subround);

      Xor(ebp,reg[B]);
      Lea(reg[A],reg[A],1,edi,KR[subround]);

      And(ebp,reg[D]);
      Mov(edi,reg[B]);

      Xor(ebp,reg[C]);
      if ( subround!=15 )
        Nop();
      else
        Xor(edi,-1);

      Add(reg[A],ebp);
      Mov(ebp,esi,rr[subround+1]*4);

      Rol(reg[A],sr[subround]);
      os <<endl;
      reg.Circulate();
    }
}

void RMD128AsmGenerator::PrintRightRound2()
{
  a2r128 reg; 

  for (int i=16; i<32; i+=2)
    {
      // a=(a+d^(b|~c)+K+M)<<<s
      int subround=i;

      Subround(subround);

      Or(edi,reg[B]);
      Lea(reg[A],reg[A],1,ebp,KR[subround]);

      Xor(edi,reg[D]);
      Mov(ebp,reg[B]);

      Add(reg[A],edi);
      Mov(edi,esi,rr[subround+1]*4);

      Rol(reg[A],sr[subround]);
      os <<endl;
      reg.Circulate();

      // a=(a+d^(b|~c)+K+M)<<<s
      subround++;

      Subround(subround);
      Xor(ebp,-1);
      Lea(reg[A],reg[A],1,edi,KR[subround]);

      Or(ebp,reg[B]);
      Mov(edi,reg[B]);

      Xor(ebp,reg[D]);
      if ( subround != 31 )
        Xor(edi,-1);
      else
        Xor(edi,reg[C]);

      Add(reg[A],ebp);
      Mov(ebp,esi,rr[subround+1]*4);

      Rol(reg[A],sr[subround]);
      os <<endl;
      reg.Circulate();
    }
}

void RMD128AsmGenerator::PrintRightRound3()
{
  a2r128 reg;

  for (int i=32; i<48; i+=2)
    {
      // a=(a+d^(b&(d^c))+K+M)<<<s
      int subround=i;

      Subround(subround);

      And(edi,reg[B]);
      Lea(reg[A],reg[A],1,ebp,KR[subround]);

      Xor(edi,reg[D]);
      Mov(ebp,reg[B]);

      Add(reg[A],edi);
      Mov(edi,esi,rr[subround+1]*4);

      Rol(reg[A],sr[subround]);
      os <<endl;
      reg.Circulate();

      // a=(a+d^(b&(d^c))+K+M)<<<s

      subround++;
      Subround(subround);

      Xor(ebp,reg[D]);
      Lea(reg[A],reg[A],1,edi,KR[subround]);

      And(ebp,reg[B]);
      Mov(edi,reg[B]);

      Xor(ebp,reg[D]);
      if ( subround !=47 )
        Xor(edi,reg[C]);

      Add(reg[A],ebp);
      Mov(ebp,esi,rr[subround+1]*4);

      Rol(reg[A],sr[subround]);
      os <<endl;
      reg.Circulate();
    }
}
 
void RMD128AsmGenerator::PrintRightRound4()
{
  a2r128 reg; 

  for (int i=48; i<64; i++)
    {
      // a=(a+b^d^c+M)<<<s
      int subround=i;

      Subround(subround);
      Xor(edi,reg[D]);
      Add(reg[A],ebp);

      Xor(edi,reg[B]);
      if ( subround != 63 )
        Mov(ebp,esi,rr[subround+1]*4);

      Add(reg[A],edi);
      Mov(edi,reg[B]);

      Rol(reg[A],sr[subround]);
      os <<endl;
      reg.Circulate();
    }
}

