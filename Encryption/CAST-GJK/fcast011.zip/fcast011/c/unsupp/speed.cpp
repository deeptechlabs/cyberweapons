#include "cast128.h"

#include <iostream.h>
#include <iomanip.h>
#include <string.h>
#include "gettsc.inl"

const int blocks=384;

void main()
{
  int i;
  LONG K[ CAST_KEYSIZE ];
  BYTE key[ CAST_USERKEY_SIZE ] =
{ 0x01, 0x23, 0x45, 0x67, 0x12, 0x34, 0x56, 0x78,
  0x23, 0x45, 0x67, 0x89, 0x34, 0x56, 0x78, 0x9A };
  BYTE iv[CAST_BLOCKSIZE]={ 0xef, 0xcd, 0xab, 0x89, 0x67, 0x45, 0x23, 0x01 };
  BYTE data[ blocks*CAST_BLOCKSIZE ];


  memset(data,0,blocks*CAST_BLOCKSIZE);
  castKeyInit( K,key );
  
  unsigned long start1, stop1, start2, stop2;
 
  unsigned long accumulate=0ul;
 
  // get S-Boxes into the cache

  for (i=0; i<256; i++)
    accumulate^=S1[i];
  for (i=0; i<256; i++)
    accumulate^=S2[i];
  for (i=0; i<256; i++)
    accumulate^=S3[i];
  for (i=0; i<256; i++)
    accumulate^=S4[i];

  for (i=0; i<3; i++)
  {
    GetTSC(start1);
    castEncryptCBC(data,data,blocks*CAST_BLOCKSIZE,K,iv);
    GetTSC(stop1);
    GetTSC(start2);
    castEncryptCBC(data,data,blocks*CAST_BLOCKSIZE,K,iv);
    castEncryptCBC(data,data,blocks*CAST_BLOCKSIZE,K,iv);
    GetTSC(stop2);
  }

  cout <<"encrypt rate="<<(((stop2-start2)-(stop1-start1))/(blocks*8.0))<<" cycles/byte"<<endl;

  for (i=0; i<3; i++)
  {
    GetTSC(start1);
    castDecryptCBC(data,data,blocks*CAST_BLOCKSIZE,K,iv);
    GetTSC(stop1);
    GetTSC(start2);
    castDecryptCBC(data,data,blocks*CAST_BLOCKSIZE,K,iv);
    castDecryptCBC(data,data,blocks*CAST_BLOCKSIZE,K,iv);
    GetTSC(stop2);
  }

  cout <<"decrypt rate="<<(((stop2-start2)-(stop1-start1))/(blocks*8.0))<<" cycles/byte"<<endl;
}
