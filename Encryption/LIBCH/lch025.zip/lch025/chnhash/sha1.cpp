//
// sha1.cxx
//
// The NIST/NSA's Secure Hash Algorithm as defined in FIPS 180-1
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#include <string.h>
#include <iostream.h>
#include <iomanip.h>
#include "sha1.hpp"
#include "chmisc.hpp"
#include "clink.h"

SHA1::SHA1() : SHA()
{
}

SHA1::~SHA1()
{
}

void SHA1::Compress(const void* iv, const void* block, void* result)
{
  u32 Block[16];
  u32 Result[5];

  memcpy(Result,iv,20);
  CHMisc::MemSwap(Result,5);

  memcpy(Block,block,64);

  SHA1Transform(Result,Block);

  CHMisc::MemSwap(Result,5);
  memcpy(result,Result,20);
}

void SHA1::Compress(const u32* iv, const u32* block, u32* result)
{
  memcpy(result,iv,20);
  SHA1Transform(result,block);
}

void SHA1::ProcessBlock(const u32* block)
{
  SHA1Transform(H,block);
}
