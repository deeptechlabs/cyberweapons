//
// rmd160.hpp
//
// This algorithm is due to H. Dobbertin, A. Bosselaers, and Bart Preneel,
// and is defined in _RIPE-MD160:_A_Strengthened_Version_of_RIPEMD_
// available at ftp://ftp.esat.kuleuven.ac.be/pub/COSIC/bosselae/ripemd/.
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#ifndef _RMD160_HPP
#define _RMD160_HPP

#include <chnhash/md4ish.hpp>

class RIPEMD160 : public MD4ish 
{
 protected:
  void ProcessBlock(const u32* block);
 public:
  RIPEMD160();
  ~RIPEMD160();
 
  static void Compress(const u32* iv, const u32* block, u32* result);
  static void Compress(const void* iv, const void* block, void* result);

  void Reset();

  static const u32 H0;
  static const u32 H1;
  static const u32 H2;
  static const u32 H3;
  static const u32 H4;
};     

#endif
