//
// cbcdec.cpp
//
// CBC decryption mode for CAST
//
// Copyright (C) 1997 by Leonard Janke (janke@unixg.ubc.ca)

#include <stdlib.h>
#include <iostream.h>
#include <iomanip.h>

#include "cbcdec.hpp"

// gnu 2.7.2 dies on an internal bug for this code without these macros:
// *puke*
 
#if defined(__GNUC__)
#define SHOULD_BE_K ebp  
#else
#define SHOULD_BE_K K  
#endif

const char* CAST128CBCDecryptAsmGenerator::loopBeginLabel="CAST128CBCDecryptLoop";

CAST128CBCDecryptAsmGenerator::CAST128CBCDecryptAsmGenerator(ostream& os)
 : CAST128DecryptAsmGenerator(os)
{
}

void CAST128CBCDecryptAsmGenerator::Body()
{
  Label(loopBeginLabel);
  LoopBegin();
  CAST128DecryptAsmGenerator::Body();
  Comment("loop end");
  LoopEnd();
}

void CAST128CBCDecryptAsmGenerator::Startup()
{
  Comment("startup");
  Push(ebp);
  Push(esi);
  Push(edi);
  if ( callingConvention != WATCOMREGISTER )
    Push(ebx);
 
  os <<endl;

  // the stack will be organized as follows:
  //
  // Watcom Register
  // ===============
  //
  // esp+44 iv
  // esp+40 return address
  // esp+36 saved ebp
  // esp+32 saved esi
  // esp+28 saved edi
  // esp+24 next iv R
  // esp+20 next iv L
  // esp+16 this iv R
  // esp+12 this iv L
  // esp+8  out
  // esp+4  in
  // esp+0  counter
  //
  // Microsoft's fastcall
  // ====================
  //
  // esp+56 iv
  // esp+52 key
  // esp+48 (length in)
  // esp+44 return address
  // esp+40 saved ebp
  // esp+36 saved esi
  // esp+32 saved edi
  // esp+28 saved ebx
  // esp+24 next iv R
  // esp+20 next iv L
  // esp+16 this iv R
  // esp+12 this iv L
  // esp+8  out
  // esp+4  in
  // esp+0  counter
  //
  // cdecl
  // =====
  //
  // esp+56 iv
  // esp+52 key
  // esp+48 (length in) 
  // esp+44 out 
  // esp+40 in
  // esp+36 return address
  // esp+32 saved ebp
  // esp+28 saved esi
  // esp+24 saved edi
  // esp+20 saved ebx
  // esp+16 next iv R
  // esp+12 next iv L
  // esp+8  this iv R
  // esp+4  this iv L
  // esp+0  counter

  switch ( callingConvention )
  {
  // when adding new calling conventions be sure that
  // ebx counts the initial byte count
  // eax contains in and
  // edx contains out
  case WATCOMREGISTER:
    Mov(SHOULD_BE_K,ecx);

    iv=44;
    nextIVR=24;
    nextIVL=20;
    thisIVR=16;
    thisIVL=12;
    out=8;
    in=4;
    counter=0;
    localVarsSize=28;

    // Mov(eax,eax);
    // Mov(edx,edx);
    // Mov(ebx,ebx);

    Sub(esp,localVarsSize);

    Mov(esp,in,eax);
    Mov(esp,out,edx);

    break;
  case FASTCALL: 
    Mov(SHOULD_BE_K,esp,8+16);

    iv=56;
    nextIVR=24;
    nextIVL=20;
    thisIVR=16;
    thisIVL=12;
    out=8;
    in=4;
    counter=0;
    localVarsSize=28;

    Mov(eax,ecx);
    // Mov(edx,edx);
    Mov(ebx,esp,4+16);

    Sub(esp,localVarsSize);

    Mov(esp,in,ecx);
    Mov(esp,out,edx);

    break;
  case CDECL:
    Mov(SHOULD_BE_K,esp,16+16);

    iv=56;
    out=44;
    in=40;
    nextIVR=16;
    nextIVL=12;
    thisIVR=8;
    thisIVL=4;
    counter=0;
    localVarsSize=20;

    Mov(eax,esp,4+16);
    Mov(edx,esp,8+16);
    Mov(ebx,esp,12+16);

    Sub(esp,localVarsSize);

    break;
  default:
    cerr <<"Unrecognized calling convention"<<endl;
    exit(-1);
  }
  
  Lea(eax,eax,1,ebx,0);
  Lea(edx,edx,1,ebx,0);
  Shr(ebx,3);
  Mov(ecx,esp,iv);
  Mov(esp,in,eax);
  Neg(ebx);
  Mov(esp,out,edx);
  Mov(esp,counter,ebx);

  Mov(eax,ecx,0);
  Mov(edx,ecx,4);
  BSwap(eax);
  BSwap(edx);
  Mov(esp,thisIVL,eax);
  Mov(esp,thisIVR,edx);

  os <<endl;
}

void CAST128CBCDecryptAsmGenerator::LoopBegin()
{
  Mov(ecx,esp,in);
  Mov(ebx,esp,counter);
  Mov(eax,ecx,8,ebx,0);
  Mov(edx,ecx,8,ebx,4);
  BSwap(eax);
  BSwap(edx);
  Mov(esp,nextIVL,eax);
  Mov(esp,nextIVR,edx);
  Mov(*dst,eax);
  Mov(*src,edx);
}

void CAST128CBCDecryptAsmGenerator::LoopEnd()
{
  Mov(ebx,esp,counter);
  Mov(eax,esp,thisIVL);
  Mov(edx,esp,thisIVR);
  Xor(*dst,eax);
  Xor(*src,edx);
  Mov(ecx,esp,out);
  Mov(eax,esp,nextIVL);
  Mov(edx,esp,nextIVR);
  Mov(esp,thisIVL,eax);
  Mov(esp,thisIVR,edx);
  BSwap(*dst);
  BSwap(*src);
  Mov(ecx,8,ebx,0,*dst);
  Mov(ecx,8,ebx,4,*src);
  Inc(ebx);
  Mov(esp,counter,ebx);
  Jne(loopBeginLabel,nearJ);
}

void CAST128CBCDecryptAsmGenerator::Cleanup()
{
  Comment("cleanup");
  Mov(ecx,esp,iv);
  Add(esp,localVarsSize);
  BSwap(eax);
  BSwap(edx);
  Mov(ecx,0,eax);
  Mov(ecx,4,edx);

  os <<endl;

  if ( callingConvention != WATCOMREGISTER )
    Pop(ebx);
  Pop(edi);
  Pop(esi);
  Pop(ebp);
  os <<endl;
  switch ( callingConvention)
  {
  case WATCOMREGISTER:
    Ret(4);
    break;
  case FASTCALL:
    Ret(12);
    break;
  case CDECL:
    Ret();
    break;
  default:
    cerr <<"Unrecognized calling convention"<<endl;
    exit(-1);
  }
}
