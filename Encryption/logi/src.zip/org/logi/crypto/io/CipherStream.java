// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.io;
import org.logi.crypto.*;
import org.logi.crypto.modes.*;
import org.logi.crypto.keys.*;

import java.io.*;

/**
 * Parent of CipherStreamClient and CipherStreamServer.
 *
 * @see org.logi.crypto.io.CipherStreamServer
 * @see org.logi.crypto.io.CipherStreamClient
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class CipherStream extends Crypto {

  protected OutputStream out;
  protected InputStream  in;

  protected EncryptStream cOut;
  protected DecryptStream cIn;

  protected EncryptMode encrypt;
  protected DecryptMode decrypt;
  
  /**
   * Get the encrypted input-stream. */
  public DecryptStream getInputStream(){
    return cIn;
  }

  /**
   * Get the encrypted output-stream. */
  public EncryptStream getOutputStream(){
    return cOut;
  }

  /**
   * Get the key used for encryption. */
  public CipherKey getEncryptKey(){
    return encrypt.getKey();
  }
  
  /**
   * Get the key used for decryption. */
  public CipherKey getDecryptKey(){
    return encrypt.getKey();
  }
  
}
