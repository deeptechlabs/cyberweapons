//
// amsgen.hpp
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#ifndef _ASMGEN_HPP
#define _ASMGEN_HPP

#include <iostream.h>

typedef long s32;
typedef unsigned long u32;

class Register
{
public:
  enum reg { eax=0, ebx=1, ecx=2, edx=3, edi=4, esi=5, ebp=6, esp=7 };

  Register(reg which) { _register=which; } 
  operator const char*() const;

  friend class AsmGenerator;
private:
  reg _register;
};

extern const Register eax, ebx, ecx, edx, edi, esi, ebp, esp;

class AsmGenerator
{
private:
  static int TheCPU;
  const char* _cFunctionName;

  static const char* IntelName[8];
  static const char* ATTName[8];

  void WriteAsmFunctionName();
protected:
  void Subround(const int number);

  void PushOffsetAddress(const Register& reg, const int offset);
  void PushIndexedAddress(const Register& base, const int scale, 
			  const Register& index, const int offset);
  // that's "push" onto output stream for the two methods above

  void Mov(const Register& dest, const Register& src);
  void Mov(const Register& dest, const s32 immediate);
  void Mov(const Register& dest, const Register& src, const int offset);
  void Mov(const Register& dest, const int offset, const Register& src);
  void And(const Register& dest, const Register& src);
  void Or(const Register& dest, const Register& src);
  void Xor(const Register& dest, const Register& src);
  void Xor(const Register& dest, const s32 immediate);
  void Add(const Register& dest, const Register& src);
  void Add(const Register& dest, const Register& src, const int offset);
  void Add(const Register& dest, const s32 immediate);
  void Sub(const Register& dest, const s32 immediate);
  void Rol(const Register& dest, const int distance);
  void Ror(const Register& dest, const int distance);
  void Push(const Register& src);
  void Pop(const Register& dest);
  void Lea(const Register& dest, const Register& src, const int scale, 
	   const Register& index, const int offset);
  void BSwap(const Register& dest);
  void Nop();
  void Ret(const int adjustment);
  void Ret();

  int RegCode(const Register& which);

  ostream& os;
public:
  enum syntaxEnum { MASM, NASM, ATT };
  enum targetEnum { ELF, AOUT, COFF, CPP, WIN32, INL };
  enum callingConventionEnum { CDECL, WATCOMREGISTER, FASTCALL };

  static syntaxEnum syntax;
  static targetEnum target;
  static callingConventionEnum callingConvention;

  AsmGenerator(ostream& os);
  virtual ~AsmGenerator() {}

  void Comment(const char* comment);
  void SetCFunctionName(const char* cFunctionName) 
   { _cFunctionName=cFunctionName; } 
  void SetCPU(const int CPU) { TheCPU=CPU; } 

  virtual void FileBegin();
  virtual void Startup()=0;
  virtual void Body()=0;
  virtual void Cleanup()=0;
  virtual void FileEnd();

  friend Register;
};

#endif
