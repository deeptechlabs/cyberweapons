// Copyright (C) 1998-2000 Logi Ragnarsson

package org.logi.crypto.sign;
import org.logi.crypto.*;

import java.io.*;

/**
 * This class stores a digital signature. It is created with a SignatureKey
 * from a Fingerprint and can later be used to verify that Fingerprint with
 * the same symmetric key or the other asymmetric key from the pair.
 *
 * @see org.logi.crypto.sign.Fingerprint
 * @see org.logi.crypto.keys.SignatureKey
 * @version 1.1.0
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 *         (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class Signature extends Crypto {
    
    protected byte[] s;             // encrypted fingerprint.
    protected String hashFunc;       // Hash function used.
    
    /**
     * Create a new Signature object. It contains the signature
     * <code>s</code> which was generated from a fingerprint returned from
     * the specified hash function. */
    public Signature(String hashFunc, byte[] s){
        this.s = new byte[s.length];
        System.arraycopy(s,0, this.s,0, s.length);
        this.hashFunc = hashFunc;
    }
    
   /**
    * Used by Crypto.fromString when parsing a CDS.<p>

    * A valid CDS can be created by calling the toString() method.

    * @exception InvalidCDSException if the CDS is malformed.
    * @see org.logi.crypto.Crypto#fromString(String)
    */
   public static Signature parseCDS(String[] param) throws InvalidCDSException{
      if(param.length!=2)
	throw new InvalidCDSException("invalid number of parameters in the CDS Signature(hashFunc,signature)");
      return new Signature(param[0], fromHexString(param[1]));
   }

    /**
     * Return the name of the hash function used to fingerprint the data
     * before signing.
     */
    public String getHashFunc(){
        return hashFunc;
    }
    
    /**
     * Return the bytes from this signature.
     */
    public byte[] getBytes(){
        byte[] ss = new byte[s.length];
        System.arraycopy(s,0, ss,0, s.length);
        return ss;
    }
    
    /**
     * Return a CDS for this object.
     */
    public String toString(){
        StringBuffer sb=new StringBuffer();
        sb.append("Signature(");
        sb.append(hashFunc==null ? "null" : hashFunc);
        sb.append(',');
        sb.append(s==null ? "null" : hexString(s));
        sb.append(')');
        return sb.toString();
    }
    
   /**
    * Print this object to out, indented with ind tabs, going down at most
    * rec levels of recursion. */
   public void prettyPrint(PrintWriter out, int ind, int rec) throws IOException {
      if(rec<0)
	return;
      for(int i=0; i<ind; i++)
	out.print('\t');
      out.println("Signature(");

      for(int i=0; i<=ind; i++)
	out.print('\t');
      out.print(hashFunc==null ? "null" : hashFunc);
      out.println(",");
      
      for(int i=0; i<=ind; i++)
	out.print('\t');
      out.print(s==null ? "null" : hexString(s));
      out.println();
      
      for(int i=0; i<ind; i++)
	out.print('\t');
      out.print(")");
    }

}
