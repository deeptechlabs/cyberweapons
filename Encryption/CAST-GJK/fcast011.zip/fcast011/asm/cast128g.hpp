//
// cast128g.hpp
//
// Copyright (C) 1997 Peter Gutmann (pgut001@cs.auckland.ac.nz),
//                    Leonard Janke (janke@unixg.ubc.ca),
//                    and Vesa Karvonen (vkarvone@mail.student.oulu.fi).

#ifndef _CAST128G_HPP 
#define _CAST128G_HPP

#include "asmgen.hpp"

class CAST128AsmGenerator : public AsmGenerator
{
protected:
  static const DWordRegister& K;

  static const DWordRegister& cnt;
  static const ByteRegister& cntl;
  static const ByteRegister& cnth;

  static const DWordRegister& rx0;
  static const ByteRegister& rx0l;
  static const ByteRegister& rx0h;

  static const DWordRegister& rx1;
  static const ByteRegister& rx1l;
  static const ByteRegister& rx1h;

  static const DWordRegister& rx2;
  static const ByteRegister& rx2l;
  static const ByteRegister& rx2h;

  static const CPtr S1; 
  static const CPtr S2; 
  static const CPtr S3; 
  static const CPtr S4; 

  static void Swap(const DWordRegister*& x, const DWordRegister*& y);

  const DWordRegister* src;
  const DWordRegister* dst;

  typedef void (AsmGenerator::*OpPtr)(const DWordRegister&, 
                                      const DWordRegister&);

  // Technically, none of what we produce will be normal CAST rounds 
  // since there is some interleaving between them to
  // optimize Pentium performance. The 16 rounds are replaced by what
  // I link to think of as 16 links on a chain. -Leonard 
  enum LinkEnum { top, middle, bottom  };
  void Link(int n, OpPtr op1, OpPtr op2, OpPtr op3, LinkEnum linkType);  

public:
  CAST128AsmGenerator(ostream& os);
  virtual ~CAST128AsmGenerator() {}

  void Copyright();
  void Externals();

  void Startup();
  void Cleanup();
};

#endif
