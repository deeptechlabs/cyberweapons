// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.modes;
import org.logi.crypto.*;
import org.logi.crypto.keys.*;

import java.util.Random;

/**
 * Descendants of EncryptMode encrypt arbtrarily large arrays of
 * plaintext.  A corresponding DecryptMode should be used for
 * decryption.
 * <p>
 * Most EncryptModes use a CipherKey object to do actual
 * encryption and do additional computations to mask repetitions in
 * the plaintext.
 *
 * @see org.logi.crypto.modes.DecryptMode
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a> 
 *         (<a href="mailto:logir@logi.org">logir@logi.org</a>) */
public abstract class EncryptMode extends Crypto {

  /** Return the key used for encryption. */
  public abstract CipherKey getKey();
  
  /**
   * Set the key to use for encryption. The key can only be set once in
   * this version of the library. The 1.1.x and eventually 1.2.x series
   * allows dynamic re-keying. */
  public abstract void setKey(CipherKey key);
  
  /**
   * Return the size of the blocks of plaintext encrypted by this object.
   */
  public abstract int plainBlockSize();
  
  /**
   * Pads the internal buffer, encrypts it and returns the
   * ciphertext.
   */
  public abstract byte[] flush();

  /**
   * Equivalent to calling <code>encrypt(source,i,length)</code>
   * followed by <code>flush()</code>.
   */
  public byte[] flush(byte[] source, int i, int length){
    byte[] e1 = encrypt(source,i,length);
    byte[] e2 = flush();
    if(e2.length==0)
      return e1;
    byte[] r = new byte[e1.length+e2.length];
    System.arraycopy(e1,0, r,0        , e1.length);
    System.arraycopy(e2,0, r,e1.length, e2.length);
    return r;
  }
  
  /**
   * Send bytes to the EncryptMode for encryption.
   * <p>
   * Encrypt <code>length</code> bytes from <code>source</code>,
   * starting at <code>i</code> and return the ciphertext. Data may be
   * encrypted in blocks in which case only whole blocks of ciphertext
   * are written to <code>dest</code>. Any remaining plaintext will be
   * stored and prepended to <code>source</code> in the next call to
   * <code>encrypt</code>.
   */
  public abstract byte[] encrypt(byte[] source, int i, int length);

  /**
   * Close files and kill threads owned by the object. This should
   * be called to make sure all resources are freed.
   */
  public void close(){
  }

  /**
   * This finalizer calls close(). Note, however, that java offers
   * <b>no guarantee</b> that the finalizer is ever called.
   */
  public void finalize(){
    close();
  }
  
}
