// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.protocols;
import org.logi.crypto.*;
import org.logi.crypto.keys.*;

import java.math.BigInteger;

/**
 * Query-response authenticaton server. It expects to talk to a
 * QRAuthClient object.
 * <p>
 * If the protocol is completed, the server is certain that the client
 * also knows the secret key passed to the constructor.
 *
 * @see org.logi.crypto.protocols.QRAuthServer
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class QRAuthServer extends QRAuth implements InterAuthServer {
    
    /**
     * Creates a new QRAuthServer object with the specified secret
     * <code>key</code>.
     */
    public QRAuthServer(CipherKey key){
        super(key);
    }
    
    /**
     * Get the next message in the protocol.
     * <p>
     * <code>received</code> is the last message received form the server
     * and has not yet been sent to the client.
     * <p>
     * The returned value is the next message to send to the server or null
     * if no more messages need to be sent and the protocol is terminated.
     *
     * @exception CryptoProtocolException if a problem arises with the protocol.
     */
    public byte[] message(byte[] received) throws CryptoProtocolException {
	try{

	    if(r==null){
		// The protocol is just beginning. The client should now
		// be sending us E(r) to which we reply E(r+1)
		
		if(received==null)
		    throw new CryptoProtocolException("The client should always send the first message");
		
		r = new byte[key.plainBlockSize()];
		key.decrypt(received,0, r,0);
		
		QRAuthClient.addOne(r);
		byte[] e = new byte[key.cipherBlockSize()];
		key.encrypt(r,0, e,0);
		
		return e;
	    } else {
		// The client should now be sending us E(r+2)
		
		if(received.length != key.cipherBlockSize())
		    throw new CryptoProtocolException("Received message has the wrong length.");
		
		byte[] guess = new byte[key.cipherBlockSize()];
		key.decrypt(received,0, guess,0);
		
		QRAuthClient.addOne(r);
		if(!equal(guess,r))
		    throw new ValidationException("The client does not know the secret");
		
		completed = true;
		return null;
	    }
	} catch (ArrayIndexOutOfBoundsException e) {
	    throw new CryptoProtocolException("Malformed message.");
	}
    }
    
}
