//
// a2r128.hpp 
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#ifndef _A2R128_HPP
#define _A2R128_HPP

#include "asmgen.hpp" 

enum alias { A=0, B=1, C=2, D=3 };

class a2r128
{
private:
 int offset;
public:
 a2r128() { offset=0; }
 void Circulate();
 const Register& operator[](alias);
};

#endif
