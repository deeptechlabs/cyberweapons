// Copyright (C) 1998-2000 Logi Ragnarsson

package org.logi.crypto.modes;
import org.logi.crypto.*;
import org.logi.crypto.keys.*;

/**
 * This class is used by EncryptOFB and DecryptOFB to precalculate the
 * keystream. <p>

 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 *
 * @see org.logi.crypto.modes.EncryptOFB
 * @see org.logi.crypto.modes.DecryptOFB
 */
public class OFBProducer extends Producer {

   /** The key to use for encryption. */
   CipherKey key;
   
   /** Input block size and output block size. */
   int ibs;
   int obs;
   
   /** The last block from the last quart-buffer. */
   byte[] lastBlock;

   /** The IV or null if it has been set null by the consumer. */
   byte[] IV;
   
   /**
    * Create new OFB thread with the given key and buffer size,
    * but random IV. */
   public OFBProducer(CipherKey key, int bufSize){
      // each quart-buffer is a quarter of bufSize, rounded up to the
      // nearest multiple of obs.
      super(((bufSize-1)/key.cipherBlockSize()/4+1)*key.cipherBlockSize());
      this.key=key;
      ibs=key.plainBlockSize();
      obs=key.cipherBlockSize();
      lastBlock = new byte[ibs];
      IV = new byte[ibs];
      Crypto.random.nextBytes(IV);  // random IV
      System.arraycopy(IV,0, lastBlock,0, ibs);
      start();
   }
   
   /**
    * Create new OFB thread with the given key, buffer size
    * and IV[i..i+key.plainBlockSize()-1]. */
   protected OFBProducer(CipherKey key, int bufSize, byte[] IV, int i){
      // each quart-buffer is a quarter of bufSize, rounded up to the
      // nearest multiple of obs.
      super(((bufSize-1)/key.cipherBlockSize()/4+1)*key.cipherBlockSize());
      this.key=key;
      ibs=key.plainBlockSize();
      obs=key.cipherBlockSize();
      lastBlock = new byte[ibs];
      this.IV = new byte[ibs];
      System.arraycopy(IV,i, this.IV,0, ibs);  // given IV
      System.arraycopy(IV,i, lastBlock,0, ibs);
      start();
   }

   public CipherKey getKey() {
      return key;
   }
   
   /**
    * Calculate the next bytes from the key-stream and put in buf. We know
    * that the size of buf is an even multiple of the size of input blocks.
    */
   public void calculate(byte[] buf) {
      key.encrypt(lastBlock,0, buf,0);
      for(int i=obs; i<buf.length; i+=obs)
	key.encrypt(buf,i-ibs, buf,i);
      System.arraycopy(buf,buf.length-ibs, lastBlock,0, ibs);
   }
   
}
