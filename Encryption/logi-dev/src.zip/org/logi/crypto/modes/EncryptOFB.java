// Copyright (C) 1998,2000 Logi Ragnarsson

package org.logi.crypto.modes;
import org.logi.crypto.*;
import org.logi.crypto.keys.*;

import java.util.Random;

/**
 * Output Fedback Mode iterates the encryption routine on the IV and xors
 * the resulting stream with the plaintext to produce the ciphertext.<p>

 * This requires as many encryptions as ECB or CBC mode, but can encrypt
 * plaintext one byte at a time. A stream is calculated in a separate
 * thread and xored with the plaintext. This gives fast response, since the
 * final encryption is merely an xor operation.<p>

 * However, since (with plaintext P, ciphertext C and xor-stream S)
 * <p><blockquote>
 *   P = C ^ S, 
 * </blockquote><p>
 * the opponent can alter the plaintext received by changing
 * <p><blockquote>
 *  C' = C ^ A,
 * </blockquote><p>
 * so that
 * <p><blockquote>
 *  P' = C' ^ S = C ^ A ^ S = P ^ A
 * </blockquote><p>
 * is seen. But the opponent will not be able to learn P or control what P'
 * is.<p>
 
 * An example of how the attacker can use this is to flip the most
 * significant bit of the amount of money being deposited onto his bank
 * account. OFB mode should be used with some sort of hashing or signing
 * mechanism.

 * @see org.logi.crypto.modes.DecryptOFB
 * 
 * @version 1.1.1
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class EncryptOFB extends EncryptMode{
  
   /** Calculates the stream. */
   private OFBProducer producer;
   
   /** Stores desired buffer size until setKey() is called. */
   private int bufSize;
   
   // keyStream[keyPos..keyStream.length-1] is the next unused key-stream
   // bytes.
   private byte[] keyStream;
   private int keyPos;
   
   /** Has IV been written yet? */
   private boolean wroteIV=false;
   
  /**
   * Create a new OFB-mode encrypt session with the specified
   * <code>key</code>. A buffer of <code>bufSize</code> bytes is created
   * to hold a pre-calculated xor-stream.
   */
  public EncryptOFB(CipherKey key, int bufSize) {
     this.bufSize=bufSize;
     setKey(key);
  }
  
  /**
   * Create a new OFB-mode encrypt session with no key. No
   * encryption can be performed until the <code>setKey()</code>
   * method has been called.
   * <p>
   * A buffer of <code>bufSize</code> bytes is created to hold a
   * pre-calculated xor-stream.*/
  public EncryptOFB(int bufSize){
    this.bufSize=bufSize;
  }
  
  /** Return the key used for encryption. */
  public CipherKey getKey(){
    return producer.key;
  }
  
  /**
   * Set the key to use for encryption. The key can only be set once in
   * this version of the library. The 1.1.x and eventually 1.2.x series
   * allows dynamic re-keying. */
  public synchronized void setKey(CipherKey key) {
     if(producer!=null)
       producer.kill();
     wroteIV=false;
     producer = new OFBProducer(key,bufSize);
  }
    
  /**
   * Return the size of the blocks of plaintext encrypted by this object.
   */
  public int plainBlockSize(){
      return 1;
  }
  
  /**
   * Pads the internal buffer, encrypts it and returns the ciphertext.
   * Since OFB mode doesn't use an internal buffer, an empty array is
   * returned.
   */
  public synchronized byte[] flush(){
    return new byte[0];
  }

  /**
   * Send bytes to the EncryptOFB object for encryption.
   * <p>
   * Encrypt <code>length</code> bytes from <code>source</code>,
   * starting at <code>i</code> and return the ciphertext.
   */
  public synchronized byte[] encrypt(byte[] source, int i, int length){
     byte[] dest;
     int destPos=0;
     
     if (!wroteIV){
	dest = new byte[length+producer.ibs];
	System.arraycopy(producer.IV,0, dest,0, producer.ibs);
	destPos = producer.ibs;
	wroteIV=true;
     } else {
	dest = new byte[length];
     }
     
     if(keyStream==null) {
	keyStream = producer.nextBuffer();
	keyPos = 0;
     }
     
     while(length>0){
	if(keyPos==keyStream.length) {
	   keyStream = producer.nextBuffer();
	   keyPos = 0;
	}
	int n = Math.min(length, keyStream.length-keyPos);
	length-=n;
	int end=i+n;
	while(i<end){
	   dest[destPos++] = (byte)(source[i++] ^ keyStream[keyPos++]);
	}
     }
     
     return dest;
  }
   
   /**
    * Close files and kill threads owned by the object. This should
    * be called to make sure all resources are freed.
    */
   public void close(){
      if(producer==null)
	return;
      producer.kill();
      producer=null;
   }
  
}
