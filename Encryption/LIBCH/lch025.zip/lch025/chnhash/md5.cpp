//
// md5.cxx
// This algorithm is due to R. Rivest and is defined in RFC 1321.
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#include <assert.h>
#include <string.h>
#include "md5.hpp"
#include "chmisc.hpp"
#include "clink.h"
#include <assert.h>

const u32 MD5::H0=0x67452301;
const u32 MD5::H1=0xefcdab89;
const u32 MD5::H2=0x98badcfe;
const u32 MD5::H3=0x10325476;

MD5::MD5() : MD4ish(128)
{
  H=new u32[4];

  H[0]=H0;
  H[1]=H1;
  H[2]=H2;
  H[3]=H3;
}
 
MD5::~MD5()
{
  delete[] H;
}

void MD5::ProcessBlock(const u32* block)
{
  MD5Transform(H,block);
}

void MD5::Compress(const u32* iv, const u32* block, u32* result)
{
  memcpy(result,iv,16);
  MD5Transform(result,block);
}

void MD5::Compress(const void* iv, const void* block, void* result)
{
  u32 Block[16];
  u32 Result[4];

  memcpy(Result,iv,16);
  memcpy(Block,block,64);
  CHMisc::MemSwap(Result,4);

  MD5Transform(Result,Block);
  memcpy(result,Result,16);
}

void MD5::Reset()
{
  MD4ish::Reset();

  H[0]=H0;
  H[1]=H1;
  H[2]=H2;
  H[3]=H3;
}
