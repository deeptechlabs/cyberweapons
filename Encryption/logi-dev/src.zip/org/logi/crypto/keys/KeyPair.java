// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.keys;
import org.logi.crypto.*;

import java.io.PrintWriter;
import java.io.IOException;

/**
 * This class is a simple holder for a pair of public/private keys. Some
 * encryption algorithms only use a single key, in which case the
 * public and private fields of a KeyPair may reference the same object.
 * Either the public or private fields may be <code>null</code> if the
 * corresponding key is unknown.
 * 
 * @see org.logi.crypto.keys.Key
 * @see org.logi.crypto.keys.KeyRing
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a> (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class KeyPair extends Crypto {
    
    // public and private key in the pair.
    Key pub,pri;
    
    /** Create a new KeyPair holder. */
    public KeyPair(Key pub, Key pri){
        this.pub=pub;
        this.pri=pri;
    }
    
    /** Return the public key from the pair. */
    public Key getPublic(){
        return pub;
    }
    
    /** Return the private key from the pair. */
    public Key getPrivate(){
        return pri;
    }
    
   /**
    * Used by Crypto.fromString when parsing a CDS.<p>

    * A valid CDS can be created by calling the toString() method.

    * @exception InvalidCDSException if the CDS is malformed.
    * @see org.logi.crypto.Crypto#fromString(String)
    */
   public static KeyPair parseCDS(String[] param) throws InvalidCDSException{
      if(param.length!=2)
	throw new InvalidCDSException("invalid number of parameters in the CDS KeyPair(pubKey,priKey)");
      Object pubKey = fromString(param[0]);
      if(!(pubKey instanceof Key))
	throw new InvalidCDSException("CDS for a Key object expected as first argument to KeyPair()");
      Object priKey = fromString(param[1]);
      if(!(priKey instanceof Key))
	throw new InvalidCDSException("CDS for a Key object expected as second argument to KeyPair()");
      return new KeyPair((Key)pubKey, (Key)priKey);
   }
   
    /**
     * Return a CDS for this key-pair.
     *
     * @see org.logi.crypto.Crypto#fromString(String)
     */
    public String toString(){
        return "KeyPair("+pub.toString()+","+pri.toString()+")";
    }

   /**
    * Print this object to out, indented with ind tabs, going down at most
    * rec levels of recursion. */
   public void prettyPrint(PrintWriter out, int ind, int rec) throws IOException {
      if(rec<0)
	return;
      for(int i=0; i<ind; i++)
	out.print('\t');
      out.println("KeyPair(");

      pub.prettyPrint(out, ind+1, rec-1);
      out.println(",");

      pub.prettyPrint(out, ind+1, rec-1);
      out.println();
      
      for(int i=0; i<ind; i++)
	out.print('\t');
      out.print(")");
    }

}
