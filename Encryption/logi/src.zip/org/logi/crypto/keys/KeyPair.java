// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.keys;
import org.logi.crypto.*;

/**
 * This class is a simple holder for a pair of public/private keys. Some
 * encryption algorithms only use a single key, in which case the
 * public and private fields of a KeyPair may reference the same object.
 * Either the public or private fields may be <code>null</code> if the
 * corresponding key is unknown.
 * 
 * @see org.logi.crypto.keys.Key
 * @see org.logi.crypto.keys.KeyRing
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a> (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class KeyPair extends Crypto {
    
    // public and private key in the pair.
    Key pub,pri;
    
    /** Create a new KeyPair holder. */
    public KeyPair(Key pub, Key pri){
        this.pub=pub;
        this.pri=pri;
    }
    
    /** Return the public key from the pair. */
    public Key getPublic(){
        return pub;
    }
    
    /** Return the private key from the pair. */
    public Key getPrivate(){
        return pri;
    }
    
    /**
     * Return a CDS for this key-pair.
     *
     * @see org.logi.crypto.Crypto#fromString(String)
     */
    public String toString(){
        return "KeyPair("+pub.toString()+","+pri.toString()+")";
    }
}
