//
// a2r160.cpp 
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#include "a2r160.hpp"

void a2r160::Circulate()
{
  offset--;
  if ( offset < 0 )
   offset+=5;
  return;
}

const Register& a2r160::operator[](alias a)
{
  const Register* rv;

  switch ( (a+offset)%5 )
    {
    case 0:
      rv=&eax;
      break;
    case 1:
      rv=&ebx;
      break;
    case 2:
      rv=&ecx;
      break;
    case 3:
      rv=&edx;
      break;
    case 4:
      rv=&edi;
      break;
    }

  return *rv;
}
