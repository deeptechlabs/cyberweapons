Please read the following documents:

docs/index.htm    an abstract describing this library,
docs/license.htm  license information, and
docs/install.htm  details on installing the library.

docs/toc.htm contains the table of contents for the documentation. The entire 
documentation can be read starting from docs/index.htm by following the "next" 
link at the top of each page.

Enjoy! :)
Leonard Janke (janke@unixg.ubc.ca)
May 4, 1997
