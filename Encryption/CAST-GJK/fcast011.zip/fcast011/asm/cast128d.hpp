//
// cast128d.hpp
//
// Copyright (C) 1997 Peter Gutmann (pgut001@cs.auckland.ac.nz) and
//                    Leonard Janke (janke@unixg.ubc.ca) 

#ifndef _CAST128D_HPP 
#define _CAST128D_HPP

#include "cast128g.hpp"

class CAST128DecryptAsmGenerator : public CAST128AsmGenerator
{
public:
  CAST128DecryptAsmGenerator(ostream& os);

  void Body();
};

#endif
