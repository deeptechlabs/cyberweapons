#include "clink.h"

void __declspec(naked) __cdecl RIPEMD128Transform(u32* H, const u32* X)
{
  __asm{
	push ebp
	push esi
	push edi
	push ebx
	mov eax, [esp+20]
	mov esi, [esp+24]
	mov edx, [eax+12]
	mov ecx, [eax+8]
	mov ebx, [eax+4]
	mov eax, [eax]
	push edx
	push ecx
	push ebx
	push eax
/* left half */
	mov edi, ecx
	mov ebp, [esi]
/* Subround 0 */
	xor edi, edx
	add eax, ebp
	xor edi, ebx
	mov ebp, [esi+4]
	add eax, edi
	mov edi, ebx
	rol eax, 11

/* Subround 1 */
	xor edi, ecx
	add edx, ebp
	xor edi, eax
	mov ebp, [esi+8]
	add edx, edi
	mov edi, eax
	rol edx, 14

/* Subround 2 */
	xor edi, ebx
	add ecx, ebp
	xor edi, edx
	mov ebp, [esi+12]
	add ecx, edi
	mov edi, edx
	rol ecx, 15

/* Subround 3 */
	xor edi, eax
	add ebx, ebp
	xor edi, ecx
	mov ebp, [esi+16]
	add ebx, edi
	mov edi, ecx
	rol ebx, 12

/* Subround 4 */
	xor edi, edx
	add eax, ebp
	xor edi, ebx
	mov ebp, [esi+20]
	add eax, edi
	mov edi, ebx
	rol eax, 5

/* Subround 5 */
	xor edi, ecx
	add edx, ebp
	xor edi, eax
	mov ebp, [esi+24]
	add edx, edi
	mov edi, eax
	rol edx, 8

/* Subround 6 */
	xor edi, ebx
	add ecx, ebp
	xor edi, edx
	mov ebp, [esi+28]
	add ecx, edi
	mov edi, edx
	rol ecx, 7

/* Subround 7 */
	xor edi, eax
	add ebx, ebp
	xor edi, ecx
	mov ebp, [esi+32]
	add ebx, edi
	mov edi, ecx
	rol ebx, 9

/* Subround 8 */
	xor edi, edx
	add eax, ebp
	xor edi, ebx
	mov ebp, [esi+36]
	add eax, edi
	mov edi, ebx
	rol eax, 11

/* Subround 9 */
	xor edi, ecx
	add edx, ebp
	xor edi, eax
	mov ebp, [esi+40]
	add edx, edi
	mov edi, eax
	rol edx, 13

/* Subround 10 */
	xor edi, ebx
	add ecx, ebp
	xor edi, edx
	mov ebp, [esi+44]
	add ecx, edi
	mov edi, edx
	rol ecx, 14

/* Subround 11 */
	xor edi, eax
	add ebx, ebp
	xor edi, ecx
	mov ebp, [esi+48]
	add ebx, edi
	mov edi, ecx
	rol ebx, 15

/* Subround 12 */
	xor edi, edx
	add eax, ebp
	xor edi, ebx
	mov ebp, [esi+52]
	add eax, edi
	mov edi, ebx
	rol eax, 6

/* Subround 13 */
	xor edi, ecx
	add edx, ebp
	xor edi, eax
	mov ebp, [esi+56]
	add edx, edi
	mov edi, eax
	rol edx, 7

/* Subround 14 */
	xor edi, ebx
	add ecx, ebp
	xor edi, edx
	mov ebp, [esi+60]
	add ecx, edi
	mov edi, edx
	rol ecx, 9

/* Subround 15 */
	xor edi, eax
	add ebx, ebp
	xor edi, ecx
	mov ebp, [esi+28]
	add ebx, edi
	mov edi, ecx
	rol ebx, 8

	xor edi, edx
/* Subround 16 */
	and edi, ebx
	lea eax, [eax+ebp+1518500249]
	xor edi, edx
	mov ebp, ebx
	add eax, edi
	mov edi, [esi+16]
	rol eax, 7

/* Subround 17 */
	xor ebp, ecx
	lea edx, [edx+edi+1518500249]
	and ebp, eax
	mov edi, eax
	xor ebp, ecx
	xor edi, ebx
	add edx, ebp
	mov ebp, [esi+52]
	rol edx, 6

/* Subround 18 */
	and edi, edx
	lea ecx, [ecx+ebp+1518500249]
	xor edi, ebx
	mov ebp, edx
	add ecx, edi
	mov edi, [esi+4]
	rol ecx, 8

/* Subround 19 */
	xor ebp, eax
	lea ebx, [ebx+edi+1518500249]
	and ebp, ecx
	mov edi, ecx
	xor ebp, eax
	xor edi, edx
	add ebx, ebp
	mov ebp, [esi+40]
	rol ebx, 13

/* Subround 20 */
	and edi, ebx
	lea eax, [eax+ebp+1518500249]
	xor edi, edx
	mov ebp, ebx
	add eax, edi
	mov edi, [esi+24]
	rol eax, 11

/* Subround 21 */
	xor ebp, ecx
	lea edx, [edx+edi+1518500249]
	and ebp, eax
	mov edi, eax
	xor ebp, ecx
	xor edi, ebx
	add edx, ebp
	mov ebp, [esi+60]
	rol edx, 9

/* Subround 22 */
	and edi, edx
	lea ecx, [ecx+ebp+1518500249]
	xor edi, ebx
	mov ebp, edx
	add ecx, edi
	mov edi, [esi+12]
	rol ecx, 7

/* Subround 23 */
	xor ebp, eax
	lea ebx, [ebx+edi+1518500249]
	and ebp, ecx
	mov edi, ecx
	xor ebp, eax
	xor edi, edx
	add ebx, ebp
	mov ebp, [esi+48]
	rol ebx, 15

/* Subround 24 */
	and edi, ebx
	lea eax, [eax+ebp+1518500249]
	xor edi, edx
	mov ebp, ebx
	add eax, edi
	mov edi, [esi]
	rol eax, 7

/* Subround 25 */
	xor ebp, ecx
	lea edx, [edx+edi+1518500249]
	and ebp, eax
	mov edi, eax
	xor ebp, ecx
	xor edi, ebx
	add edx, ebp
	mov ebp, [esi+36]
	rol edx, 12

/* Subround 26 */
	and edi, edx
	lea ecx, [ecx+ebp+1518500249]
	xor edi, ebx
	mov ebp, edx
	add ecx, edi
	mov edi, [esi+20]
	rol ecx, 15

/* Subround 27 */
	xor ebp, eax
	lea ebx, [ebx+edi+1518500249]
	and ebp, ecx
	mov edi, ecx
	xor ebp, eax
	xor edi, edx
	add ebx, ebp
	mov ebp, [esi+8]
	rol ebx, 9

/* Subround 28 */
	and edi, ebx
	lea eax, [eax+ebp+1518500249]
	xor edi, edx
	mov ebp, ebx
	add eax, edi
	mov edi, [esi+56]
	rol eax, 11

/* Subround 29 */
	xor ebp, ecx
	lea edx, [edx+edi+1518500249]
	and ebp, eax
	mov edi, eax
	xor ebp, ecx
	xor edi, ebx
	add edx, ebp
	mov ebp, [esi+44]
	rol edx, 7

/* Subround 30 */
	and edi, edx
	lea ecx, [ecx+ebp+1518500249]
	xor edi, ebx
	mov ebp, edx
	add ecx, edi
	mov edi, [esi+32]
	rol ecx, 13

/* Subround 31 */
	xor ebp, eax
	lea ebx, [ebx+edi+1518500249]
	and ebp, ecx
	mov edi, ecx
	xor ebp, eax
	xor edi, -1
	add ebx, ebp
	mov ebp, [esi+12]
	rol ebx, 12

/* Subround 32 */
	or edi, ebx
	lea eax, [eax+ebp+1859775393]
	xor edi, edx
	mov ebp, ebx
	add eax, edi
	mov edi, [esi+40]
	rol eax, 11

/* Subround 33 */
	xor ebp, -1
	lea edx, [edx+edi+1859775393]
	or ebp, eax
	mov edi, eax
	xor ebp, ecx
	xor edi, -1
	add edx, ebp
	mov ebp, [esi+56]
	rol edx, 13

/* Subround 34 */
	or edi, edx
	lea ecx, [ecx+ebp+1859775393]
	xor edi, ebx
	mov ebp, edx
	add ecx, edi
	mov edi, [esi+16]
	rol ecx, 6

/* Subround 35 */
	xor ebp, -1
	lea ebx, [ebx+edi+1859775393]
	or ebp, ecx
	mov edi, ecx
	xor ebp, eax
	xor edi, -1
	add ebx, ebp
	mov ebp, [esi+36]
	rol ebx, 7

/* Subround 36 */
	or edi, ebx
	lea eax, [eax+ebp+1859775393]
	xor edi, edx
	mov ebp, ebx
	add eax, edi
	mov edi, [esi+60]
	rol eax, 14

/* Subround 37 */
	xor ebp, -1
	lea edx, [edx+edi+1859775393]
	or ebp, eax
	mov edi, eax
	xor ebp, ecx
	xor edi, -1
	add edx, ebp
	mov ebp, [esi+32]
	rol edx, 9

/* Subround 38 */
	or edi, edx
	lea ecx, [ecx+ebp+1859775393]
	xor edi, ebx
	mov ebp, edx
	add ecx, edi
	mov edi, [esi+4]
	rol ecx, 13

/* Subround 39 */
	xor ebp, -1
	lea ebx, [ebx+edi+1859775393]
	or ebp, ecx
	mov edi, ecx
	xor ebp, eax
	xor edi, -1
	add ebx, ebp
	mov ebp, [esi+8]
	rol ebx, 15

/* Subround 40 */
	or edi, ebx
	lea eax, [eax+ebp+1859775393]
	xor edi, edx
	mov ebp, ebx
	add eax, edi
	mov edi, [esi+28]
	rol eax, 14

/* Subround 41 */
	xor ebp, -1
	lea edx, [edx+edi+1859775393]
	or ebp, eax
	mov edi, eax
	xor ebp, ecx
	xor edi, -1
	add edx, ebp
	mov ebp, [esi]
	rol edx, 8

/* Subround 42 */
	or edi, edx
	lea ecx, [ecx+ebp+1859775393]
	xor edi, ebx
	mov ebp, edx
	add ecx, edi
	mov edi, [esi+24]
	rol ecx, 13

/* Subround 43 */
	xor ebp, -1
	lea ebx, [ebx+edi+1859775393]
	or ebp, ecx
	mov edi, ecx
	xor ebp, eax
	xor edi, -1
	add ebx, ebp
	mov ebp, [esi+52]
	rol ebx, 6

/* Subround 44 */
	or edi, ebx
	lea eax, [eax+ebp+1859775393]
	xor edi, edx
	mov ebp, ebx
	add eax, edi
	mov edi, [esi+44]
	rol eax, 5

/* Subround 45 */
	xor ebp, -1
	lea edx, [edx+edi+1859775393]
	or ebp, eax
	mov edi, eax
	xor ebp, ecx
	xor edi, -1
	add edx, ebp
	mov ebp, [esi+20]
	rol edx, 12

/* Subround 46 */
	or edi, edx
	lea ecx, [ecx+ebp+1859775393]
	xor edi, ebx
	mov ebp, edx
	add ecx, edi
	mov edi, [esi+48]
	rol ecx, 7

/* Subround 47 */
	xor ebp, -1
	lea ebx, [ebx+edi+1859775393]
	or ebp, ecx
	mov edi, ecx
	xor ebp, eax
	add ebx, ebp
	mov ebp, [esi+4]
	rol ebx, 5

/* Subround 48 */
	xor edi, ebx
	mov ebp, [esi+4]
	and edi, edx
	add eax, ebp
	xor edi, ecx
	add eax, -1894007588
	add eax, edi
	mov edi, ebx
	rol eax, 11

/* Subround 49 */
	xor edi, eax
	mov ebp, [esi+36]
	and edi, ecx
	add edx, ebp
	xor edi, ebx
	add edx, -1894007588
	add edx, edi
	mov edi, eax
	rol edx, 12

/* Subround 50 */
	xor edi, edx
	mov ebp, [esi+44]
	and edi, ebx
	add ecx, ebp
	xor edi, eax
	add ecx, -1894007588
	add ecx, edi
	mov edi, edx
	rol ecx, 14

/* Subround 51 */
	xor edi, ecx
	mov ebp, [esi+40]
	and edi, eax
	add ebx, ebp
	xor edi, edx
	add ebx, -1894007588
	add ebx, edi
	mov edi, ecx
	rol ebx, 15

/* Subround 52 */
	xor edi, ebx
	mov ebp, [esi]
	and edi, edx
	add eax, ebp
	xor edi, ecx
	add eax, -1894007588
	add eax, edi
	mov edi, ebx
	rol eax, 14

/* Subround 53 */
	xor edi, eax
	mov ebp, [esi+32]
	and edi, ecx
	add edx, ebp
	xor edi, ebx
	add edx, -1894007588
	add edx, edi
	mov edi, eax
	rol edx, 15

/* Subround 54 */
	xor edi, edx
	mov ebp, [esi+48]
	and edi, ebx
	add ecx, ebp
	xor edi, eax
	add ecx, -1894007588
	add ecx, edi
	mov edi, edx
	rol ecx, 9

/* Subround 55 */
	xor edi, ecx
	mov ebp, [esi+16]
	and edi, eax
	add ebx, ebp
	xor edi, edx
	add ebx, -1894007588
	add ebx, edi
	mov edi, ecx
	rol ebx, 8

/* Subround 56 */
	xor edi, ebx
	mov ebp, [esi+52]
	and edi, edx
	add eax, ebp
	xor edi, ecx
	add eax, -1894007588
	add eax, edi
	mov edi, ebx
	rol eax, 9

/* Subround 57 */
	xor edi, eax
	mov ebp, [esi+12]
	and edi, ecx
	add edx, ebp
	xor edi, ebx
	add edx, -1894007588
	add edx, edi
	mov edi, eax
	rol edx, 14

/* Subround 58 */
	xor edi, edx
	mov ebp, [esi+28]
	and edi, ebx
	add ecx, ebp
	xor edi, eax
	add ecx, -1894007588
	add ecx, edi
	mov edi, edx
	rol ecx, 5

/* Subround 59 */
	xor edi, ecx
	mov ebp, [esi+60]
	and edi, eax
	add ebx, ebp
	xor edi, edx
	add ebx, -1894007588
	add ebx, edi
	mov edi, ecx
	rol ebx, 6

/* Subround 60 */
	xor edi, ebx
	mov ebp, [esi+56]
	and edi, edx
	add eax, ebp
	xor edi, ecx
	add eax, -1894007588
	add eax, edi
	mov edi, ebx
	rol eax, 8

/* Subround 61 */
	xor edi, eax
	mov ebp, [esi+20]
	and edi, ecx
	add edx, ebp
	xor edi, ebx
	add edx, -1894007588
	add edx, edi
	mov edi, eax
	rol edx, 6

/* Subround 62 */
	xor edi, edx
	mov ebp, [esi+24]
	and edi, ebx
	add ecx, ebp
	xor edi, eax
	add ecx, -1894007588
	add ecx, edi
	mov edi, edx
	rol ecx, 5

/* Subround 63 */
	xor edi, ecx
	mov ebp, [esi+8]
	and edi, eax
	add ebx, ebp
	xor edi, edx
	add ebx, -1894007588
	add ebx, edi
	mov edi, ecx
	rol ebx, 12

/* save left result */
	push edx
	push ecx
	push ebx
	push eax
/* reloading chain variables */
	mov edx, [esp+28]
	mov ecx, [esp+24]
	mov ebx, [esp+20]
	mov eax, [esp+16]
/* right half */
	mov edi, ecx
	mov ebp, [esi+20]
/* Subround 0 */
	xor edi, ebx
	lea eax, [eax+ebp+1352829926]
	and edi, edx
	mov ebp, ebx
	xor edi, ecx
	nop
	add eax, edi
	mov edi, [esi+56]
	rol eax, 8

/* Subround 1 */
	xor ebp, eax
	lea edx, [edx+edi+1352829926]
	and ebp, ecx
	mov edi, eax
	xor ebp, ebx
	nop
	add edx, ebp
	mov ebp, [esi+28]
	rol edx, 9

/* Subround 2 */
	xor edi, edx
	lea ecx, [ecx+ebp+1352829926]
	and edi, ebx
	mov ebp, edx
	xor edi, eax
	nop
	add ecx, edi
	mov edi, [esi]
	rol ecx, 9

/* Subround 3 */
	xor ebp, ecx
	lea ebx, [ebx+edi+1352829926]
	and ebp, eax
	mov edi, ecx
	xor ebp, edx
	nop
	add ebx, ebp
	mov ebp, [esi+36]
	rol ebx, 11

/* Subround 4 */
	xor edi, ebx
	lea eax, [eax+ebp+1352829926]
	and edi, edx
	mov ebp, ebx
	xor edi, ecx
	nop
	add eax, edi
	mov edi, [esi+8]
	rol eax, 13

/* Subround 5 */
	xor ebp, eax
	lea edx, [edx+edi+1352829926]
	and ebp, ecx
	mov edi, eax
	xor ebp, ebx
	nop
	add edx, ebp
	mov ebp, [esi+44]
	rol edx, 15

/* Subround 6 */
	xor edi, edx
	lea ecx, [ecx+ebp+1352829926]
	and edi, ebx
	mov ebp, edx
	xor edi, eax
	nop
	add ecx, edi
	mov edi, [esi+16]
	rol ecx, 15

/* Subround 7 */
	xor ebp, ecx
	lea ebx, [ebx+edi+1352829926]
	and ebp, eax
	mov edi, ecx
	xor ebp, edx
	nop
	add ebx, ebp
	mov ebp, [esi+52]
	rol ebx, 5

/* Subround 8 */
	xor edi, ebx
	lea eax, [eax+ebp+1352829926]
	and edi, edx
	mov ebp, ebx
	xor edi, ecx
	nop
	add eax, edi
	mov edi, [esi+24]
	rol eax, 7

/* Subround 9 */
	xor ebp, eax
	lea edx, [edx+edi+1352829926]
	and ebp, ecx
	mov edi, eax
	xor ebp, ebx
	nop
	add edx, ebp
	mov ebp, [esi+60]
	rol edx, 7

/* Subround 10 */
	xor edi, edx
	lea ecx, [ecx+ebp+1352829926]
	and edi, ebx
	mov ebp, edx
	xor edi, eax
	nop
	add ecx, edi
	mov edi, [esi+32]
	rol ecx, 8

/* Subround 11 */
	xor ebp, ecx
	lea ebx, [ebx+edi+1352829926]
	and ebp, eax
	mov edi, ecx
	xor ebp, edx
	nop
	add ebx, ebp
	mov ebp, [esi+4]
	rol ebx, 11

/* Subround 12 */
	xor edi, ebx
	lea eax, [eax+ebp+1352829926]
	and edi, edx
	mov ebp, ebx
	xor edi, ecx
	nop
	add eax, edi
	mov edi, [esi+40]
	rol eax, 14

/* Subround 13 */
	xor ebp, eax
	lea edx, [edx+edi+1352829926]
	and ebp, ecx
	mov edi, eax
	xor ebp, ebx
	nop
	add edx, ebp
	mov ebp, [esi+12]
	rol edx, 14

/* Subround 14 */
	xor edi, edx
	lea ecx, [ecx+ebp+1352829926]
	and edi, ebx
	mov ebp, edx
	xor edi, eax
	nop
	add ecx, edi
	mov edi, [esi+48]
	rol ecx, 12

/* Subround 15 */
	xor ebp, ecx
	lea ebx, [ebx+edi+1352829926]
	and ebp, eax
	mov edi, ecx
	xor ebp, edx
	xor edi, -1
	add ebx, ebp
	mov ebp, [esi+24]
	rol ebx, 6

/* Subround 16 */
	or edi, ebx
	lea eax, [eax+ebp+1548603684]
	xor edi, edx
	mov ebp, ebx
	add eax, edi
	mov edi, [esi+44]
	rol eax, 9

/* Subround 17 */
	xor ebp, -1
	lea edx, [edx+edi+1548603684]
	or ebp, eax
	mov edi, eax
	xor ebp, ecx
	xor edi, -1
	add edx, ebp
	mov ebp, [esi+12]
	rol edx, 13

/* Subround 18 */
	or edi, edx
	lea ecx, [ecx+ebp+1548603684]
	xor edi, ebx
	mov ebp, edx
	add ecx, edi
	mov edi, [esi+28]
	rol ecx, 15

/* Subround 19 */
	xor ebp, -1
	lea ebx, [ebx+edi+1548603684]
	or ebp, ecx
	mov edi, ecx
	xor ebp, eax
	xor edi, -1
	add ebx, ebp
	mov ebp, [esi]
	rol ebx, 7

/* Subround 20 */
	or edi, ebx
	lea eax, [eax+ebp+1548603684]
	xor edi, edx
	mov ebp, ebx
	add eax, edi
	mov edi, [esi+52]
	rol eax, 12

/* Subround 21 */
	xor ebp, -1
	lea edx, [edx+edi+1548603684]
	or ebp, eax
	mov edi, eax
	xor ebp, ecx
	xor edi, -1
	add edx, ebp
	mov ebp, [esi+20]
	rol edx, 8

/* Subround 22 */
	or edi, edx
	lea ecx, [ecx+ebp+1548603684]
	xor edi, ebx
	mov ebp, edx
	add ecx, edi
	mov edi, [esi+40]
	rol ecx, 9

/* Subround 23 */
	xor ebp, -1
	lea ebx, [ebx+edi+1548603684]
	or ebp, ecx
	mov edi, ecx
	xor ebp, eax
	xor edi, -1
	add ebx, ebp
	mov ebp, [esi+56]
	rol ebx, 11

/* Subround 24 */
	or edi, ebx
	lea eax, [eax+ebp+1548603684]
	xor edi, edx
	mov ebp, ebx
	add eax, edi
	mov edi, [esi+60]
	rol eax, 7

/* Subround 25 */
	xor ebp, -1
	lea edx, [edx+edi+1548603684]
	or ebp, eax
	mov edi, eax
	xor ebp, ecx
	xor edi, -1
	add edx, ebp
	mov ebp, [esi+32]
	rol edx, 7

/* Subround 26 */
	or edi, edx
	lea ecx, [ecx+ebp+1548603684]
	xor edi, ebx
	mov ebp, edx
	add ecx, edi
	mov edi, [esi+48]
	rol ecx, 12

/* Subround 27 */
	xor ebp, -1
	lea ebx, [ebx+edi+1548603684]
	or ebp, ecx
	mov edi, ecx
	xor ebp, eax
	xor edi, -1
	add ebx, ebp
	mov ebp, [esi+16]
	rol ebx, 7

/* Subround 28 */
	or edi, ebx
	lea eax, [eax+ebp+1548603684]
	xor edi, edx
	mov ebp, ebx
	add eax, edi
	mov edi, [esi+36]
	rol eax, 6

/* Subround 29 */
	xor ebp, -1
	lea edx, [edx+edi+1548603684]
	or ebp, eax
	mov edi, eax
	xor ebp, ecx
	xor edi, -1
	add edx, ebp
	mov ebp, [esi+4]
	rol edx, 15

/* Subround 30 */
	or edi, edx
	lea ecx, [ecx+ebp+1548603684]
	xor edi, ebx
	mov ebp, edx
	add ecx, edi
	mov edi, [esi+8]
	rol ecx, 13

/* Subround 31 */
	xor ebp, -1
	lea ebx, [ebx+edi+1548603684]
	or ebp, ecx
	mov edi, ecx
	xor ebp, eax
	xor edi, edx
	add ebx, ebp
	mov ebp, [esi+60]
	rol ebx, 11

/* Subround 32 */
	and edi, ebx
	lea eax, [eax+ebp+1836072691]
	xor edi, edx
	mov ebp, ebx
	add eax, edi
	mov edi, [esi+20]
	rol eax, 9

/* Subround 33 */
	xor ebp, ecx
	lea edx, [edx+edi+1836072691]
	and ebp, eax
	mov edi, eax
	xor ebp, ecx
	xor edi, ebx
	add edx, ebp
	mov ebp, [esi+4]
	rol edx, 7

/* Subround 34 */
	and edi, edx
	lea ecx, [ecx+ebp+1836072691]
	xor edi, ebx
	mov ebp, edx
	add ecx, edi
	mov edi, [esi+12]
	rol ecx, 15

/* Subround 35 */
	xor ebp, eax
	lea ebx, [ebx+edi+1836072691]
	and ebp, ecx
	mov edi, ecx
	xor ebp, eax
	xor edi, edx
	add ebx, ebp
	mov ebp, [esi+28]
	rol ebx, 11

/* Subround 36 */
	and edi, ebx
	lea eax, [eax+ebp+1836072691]
	xor edi, edx
	mov ebp, ebx
	add eax, edi
	mov edi, [esi+56]
	rol eax, 8

/* Subround 37 */
	xor ebp, ecx
	lea edx, [edx+edi+1836072691]
	and ebp, eax
	mov edi, eax
	xor ebp, ecx
	xor edi, ebx
	add edx, ebp
	mov ebp, [esi+24]
	rol edx, 6

/* Subround 38 */
	and edi, edx
	lea ecx, [ecx+ebp+1836072691]
	xor edi, ebx
	mov ebp, edx
	add ecx, edi
	mov edi, [esi+36]
	rol ecx, 6

/* Subround 39 */
	xor ebp, eax
	lea ebx, [ebx+edi+1836072691]
	and ebp, ecx
	mov edi, ecx
	xor ebp, eax
	xor edi, edx
	add ebx, ebp
	mov ebp, [esi+44]
	rol ebx, 14

/* Subround 40 */
	and edi, ebx
	lea eax, [eax+ebp+1836072691]
	xor edi, edx
	mov ebp, ebx
	add eax, edi
	mov edi, [esi+32]
	rol eax, 12

/* Subround 41 */
	xor ebp, ecx
	lea edx, [edx+edi+1836072691]
	and ebp, eax
	mov edi, eax
	xor ebp, ecx
	xor edi, ebx
	add edx, ebp
	mov ebp, [esi+48]
	rol edx, 13

/* Subround 42 */
	and edi, edx
	lea ecx, [ecx+ebp+1836072691]
	xor edi, ebx
	mov ebp, edx
	add ecx, edi
	mov edi, [esi+8]
	rol ecx, 5

/* Subround 43 */
	xor ebp, eax
	lea ebx, [ebx+edi+1836072691]
	and ebp, ecx
	mov edi, ecx
	xor ebp, eax
	xor edi, edx
	add ebx, ebp
	mov ebp, [esi+40]
	rol ebx, 14

/* Subround 44 */
	and edi, ebx
	lea eax, [eax+ebp+1836072691]
	xor edi, edx
	mov ebp, ebx
	add eax, edi
	mov edi, [esi]
	rol eax, 13

/* Subround 45 */
	xor ebp, ecx
	lea edx, [edx+edi+1836072691]
	and ebp, eax
	mov edi, eax
	xor ebp, ecx
	xor edi, ebx
	add edx, ebp
	mov ebp, [esi+16]
	rol edx, 13

/* Subround 46 */
	and edi, edx
	lea ecx, [ecx+ebp+1836072691]
	xor edi, ebx
	mov ebp, edx
	add ecx, edi
	mov edi, [esi+52]
	rol ecx, 7

/* Subround 47 */
	xor ebp, eax
	lea ebx, [ebx+edi+1836072691]
	and ebp, ecx
	mov edi, ecx
	xor ebp, eax
	add ebx, ebp
	mov ebp, [esi+32]
	rol ebx, 5

/* Subround 48 */
	xor edi, edx
	add eax, ebp
	xor edi, ebx
	mov ebp, [esi+24]
	add eax, edi
	mov edi, ebx
	rol eax, 15

/* Subround 49 */
	xor edi, ecx
	add edx, ebp
	xor edi, eax
	mov ebp, [esi+16]
	add edx, edi
	mov edi, eax
	rol edx, 5

/* Subround 50 */
	xor edi, ebx
	add ecx, ebp
	xor edi, edx
	mov ebp, [esi+4]
	add ecx, edi
	mov edi, edx
	rol ecx, 8

/* Subround 51 */
	xor edi, eax
	add ebx, ebp
	xor edi, ecx
	mov ebp, [esi+12]
	add ebx, edi
	mov edi, ecx
	rol ebx, 11

/* Subround 52 */
	xor edi, edx
	add eax, ebp
	xor edi, ebx
	mov ebp, [esi+44]
	add eax, edi
	mov edi, ebx
	rol eax, 14

/* Subround 53 */
	xor edi, ecx
	add edx, ebp
	xor edi, eax
	mov ebp, [esi+60]
	add edx, edi
	mov edi, eax
	rol edx, 14

/* Subround 54 */
	xor edi, ebx
	add ecx, ebp
	xor edi, edx
	mov ebp, [esi]
	add ecx, edi
	mov edi, edx
	rol ecx, 6

/* Subround 55 */
	xor edi, eax
	add ebx, ebp
	xor edi, ecx
	mov ebp, [esi+20]
	add ebx, edi
	mov edi, ecx
	rol ebx, 14

/* Subround 56 */
	xor edi, edx
	add eax, ebp
	xor edi, ebx
	mov ebp, [esi+48]
	add eax, edi
	mov edi, ebx
	rol eax, 6

/* Subround 57 */
	xor edi, ecx
	add edx, ebp
	xor edi, eax
	mov ebp, [esi+8]
	add edx, edi
	mov edi, eax
	rol edx, 9

/* Subround 58 */
	xor edi, ebx
	add ecx, ebp
	xor edi, edx
	mov ebp, [esi+52]
	add ecx, edi
	mov edi, edx
	rol ecx, 12

/* Subround 59 */
	xor edi, eax
	add ebx, ebp
	xor edi, ecx
	mov ebp, [esi+36]
	add ebx, edi
	mov edi, ecx
	rol ebx, 9

/* Subround 60 */
	xor edi, edx
	add eax, ebp
	xor edi, ebx
	mov ebp, [esi+28]
	add eax, edi
	mov edi, ebx
	rol eax, 12

/* Subround 61 */
	xor edi, ecx
	add edx, ebp
	xor edi, eax
	mov ebp, [esi+40]
	add edx, edi
	mov edi, eax
	rol edx, 5

/* Subround 62 */
	xor edi, ebx
	add ecx, ebp
	xor edi, edx
	mov ebp, [esi+56]
	add ecx, edi
	mov edi, edx
	rol ecx, 15

/* Subround 63 */
	xor edi, eax
	add ebx, ebp
	xor edi, ecx
	add ebx, edi
	mov edi, ecx
	rol ebx, 8

/* combine */
	push ebx
	mov edi, edx
	mov ebp, [esp+12]
	add edi, ebp
	mov ebp, [esp+24]
	add edi, ebp
	mov ebx, eax
	mov eax, edi
	mov ebp, [esp+16]
	add ebx, ebp
	mov ebp, [esp+28]
	add ebx, ebp
	mov edx, ecx
	mov ecx, [esp]
	mov ebp, [esp+8]
	add edx, ebp
	mov ebp, [esp+20]
	add edx, ebp
	mov ebp, [esp+32]
	add ecx, ebp
	mov ebp, [esp+4]
	add ecx, ebp
	add esp, 36
	mov edi, [esp+20]
	mov [edi], eax
	mov [edi+4], ebx
	mov [edi+8], ecx
	mov [edi+12], edx

	pop ebx
	pop edi
	pop esi
	pop ebp

	ret
  }
}
