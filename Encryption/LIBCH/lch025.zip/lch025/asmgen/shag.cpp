//
// shag.cpp
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#include <stdlib.h>
#include <iomanip.h>
#include "a2r160.hpp"
#include "shag.hpp"

SHAAsmGenerator::SHAAsmGenerator(ostream& os, const int shaVersion) :
  AsmGenerator(os), shaVersion(shaVersion)
{
}

void SHAAsmGenerator::Startup()
{
  int i;

  Push(ebp);
  Push(esi);
  Push(edi);
  Push(ebx);
  
  switch (callingConvention)
  {
  case WATCOMREGISTER:
    Push(ecx);
    Push(eax);
    break;
  case FASTCALL:
    Push(ecx);
    break;
  case CDECL:
    Mov(edx,esp,16+8);
    break;
  default:
    cerr <<"Unrecognized calling convention"<<endl;
    exit(-1);
  }

  Sub(esp,320);

  os <<endl;

  for(i=0; i<16; i+=2)
  {
    Mov(edi,edx,i*4);
    Mov(ebp,edx,(i+1)*4);
    BSwap(edi);
    BSwap(ebp);
    Mov(esp,i*4,edi);
    Mov(esp,(i+1)*4,ebp);
  }
  // do block expansion

  Mov(edi,esp,16*4-32);
  Mov(ebp,esp,16*4-28);

  for (i=16; i<78; i+=2)
    {
      Mov(ecx,esp,i*4-12);
      Mov(ebx,esp,i*4-8);

      Xor(ecx,edi);
      Xor(ebx,ebp);

      Mov(edi,esp,i*4-56);
      Mov(ebp,esp,i*4-52);

      Xor(ecx,edi);
      Xor(ebx,ebp);

      Mov(edi,esp,i*4-64);
      Mov(ebp,esp,i*4-60);

      Xor(ecx,edi);
      Xor(ebx,ebp);

      if ( shaVersion==1 )
	Rol(ecx,1);
      Mov(edi,esp,(i+2)*4-32);

      if ( shaVersion==1 )
	Rol(ebx,1);
      Mov(ebp,esp,(i+2)*4-28);

      Mov(esp,i*4,ecx);
      Mov(esp,(i+1)*4,ebx);
    }

  Mov(ecx,esp,78*4-12);
  Mov(ebx,esp,78*4-8);
  
  Xor(ecx,edi);
  Xor(ebx,ebp);
  
  Mov(edi,esp,78*4-56);
  Mov(ebp,esp,78*4-52);
  
  Xor(ecx,edi);
  Xor(ebx,ebp);
  
  Mov(edi,esp,78*4-64);
  Mov(ebp,esp,78*4-60);
  
  Xor(ecx,edi);
  Xor(ebx,ebp);

  if ( shaVersion==1 )
    Rol(ecx,1);

  if ( shaVersion==1 )
    Rol(ebx,1);

  Mov(esp,78*4,ecx);
  Mov(esp,79*4,ebx);

  // load chain variables
	
  switch ( callingConvention )
  {
  case WATCOMREGISTER:
    break;
  case FASTCALL:
    Mov(eax,esp,320);
    break;
  case CDECL:
    Mov(eax,esp,4+16+320);
    break;
  default:
    cerr <<"Unrecognized calling convention"<<endl;
    exit(-1);
  }

  Mov(ebx,eax,4);

  Mov(ecx,eax,8);
  Mov(edx,eax,12);

  Mov(edi,eax,16);
  Mov(eax,eax,0);
}

void SHAAsmGenerator::PrintRound1()
{
  a2r160 reg;

  Mov(ebp,reg[C]);
  for (int i=0; i<20; i+=2)
    {
      // e=a<<<5+e+M+K+d^(b&(c^d))
      // b=b<<<30
      int subround=i;

      Subround(subround);
      Xor(ebp,reg[D]);

      And(ebp,reg[B]);
      Mov(esi,reg[A]);

      Rol(esi,5);

      Add(reg[E],esi);
      Mov(esi,esp,4*subround); 

      Ror(reg[B],1);
      Xor(ebp,reg[D]);

      Ror(reg[B],1);
      Lea(reg[E],reg[E],1,esi,long(0x5a827999u));

      Add(reg[E],ebp);
      reg.Circulate();

      // e=a<<<5+e+M+K+d^(b&(c^d))
      // b=b<<<30
      subround++;

      Subround(subround);
      Mov(esi,reg[C]);

      Xor(esi,reg[D]);
      Mov(ebp,reg[A]);

      Rol(ebp,5);

      And(esi,reg[B]);
      Add(reg[E],ebp);

      Ror(reg[B],1);
      Mov(ebp,esp,4*subround); 

      Ror(reg[B],1);
      Xor(esi,reg[D]);

      Lea(reg[E],reg[E],1,ebp,long(0x5a827999u));
      Mov(ebp,reg[B]);

      Add(reg[E],esi);
      reg.Circulate();
    }
}

void SHAAsmGenerator::PrintRound2()
{
  a2r160 reg; 

  Mov(esi,esp,20*4);
  for (int i=20; i<40; i++)
    {
      // e=a<<<5+e+M+K+(c^b^d)
      // b=b<<<30
      // 6 cycles
      int subround=i;

      Subround(subround);
      Xor(ebp,reg[B]);

      Ror(reg[B],1);
      Xor(ebp,reg[D]);

      Ror(reg[B],1);
      Lea(reg[E],reg[E],1,esi,long(0x6ed9eba1u));

      Mov(esi,reg[A]);
      Add(reg[E],ebp);

      Rol(esi,5);

      Add(reg[E],esi);
      Mov(ebp,reg[B]);

      Mov(esi,esp,4*(subround+1)); 

      reg.Circulate();
    }
}

void SHAAsmGenerator::PrintRound3()
{
  a2r160 reg; 

  for (int i=40; i<60; i+=2)
    {
      // e=a<<<5+e+M+K+(d&(b|c))|(b&c)
      // b=b<<<30
      int subround=i;

      Subround(subround);

      Or(ebp,reg[B]);
      Lea(reg[E],reg[E],1,esi,long(0x8f1bbcdcu));

      And(ebp,reg[D]);
      Mov(esi,reg[B]);

      Ror(reg[B],1);
      And(esi,reg[C]);

      Or(esi,ebp);
      Mov(ebp,reg[A]);

      Add(reg[E],esi);
      Mov(esi,esp,(subround+1)*4);

      Rol(ebp,5);

      Ror(reg[B],1);
      Add(reg[E],ebp);

      Mov(ebp,reg[B]);

      reg.Circulate();

      // e=a<<<5+e+M+K+(d&(b|c))|(b&c)
      // b=b<<<30
      subround++;

      Subround(subround);

      Lea(reg[E],reg[E],1,esi,long(0x8f1bbcdcu));

      Or(ebp,reg[B]);
      Mov(esi,reg[B]);

      And(ebp,reg[D]);
      And(esi,reg[C]);

      Ror(reg[B],1);
      Or(esi,ebp);

      Mov(ebp,reg[A]);
      Add(reg[E],esi);

      Rol(ebp,5);

      Ror(reg[B],1);
      Mov(esi,esp,(subround+1)*4);

      Add(reg[E],ebp);
      Mov(ebp,reg[B]);

      reg.Circulate();
    }
}
 
void SHAAsmGenerator::PrintRound4()
{
  a2r160 reg; 

  Mov(ebp,reg[C]);
  for (int i=60; i<80; i++)
    {
      // e=a<<<5+e+M+K+(b^c^d)
      // b=b<<<30
      // 6 cycles

      Subround(i);
      Xor(ebp,reg[B]);

      Xor(ebp,reg[D]);
      Mov(esi,reg[A]);

      Rol(esi,5);

      Ror(reg[B],1);
      Add(reg[E],esi);

      Ror(reg[B],1);
      Mov(esi,esp,4*i); 

      Lea(reg[E],reg[E],1,ebp,long(0xca62c1d6u));
      Mov(ebp,reg[B]);

      Add(reg[E],esi);

      reg.Circulate();
    }
}

void SHAAsmGenerator::Body()
{
  PrintRound1();
  PrintRound2();
  PrintRound3();
  PrintRound4();
}


void SHAAsmGenerator::Cleanup()
{
  switch ( callingConvention )
  {
  case WATCOMREGISTER: 
  case FASTCALL: 
    Mov(esi,esp,320);
    Add(esp,324);
    break;
  case CDECL:
    Mov(esi,esp,4+16+320);
    Add(esp,320);
    break;
  default:
    cerr <<"Unrecognized calling convention"<<endl;
    exit(-1);
  }

  Mov(ebp,esi,16);
  Add(edi,ebp);

  Mov(esi,16,edi);

  Mov(ebp,esi,0);
  Mov(edi,esi,4);
  Add(eax,ebp);
  Add(ebx,edi);
  Mov(esi,0,eax);
  Mov(esi,4,ebx);
  Mov(ebp,esi,8);
  Mov(edi,esi,12);
  Add(ecx,ebp);
  Add(edx,edi);
  Mov(esi,8,ecx);
  Mov(esi,12,edx);

  os <<endl;

  if ( callingConvention==WATCOMREGISTER )
    Pop(ecx);
  Pop(ebx);
  Pop(edi);
  Pop(esi);
  Pop(ebp);

  os <<endl;

  Ret();
}
