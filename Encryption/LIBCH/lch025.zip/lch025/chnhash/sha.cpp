// 
// sha.cpp
//
// Abstract base class for the two versions of the
// NIST/NSA's Secure Hash Algorithm
// (first defined in FIPS180 but modified in FIPS180-1)
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#include <string.h>
#include <assert.h>
#include "sha.hpp"
#include "chmisc.hpp"

const u32 SHA::H0=0x67452301;
const u32 SHA::H1=0xefcdab89;
const u32 SHA::H2=0x98badcfe;
const u32 SHA::H3=0x10325476;
const u32 SHA::H4=0xc3d2e1f0;

SHA::SHA() : ChainHash(512,160)
{
  H[0]=H0;
  H[1]=H1;
  H[2]=H2;
  H[3]=H3;
  H[4]=H4;
}

SHA::~SHA()
{
}

void SHA::ProcessFinalBlock(const void* block, const int size)
{
  assert ( size>=0 && size<=64);

  _bitCount+=(size*8);

  int zeroBytesInPad=( size<= 55 ) ? 55-size: 119-size;

  int numBytes=(size+9+zeroBytesInPad);

  if ( numBytes==128 )
    {
      u32 bigBuf[32];
      u8* curByte=(u8*) bigBuf;

      memcpy(curByte,block,size); curByte+=size;

      *(curByte++)=0x80;
 
      memset(curByte,0,zeroBytesInPad); // curByte+=zeroBytesInPad;

      bigBuf[30]=BSwap(CHMisc::High32Of64(_bitCount));
      bigBuf[31]=BSwap(CHMisc::Low32Of64(_bitCount));

      ProcessBlock(bigBuf);
      ProcessBlock(bigBuf+16);
    }
  else //  numBytes == 64 
    {
      u8* curByte=(u8*) buf;
      memcpy(curByte,block,size); curByte+=size;

      *(curByte++)=0x80;
 
      memset(curByte,0,zeroBytesInPad); // curByte+=zeroBytesInPad;

      buf[14]=BSwap(CHMisc::High32Of64(_bitCount));
      buf[15]=BSwap(CHMisc::Low32Of64(_bitCount));

      ProcessBlock(buf);
    }
}

void SHA::Reset()
{
  H[0]=H0;
  H[1]=H1;
  H[2]=H2;
  H[3]=H3;
  H[4]=H4;

  _bitCount=0;
}

void SHA::ChainVariables(void* buffer) const
{
  u32 cvCopy[5];
  memcpy(cvCopy,H,20);
  CHMisc::MemSwap(cvCopy,5);
  memcpy(buffer,cvCopy,20);
}
