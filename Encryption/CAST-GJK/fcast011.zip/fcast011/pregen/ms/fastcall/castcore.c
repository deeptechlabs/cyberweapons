/* Copyright (C) 1996-7 by Peter Gutmann (pgut001@cs.auckland.ac.nz), */
/*                         Leonard Janke (janke@unixg.ubc.ca), and */
/*                         Vesa Karvonen (vkarvone@mail.student.oulu.fi). */
#include "cast128.h"


void __declspec(naked) __fastcall castEncrypt(LONG* K, BYTE* data)
{
  __asm{

	push ebp
	push esi
	push edi
	push ebx
	mov ebp, ecx
	push edx
	mov edi, [edx]
	mov esi, [edx+4]
	bswap esi
	bswap edi

/* ooooooo */
/* link 0 */
/* ooooooo */
	mov eax, [ebp]
	mov cl, [ebp+64]
	add eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	xor edx, ecx
	mov ebx, S3[ebx*4]
	sub edx, ebx
	mov eax, S4[eax*4]
	add edx, eax
/* ooooooo */
/* link 1 */
/* ooooooo */
	mov eax, [ebp+4]
	xor edi, edx
	mov cl, [ebp+68]
	xor eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	sub edx, ecx
	mov ebx, S3[ebx*4]
	add edx, ebx
	mov eax, S4[eax*4]
	xor edx, eax
/* ooooooo */
/* link 2 */
/* ooooooo */
	mov eax, [ebp+8]
	xor esi, edx
	mov cl, [ebp+72]
	sub eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	add edx, ecx
	mov ebx, S3[ebx*4]
	xor edx, ebx
	mov eax, S4[eax*4]
	sub edx, eax
/* ooooooo */
/* link 3 */
/* ooooooo */
	mov eax, [ebp+12]
	xor edi, edx
	mov cl, [ebp+76]
	add eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	xor edx, ecx
	mov ebx, S3[ebx*4]
	sub edx, ebx
	mov eax, S4[eax*4]
	add edx, eax
/* ooooooo */
/* link 4 */
/* ooooooo */
	mov eax, [ebp+16]
	xor esi, edx
	mov cl, [ebp+80]
	xor eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	sub edx, ecx
	mov ebx, S3[ebx*4]
	add edx, ebx
	mov eax, S4[eax*4]
	xor edx, eax
/* ooooooo */
/* link 5 */
/* ooooooo */
	mov eax, [ebp+20]
	xor edi, edx
	mov cl, [ebp+84]
	sub eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	add edx, ecx
	mov ebx, S3[ebx*4]
	xor edx, ebx
	mov eax, S4[eax*4]
	sub edx, eax
/* ooooooo */
/* link 6 */
/* ooooooo */
	mov eax, [ebp+24]
	xor esi, edx
	mov cl, [ebp+88]
	add eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	xor edx, ecx
	mov ebx, S3[ebx*4]
	sub edx, ebx
	mov eax, S4[eax*4]
	add edx, eax
/* ooooooo */
/* link 7 */
/* ooooooo */
	mov eax, [ebp+28]
	xor edi, edx
	mov cl, [ebp+92]
	xor eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	sub edx, ecx
	mov ebx, S3[ebx*4]
	add edx, ebx
	mov eax, S4[eax*4]
	xor edx, eax
/* ooooooo */
/* link 8 */
/* ooooooo */
	mov eax, [ebp+32]
	xor esi, edx
	mov cl, [ebp+96]
	sub eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	add edx, ecx
	mov ebx, S3[ebx*4]
	xor edx, ebx
	mov eax, S4[eax*4]
	sub edx, eax
/* ooooooo */
/* link 9 */
/* ooooooo */
	mov eax, [ebp+36]
	xor edi, edx
	mov cl, [ebp+100]
	add eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	xor edx, ecx
	mov ebx, S3[ebx*4]
	sub edx, ebx
	mov eax, S4[eax*4]
	add edx, eax
/* ooooooo */
/* link 10 */
/* ooooooo */
	mov eax, [ebp+40]
	xor esi, edx
	mov cl, [ebp+104]
	xor eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	sub edx, ecx
	mov ebx, S3[ebx*4]
	add edx, ebx
	mov eax, S4[eax*4]
	xor edx, eax
/* ooooooo */
/* link 11 */
/* ooooooo */
	mov eax, [ebp+44]
	xor edi, edx
	mov cl, [ebp+108]
	sub eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	add edx, ecx
	mov ebx, S3[ebx*4]
	xor edx, ebx
	mov eax, S4[eax*4]
	sub edx, eax
/* ooooooo */
/* link 12 */
/* ooooooo */
	mov eax, [ebp+48]
	xor esi, edx
	mov cl, [ebp+112]
	add eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	xor edx, ecx
	mov ebx, S3[ebx*4]
	sub edx, ebx
	mov eax, S4[eax*4]
	add edx, eax
/* ooooooo */
/* link 13 */
/* ooooooo */
	mov eax, [ebp+52]
	xor edi, edx
	mov cl, [ebp+116]
	xor eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	sub edx, ecx
	mov ebx, S3[ebx*4]
	add edx, ebx
	mov eax, S4[eax*4]
	xor edx, eax
/* ooooooo */
/* link 14 */
/* ooooooo */
	mov eax, [ebp+56]
	xor esi, edx
	mov cl, [ebp+120]
	sub eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	add edx, ecx
	mov ebx, S3[ebx*4]
	xor edx, ebx
	mov eax, S4[eax*4]
	sub edx, eax
/* ooooooo */
/* link 15 */
/* ooooooo */
	mov eax, [ebp+60]
	xor edi, edx
	mov cl, [ebp+124]
	add eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	xor edx, ecx
	mov ebx, S3[ebx*4]
	sub edx, ebx
	mov eax, S4[eax*4]
	add edx, eax
	xor esi, edx
	bswap esi
	bswap edi
	pop edx
	mov [edx], esi
	mov [edx+4], edi

	pop ebx
	pop edi
	pop esi
	pop ebp

	ret
  }
}

void __declspec(naked) __fastcall castDecrypt(LONG* K, BYTE* data)
{
  __asm{

	push ebp
	push esi
	push edi
	push ebx
	mov ebp, ecx
	push edx
	mov edi, [edx]
	mov esi, [edx+4]
	bswap esi
	bswap edi

/* ooooooo */
/* link 15 */
/* ooooooo */
	mov eax, [ebp+60]
	mov cl, [ebp+124]
	add eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	xor edx, ecx
	mov ebx, S3[ebx*4]
	sub edx, ebx
	mov eax, S4[eax*4]
	add edx, eax
/* ooooooo */
/* link 14 */
/* ooooooo */
	mov eax, [ebp+56]
	xor edi, edx
	mov cl, [ebp+120]
	sub eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	add edx, ecx
	mov ebx, S3[ebx*4]
	xor edx, ebx
	mov eax, S4[eax*4]
	sub edx, eax
/* ooooooo */
/* link 13 */
/* ooooooo */
	mov eax, [ebp+52]
	xor esi, edx
	mov cl, [ebp+116]
	xor eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	sub edx, ecx
	mov ebx, S3[ebx*4]
	add edx, ebx
	mov eax, S4[eax*4]
	xor edx, eax
/* ooooooo */
/* link 12 */
/* ooooooo */
	mov eax, [ebp+48]
	xor edi, edx
	mov cl, [ebp+112]
	add eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	xor edx, ecx
	mov ebx, S3[ebx*4]
	sub edx, ebx
	mov eax, S4[eax*4]
	add edx, eax
/* ooooooo */
/* link 11 */
/* ooooooo */
	mov eax, [ebp+44]
	xor esi, edx
	mov cl, [ebp+108]
	sub eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	add edx, ecx
	mov ebx, S3[ebx*4]
	xor edx, ebx
	mov eax, S4[eax*4]
	sub edx, eax
/* ooooooo */
/* link 10 */
/* ooooooo */
	mov eax, [ebp+40]
	xor edi, edx
	mov cl, [ebp+104]
	xor eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	sub edx, ecx
	mov ebx, S3[ebx*4]
	add edx, ebx
	mov eax, S4[eax*4]
	xor edx, eax
/* ooooooo */
/* link 9 */
/* ooooooo */
	mov eax, [ebp+36]
	xor esi, edx
	mov cl, [ebp+100]
	add eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	xor edx, ecx
	mov ebx, S3[ebx*4]
	sub edx, ebx
	mov eax, S4[eax*4]
	add edx, eax
/* ooooooo */
/* link 8 */
/* ooooooo */
	mov eax, [ebp+32]
	xor edi, edx
	mov cl, [ebp+96]
	sub eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	add edx, ecx
	mov ebx, S3[ebx*4]
	xor edx, ebx
	mov eax, S4[eax*4]
	sub edx, eax
/* ooooooo */
/* link 7 */
/* ooooooo */
	mov eax, [ebp+28]
	xor esi, edx
	mov cl, [ebp+92]
	xor eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	sub edx, ecx
	mov ebx, S3[ebx*4]
	add edx, ebx
	mov eax, S4[eax*4]
	xor edx, eax
/* ooooooo */
/* link 6 */
/* ooooooo */
	mov eax, [ebp+24]
	xor edi, edx
	mov cl, [ebp+88]
	add eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	xor edx, ecx
	mov ebx, S3[ebx*4]
	sub edx, ebx
	mov eax, S4[eax*4]
	add edx, eax
/* ooooooo */
/* link 5 */
/* ooooooo */
	mov eax, [ebp+20]
	xor esi, edx
	mov cl, [ebp+84]
	sub eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	add edx, ecx
	mov ebx, S3[ebx*4]
	xor edx, ebx
	mov eax, S4[eax*4]
	sub edx, eax
/* ooooooo */
/* link 4 */
/* ooooooo */
	mov eax, [ebp+16]
	xor edi, edx
	mov cl, [ebp+80]
	xor eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	sub edx, ecx
	mov ebx, S3[ebx*4]
	add edx, ebx
	mov eax, S4[eax*4]
	xor edx, eax
/* ooooooo */
/* link 3 */
/* ooooooo */
	mov eax, [ebp+12]
	xor esi, edx
	mov cl, [ebp+76]
	add eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	xor edx, ecx
	mov ebx, S3[ebx*4]
	sub edx, ebx
	mov eax, S4[eax*4]
	add edx, eax
/* ooooooo */
/* link 2 */
/* ooooooo */
	mov eax, [ebp+8]
	xor edi, edx
	mov cl, [ebp+72]
	sub eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	add edx, ecx
	mov ebx, S3[ebx*4]
	xor edx, ebx
	mov eax, S4[eax*4]
	sub edx, eax
/* ooooooo */
/* link 1 */
/* ooooooo */
	mov eax, [ebp+4]
	xor esi, edx
	mov cl, [ebp+68]
	xor eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	sub edx, ecx
	mov ebx, S3[ebx*4]
	add edx, ebx
	mov eax, S4[eax*4]
	xor edx, eax
/* ooooooo */
/* link 0 */
/* ooooooo */
	mov eax, [ebp]
	xor edi, edx
	mov cl, [ebp+64]
	add eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	xor edx, ecx
	mov ebx, S3[ebx*4]
	sub edx, ebx
	mov eax, S4[eax*4]
	add edx, eax
	xor esi, edx
	bswap esi
	bswap edi
	pop edx
	mov [edx], esi
	mov [edx+4], edi

	pop ebx
	pop edi
	pop esi
	pop ebp

	ret
  }
}

void __declspec(naked) __fastcall castEncryptCBC(BYTE* in, BYTE* out, int noByte, LONG* KEY, BYTE* iv)
{
  __asm{
	push ebp
	push esi
	push edi
	push ebx

	mov ebp, [esp+24]
	mov eax, ecx
	mov ebx, [esp+20]
	sub esp, 12
	mov [esp+4], ecx
	mov [esp+8], edx
	lea eax, [eax+ebx]
	lea edx, [edx+ebx]
	shr ebx, 3
	mov ecx, [esp+40]
	mov [esp+4], eax
	neg ebx
	mov [esp+8], edx
	mov [esp], ebx
	mov edi, [ecx]
	mov esi, [ecx+4]
	bswap edi
	bswap esi

CAST128CBCEncryptLoop: 	mov ecx, [esp+4]
	mov ebx, [esp]
	mov eax, [ecx+8*ebx]
	mov edx, [ecx+8*ebx+4]
	bswap eax
	bswap edx
	xor edi, eax
	xor esi, edx
/* ooooooo */
/* link 0 */
/* ooooooo */
	mov eax, [ebp]
	mov cl, [ebp+64]
	add eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	xor edx, ecx
	mov ebx, S3[ebx*4]
	sub edx, ebx
	mov eax, S4[eax*4]
	add edx, eax
/* ooooooo */
/* link 1 */
/* ooooooo */
	mov eax, [ebp+4]
	xor edi, edx
	mov cl, [ebp+68]
	xor eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	sub edx, ecx
	mov ebx, S3[ebx*4]
	add edx, ebx
	mov eax, S4[eax*4]
	xor edx, eax
/* ooooooo */
/* link 2 */
/* ooooooo */
	mov eax, [ebp+8]
	xor esi, edx
	mov cl, [ebp+72]
	sub eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	add edx, ecx
	mov ebx, S3[ebx*4]
	xor edx, ebx
	mov eax, S4[eax*4]
	sub edx, eax
/* ooooooo */
/* link 3 */
/* ooooooo */
	mov eax, [ebp+12]
	xor edi, edx
	mov cl, [ebp+76]
	add eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	xor edx, ecx
	mov ebx, S3[ebx*4]
	sub edx, ebx
	mov eax, S4[eax*4]
	add edx, eax
/* ooooooo */
/* link 4 */
/* ooooooo */
	mov eax, [ebp+16]
	xor esi, edx
	mov cl, [ebp+80]
	xor eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	sub edx, ecx
	mov ebx, S3[ebx*4]
	add edx, ebx
	mov eax, S4[eax*4]
	xor edx, eax
/* ooooooo */
/* link 5 */
/* ooooooo */
	mov eax, [ebp+20]
	xor edi, edx
	mov cl, [ebp+84]
	sub eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	add edx, ecx
	mov ebx, S3[ebx*4]
	xor edx, ebx
	mov eax, S4[eax*4]
	sub edx, eax
/* ooooooo */
/* link 6 */
/* ooooooo */
	mov eax, [ebp+24]
	xor esi, edx
	mov cl, [ebp+88]
	add eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	xor edx, ecx
	mov ebx, S3[ebx*4]
	sub edx, ebx
	mov eax, S4[eax*4]
	add edx, eax
/* ooooooo */
/* link 7 */
/* ooooooo */
	mov eax, [ebp+28]
	xor edi, edx
	mov cl, [ebp+92]
	xor eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	sub edx, ecx
	mov ebx, S3[ebx*4]
	add edx, ebx
	mov eax, S4[eax*4]
	xor edx, eax
/* ooooooo */
/* link 8 */
/* ooooooo */
	mov eax, [ebp+32]
	xor esi, edx
	mov cl, [ebp+96]
	sub eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	add edx, ecx
	mov ebx, S3[ebx*4]
	xor edx, ebx
	mov eax, S4[eax*4]
	sub edx, eax
/* ooooooo */
/* link 9 */
/* ooooooo */
	mov eax, [ebp+36]
	xor edi, edx
	mov cl, [ebp+100]
	add eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	xor edx, ecx
	mov ebx, S3[ebx*4]
	sub edx, ebx
	mov eax, S4[eax*4]
	add edx, eax
/* ooooooo */
/* link 10 */
/* ooooooo */
	mov eax, [ebp+40]
	xor esi, edx
	mov cl, [ebp+104]
	xor eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	sub edx, ecx
	mov ebx, S3[ebx*4]
	add edx, ebx
	mov eax, S4[eax*4]
	xor edx, eax
/* ooooooo */
/* link 11 */
/* ooooooo */
	mov eax, [ebp+44]
	xor edi, edx
	mov cl, [ebp+108]
	sub eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	add edx, ecx
	mov ebx, S3[ebx*4]
	xor edx, ebx
	mov eax, S4[eax*4]
	sub edx, eax
/* ooooooo */
/* link 12 */
/* ooooooo */
	mov eax, [ebp+48]
	xor esi, edx
	mov cl, [ebp+112]
	add eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	xor edx, ecx
	mov ebx, S3[ebx*4]
	sub edx, ebx
	mov eax, S4[eax*4]
	add edx, eax
/* ooooooo */
/* link 13 */
/* ooooooo */
	mov eax, [ebp+52]
	xor edi, edx
	mov cl, [ebp+116]
	xor eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	sub edx, ecx
	mov ebx, S3[ebx*4]
	add edx, ebx
	mov eax, S4[eax*4]
	xor edx, eax
/* ooooooo */
/* link 14 */
/* ooooooo */
	mov eax, [ebp+56]
	xor esi, edx
	mov cl, [ebp+120]
	sub eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	add edx, ecx
	mov ebx, S3[ebx*4]
	xor edx, ebx
	mov eax, S4[eax*4]
	sub edx, eax
/* ooooooo */
/* link 15 */
/* ooooooo */
	mov eax, [ebp+60]
	xor edi, edx
	mov cl, [ebp+124]
	add eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	xor edx, ecx
	mov ebx, S3[ebx*4]
	sub edx, ebx
	mov eax, S4[eax*4]
	add edx, eax
	xor esi, edx
	mov ebx, [esp]
	mov ecx, [esp+8]
	mov eax, esi
	mov edx, edi
	mov esi, edx
	mov edi, eax
	bswap eax
	bswap edx
	mov [ecx+8*ebx], eax
	mov [ecx+8*ebx+4], edx
	inc ebx
	mov [esp], ebx
	jne CAST128CBCEncryptLoop
	mov ecx, [esp+40]
	add esp, 12
	mov [ecx], eax
	mov [ecx+4], edx

	pop ebx
	pop edi
	pop esi
	pop ebp

	ret 12
  }
}

void __declspec(naked) __fastcall castDecryptCBC(BYTE* in, BYTE* out, int noByte, LONG* KEY, BYTE* iv)
{
  __asm{
/* startup */
	push ebp
	push esi
	push edi
	push ebx

	mov ebp, [esp+24]
	mov eax, ecx
	mov ebx, [esp+20]
	sub esp, 28
	mov [esp+4], ecx
	mov [esp+8], edx
	lea eax, [eax+ebx]
	lea edx, [edx+ebx]
	shr ebx, 3
	mov ecx, [esp+56]
	mov [esp+4], eax
	neg ebx
	mov [esp+8], edx
	mov [esp], ebx
	mov eax, [ecx]
	mov edx, [ecx+4]
	bswap eax
	bswap edx
	mov [esp+12], eax
	mov [esp+16], edx

CAST128CBCDecryptLoop: 	mov ecx, [esp+4]
	mov ebx, [esp]
	mov eax, [ecx+8*ebx]
	mov edx, [ecx+8*ebx+4]
	bswap eax
	bswap edx
	mov [esp+20], eax
	mov [esp+24], edx
	mov edi, eax
	mov esi, edx
/* ooooooo */
/* link 15 */
/* ooooooo */
	mov eax, [ebp+60]
	mov cl, [ebp+124]
	add eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	xor edx, ecx
	mov ebx, S3[ebx*4]
	sub edx, ebx
	mov eax, S4[eax*4]
	add edx, eax
/* ooooooo */
/* link 14 */
/* ooooooo */
	mov eax, [ebp+56]
	xor edi, edx
	mov cl, [ebp+120]
	sub eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	add edx, ecx
	mov ebx, S3[ebx*4]
	xor edx, ebx
	mov eax, S4[eax*4]
	sub edx, eax
/* ooooooo */
/* link 13 */
/* ooooooo */
	mov eax, [ebp+52]
	xor esi, edx
	mov cl, [ebp+116]
	xor eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	sub edx, ecx
	mov ebx, S3[ebx*4]
	add edx, ebx
	mov eax, S4[eax*4]
	xor edx, eax
/* ooooooo */
/* link 12 */
/* ooooooo */
	mov eax, [ebp+48]
	xor edi, edx
	mov cl, [ebp+112]
	add eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	xor edx, ecx
	mov ebx, S3[ebx*4]
	sub edx, ebx
	mov eax, S4[eax*4]
	add edx, eax
/* ooooooo */
/* link 11 */
/* ooooooo */
	mov eax, [ebp+44]
	xor esi, edx
	mov cl, [ebp+108]
	sub eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	add edx, ecx
	mov ebx, S3[ebx*4]
	xor edx, ebx
	mov eax, S4[eax*4]
	sub edx, eax
/* ooooooo */
/* link 10 */
/* ooooooo */
	mov eax, [ebp+40]
	xor edi, edx
	mov cl, [ebp+104]
	xor eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	sub edx, ecx
	mov ebx, S3[ebx*4]
	add edx, ebx
	mov eax, S4[eax*4]
	xor edx, eax
/* ooooooo */
/* link 9 */
/* ooooooo */
	mov eax, [ebp+36]
	xor esi, edx
	mov cl, [ebp+100]
	add eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	xor edx, ecx
	mov ebx, S3[ebx*4]
	sub edx, ebx
	mov eax, S4[eax*4]
	add edx, eax
/* ooooooo */
/* link 8 */
/* ooooooo */
	mov eax, [ebp+32]
	xor edi, edx
	mov cl, [ebp+96]
	sub eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	add edx, ecx
	mov ebx, S3[ebx*4]
	xor edx, ebx
	mov eax, S4[eax*4]
	sub edx, eax
/* ooooooo */
/* link 7 */
/* ooooooo */
	mov eax, [ebp+28]
	xor esi, edx
	mov cl, [ebp+92]
	xor eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	sub edx, ecx
	mov ebx, S3[ebx*4]
	add edx, ebx
	mov eax, S4[eax*4]
	xor edx, eax
/* ooooooo */
/* link 6 */
/* ooooooo */
	mov eax, [ebp+24]
	xor edi, edx
	mov cl, [ebp+88]
	add eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	xor edx, ecx
	mov ebx, S3[ebx*4]
	sub edx, ebx
	mov eax, S4[eax*4]
	add edx, eax
/* ooooooo */
/* link 5 */
/* ooooooo */
	mov eax, [ebp+20]
	xor esi, edx
	mov cl, [ebp+84]
	sub eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	add edx, ecx
	mov ebx, S3[ebx*4]
	xor edx, ebx
	mov eax, S4[eax*4]
	sub edx, eax
/* ooooooo */
/* link 4 */
/* ooooooo */
	mov eax, [ebp+16]
	xor edi, edx
	mov cl, [ebp+80]
	xor eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	sub edx, ecx
	mov ebx, S3[ebx*4]
	add edx, ebx
	mov eax, S4[eax*4]
	xor edx, eax
/* ooooooo */
/* link 3 */
/* ooooooo */
	mov eax, [ebp+12]
	xor esi, edx
	mov cl, [ebp+76]
	add eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	xor edx, ecx
	mov ebx, S3[ebx*4]
	sub edx, ebx
	mov eax, S4[eax*4]
	add edx, eax
/* ooooooo */
/* link 2 */
/* ooooooo */
	mov eax, [ebp+8]
	xor edi, edx
	mov cl, [ebp+72]
	sub eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	add edx, ecx
	mov ebx, S3[ebx*4]
	xor edx, ebx
	mov eax, S4[eax*4]
	sub edx, eax
/* ooooooo */
/* link 1 */
/* ooooooo */
	mov eax, [ebp+4]
	xor esi, edx
	mov cl, [ebp+68]
	xor eax, esi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	sub edx, ecx
	mov ebx, S3[ebx*4]
	add edx, ebx
	mov eax, S4[eax*4]
	xor edx, eax
/* ooooooo */
/* link 0 */
/* ooooooo */
	mov eax, [ebp]
	xor edi, edx
	mov cl, [ebp+64]
	add eax, edi
	add cl, 16
	rol eax, cl
	xor edx, edx
	xor ecx, ecx
	mov dl, ah
	mov cl, al
	shr eax, 16
	xor ebx, ebx
	mov bl, ah
	mov edx, S1[edx*4]
	and eax, 255
	mov ecx, S2[ecx*4]
	xor edx, ecx
	mov ebx, S3[ebx*4]
	sub edx, ebx
	mov eax, S4[eax*4]
	add edx, eax
	xor esi, edx
/* loop end */
	mov ebx, [esp]
	mov eax, [esp+12]
	mov edx, [esp+16]
	xor esi, eax
	xor edi, edx
	mov ecx, [esp+8]
	mov eax, [esp+20]
	mov edx, [esp+24]
	mov [esp+12], eax
	mov [esp+16], edx
	bswap esi
	bswap edi
	mov [ecx+8*ebx], esi
	mov [ecx+8*ebx+4], edi
	inc ebx
	mov [esp], ebx
	jne CAST128CBCDecryptLoop
/* cleanup */
	mov ecx, [esp+56]
	add esp, 28
	bswap eax
	bswap edx
	mov [ecx], eax
	mov [ecx+4], edx

	pop ebx
	pop edi
	pop esi
	pop ebp

	ret 12
  }
}
