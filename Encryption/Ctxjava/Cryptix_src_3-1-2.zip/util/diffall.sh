#!/bin/sh
diff --ignore-space-change --ignore-blank-lines --context=2 --report-identical-files --recursive $*
