//
// a2r160.hpp 
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#ifndef _A2R160_HPP
#define _A2R160_HPP

#include "asmgen.hpp"

enum alias { A=0, B=1, C=2, D=3, E=4 };

class a2r160
{
private:
 int offset;
public:
 a2r160() { offset=0; }
 void Circulate();
 const Register& operator[](alias);
};

#endif
