// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.keys;
import org.logi.crypto.*;
import org.logi.crypto.hash.*;
import org.logi.crypto.sign.*;

import java.math.BigInteger;

import java.io.IOException;
import java.io.InvalidObjectException;
import java.io.StreamTokenizer;
import java.io.StringReader;

/**
 * An instance of this class handles a single RSA key.
 * <p>
 * The RSA algorithm is probably the best known and most widely used
 * public key algorithm. Breaking one RSA key is believed to be as
 * difficult as factoring the modulus (n) of the group in which calculations
 * are done. When speaking of the size of an RSA key, it is understood
 * to be the size of this modulus.
 * <p>
 * The first 512 bit number is expected to be factored by the end of 1999.
 * 1024 bits should be more than enough in most cases, but the clinically
 * paranoid may want to use up to 4096 bit keys.
 * <p>
 * Each RSA key is a pair (r,n) of integers and matches another key (s,n).
 * If P is a block of plain data represented as an integer smaller than n,
 * then it can be encrypted with the transformation:
 * <blockquote>
 *   <code>E = (P^r) mod n</code>
 * </blockquote>
 * which has the inverse transformation:
 * <blockquote>
 *   <code>P = (E^s) mod n</code>
 * </blockquote>
 * <p>
 * The key's owner will keep one key secret and publish the other as widely
 * as possible. This allows anyone who gets hold of the public key to
 * encrypt data which can only be decrypted with the corresponding private
 * key. The public key in the pair will always use the exponent 65537.
 * <p>
 * Data that is encrypted with a private key can similarly only be
 * decrypted with the corresponding public key. This is useful for digital
 * signatures.
 * <p>
 * When P is created from an array of bytes, it will correspond to as many
 * bytes of plain data as the bytes needed to store n, less one. When
 * encrypting less than a full block of data, the data should be put in the
 * most significant bytes of the plaintext-block and appended with random
 * data. This is done by all relevant classes in the logi.crypto library.
 * The plaintext block is encrypted to form a ciphertext block with as many
 * bytes as are needed to store the modulus.
 * <p>
 * This implementation was originally done from a description given in
 * Gallian's <i>Contemporary Abstract Algebra</i>, but various changes
 * from various sources have been incorporated.
 * <p>
 * When a key-pair is created, the private key will actually be an instance
 * of the RSAKeyChin class, which uses the Chinese Remainder Theorem to speed
 * up exponentiation.
 * <p>
 * The CDS for the RSAKey class is <code>RSAKey(r,n,pub)</code> for a public key,
 * <code>RSAKey(r,n,pri)</code> for a private key or <code>RSAKey(r,n,p)</code>
 * for a private key where we know one factor of <code>n</code>. In all cases
 * <code>r</code>, <code>n</code> and  <code>p</code> are hexadecimal numbers.
 *
 * @see org.logi.crypto.Crypto#fromString(String)
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class RSAKey extends K implements CipherKey,SignatureKey {
    
    /** <code>R</code> is the exponent used in all created public keys. */
    protected static final BigInteger R=BigInteger.valueOf(65537);
    
    /** The RSA key exponent */
    protected BigInteger r;
    
    /** The RSA key modulus */
    protected BigInteger n;
    
    /** Is it a private key? */
    protected boolean pri;
    
    /** The fingerprint for the other key in the pair, or null. */
    protected Fingerprint matchPrint=null;
    
    ///////////////////////////////////////////////////////////////////////
    // KEY MANAGEMENT CODE
    
    /**
     * Create a new RSA key <code>(r,n)</code>.
     * It is a private key if <code>pri</code> is true.
     */
    public RSAKey(BigInteger r, BigInteger n, boolean pri) {
        super();
        this.pri = pri;
        this.r = r;
        this.n = n;
    }
    
    /**
     * If "RSAKey( key )" is a valid CDS for an RSAKey, then
     * RSAKey.parseCDS(key) will return the described RSAKey object.
     * <p>
     * A valid CDS can be created by calling the RSAKey.toString() method.
     *
     * @exception InvalidCDSException if the CDS is malformed.
     *
     * @see org.logi.crypto.Crypto#fromString(String)
     */
    public static RSAKey parseCDS(String key) throws InvalidCDSException{
        RSAKey ret=null;
        try {
            StreamTokenizer st=new StreamTokenizer(new StringReader(key));
            st.ordinaryChars('0','9');
            st.wordChars('0','9');
            
            if(st.nextToken()!=StreamTokenizer.TT_WORD)
                throw new InvalidCDSException("Hexadecimal string expected as first argument to RSAKey()");
            BigInteger r = new BigInteger(st.sval,16);
            if(st.nextToken()!=',')
                throw new InvalidCDSException(", expected after "+r.toString(16));
            
            if(st.nextToken()!=StreamTokenizer.TT_WORD)
                throw new InvalidCDSException("Hexadecimal string expected as second argument to RSAKey()");
            BigInteger n = new BigInteger(st.sval,16);
            if(st.nextToken()!=',')
                throw new InvalidCDSException(", expected after "+n.toString(16));
            
            if(st.nextToken()!=StreamTokenizer.TT_WORD)
                throw new InvalidCDSException("modulus factor, \"pub\" or \"pri\" expected as third argument to RSAKey()");
            if(st.sval.equals("pri"))
                // private key
                ret=new RSAKey(r,n,true);
            else if(st.sval.equals("pub"))
                // public key
                ret=new RSAKey(r,n,false);
            else {
                // we have a modulus factor
                try{
                    BigInteger p = new BigInteger(st.sval,16);
                    ret=new RSAKeyChin(r,n,p,true);
                } catch (Exception e) {
                    throw new InvalidCDSException(e.getMessage());
                }
            }

            String last = st.sval;
            if(st.nextToken()!=StreamTokenizer.TT_EOF){
                System.out.println(st.ttype);
                throw new InvalidCDSException("no more parameters expected in RSAKey after "+last);
            }
        } catch (IOException e){
            // StringReader doesn't really throw exceptions.
        }
        return ret;
    }

    /** Returns the largest prime <code>p &lt;= start</code> */
    public static BigInteger findPrime(BigInteger start){
	BigInteger p = start;
	if(!start.testBit(0))
	    p = p.subtract(ONE);
	while(!p.isProbablePrime(primeCertainty))
	    p = p.subtract(TWO);
	return p;
    }

    // The below re-implementation of createKeys takes more than twice
    // the time of the old implementation. This might change depending
    // on the speed-difference between JIT-compiled java code and
    // native code and the speed of the random number generator.
    // 
    // My testing was done on a non-JIT linux system with a
    // /dev/urandom device which would be the most favourable to the
    // original implementation. A good JIT and a slow PRNG would
    // favour the re-implementation.
   
    /**
     * Create a pair of public/private keys. The key modulo will be
     * <code>bitLength</code> or <code>bitLength-1</code> bits.
     *
    public static KeyPair createKeys(int bitLength){
        if (bitLength<256)
            bitLength=256;
        
	BigInteger p=findPrime(new BigInteger(bitLength/2, random));
	BigInteger q=findPrime(new BigInteger(bitLength/2, random));
	BigInteger m=p.subtract(ONE).multiply(q.subtract(ONE));
	BigInteger s=R.modInverse(m);
	BigInteger n=p.multiply(q);

        Key pub=new RSAKey (R,n,false);
        Key pri=null;
        try {
            pri=new RSAKeyChin(s,n,p, true);
        } catch (KeyException e){
            // Won't happen unless there is a bug in the above, but just in case...
            e.printStackTrace();
            pri=new RSAKey(s,n,true);
        }
        return new KeyPair(pub,pri);
    }*/
    
    /**
     * Create a pair of public/private keys. The key modulo will be
     * <code>bitLength</code> or <code>bitLength-1</code> bits.
     */
    public static KeyPair createKeys(int bitLength){
        if (bitLength<256)
            bitLength=256;
        
        BigInteger p=null;
        BigInteger q=null;
        BigInteger s=null;
        BigInteger n=null;
        while(n==null) {
            try{
                p=new BigInteger(bitLength/2, primeCertainty, random);
                q=new BigInteger(bitLength/2, primeCertainty, random);
                BigInteger m=p.subtract(ONE).multiply(q.subtract(ONE));
                s=R.modInverse(m);
                n=p.multiply(q);
            } catch (ArithmeticException e) {
                // Key generation failed... just try again.
                n=null;
            }
        }
        
        Key pub=new RSAKey    (R,n,false);
        Key pri=null;
        try {
            pri=new RSAKeyChin(s,n,p, true);
        } catch (KeyException e){
            // Won't happen unless there is a bug in the above, but just in case...
            e.printStackTrace();
            pri=new RSAKey(s,n,true);
        }
        return new KeyPair(pub,pri);
    }
    
    /**
     * Create a pair of public/private keys from a username/password
     * pair.  The public exponent will be 65536 and the exponent will
     * have <code>bitLength</code> or <code>bitLength-1</code> bits.
     *
     * <p> The keys are created by hashing the password, appending
     * with <code>0</code>'s until it is <code>bitLength</code> bits
     * long and searching for a prime <code>p</code>by counting down
     * from there.  Another prime <code>q</code> is found in the same
     * way, but the username is prepended to the password before
     * hashing. Key-generation proceeds as normally from there.
     *
     * <p>The hashFunction parameters directs which hash function to use.
     * It must be the name of a supported hash function, such as MD5 or
     * SHA1.
     *
     * <p> The <code>username</code> does not need to be secret and
     * can in fact be a fixed string. It plays a similar role as SALT
     * in unix password systems in protecting against dictionary
     * attacks.
   
     * @exception InvalidCDSException if the specified hash function is not
     * available. */
    public static KeyPair createKeys(String username, String password, String hashFunction, int bitLength) throws InvalidCDSException {
        if (bitLength<256)
            bitLength=256;

	BigInteger p,q;

        byte[] b = Fingerprint.create(password, hashFunction).getBytes();
        p = new BigInteger(1,b);
        p = p.shiftLeft(bitLength/2-p.bitLength());
        p=findPrime(p);

        b = Fingerprint.create(username+":"+password, hashFunction).getBytes();
        q = new BigInteger(1,b);
        q = q.shiftLeft(bitLength/2-q.bitLength());
        q=findPrime(q);

        BigInteger m=p.subtract(ONE).multiply(q.subtract(ONE));
        BigInteger s=R.modInverse(m);
        BigInteger n=p.multiply(q);

        Key pub=new RSAKey (R,n,false);
        Key pri=null;
        try {
            pri=new RSAKeyChin(s,n,p, true);
        } catch (KeyException e){
            // Won't happen unless there is a bug in the above, but just in case...
            e.printStackTrace();
            pri=new RSAKey(s,n,true);
        }
        return new KeyPair(pub,pri);
    }
    
    /**
     * Create a KeyPair object holding objects for the public RSA key
     * <code>(r,n)</code> and the private RSA key (s,n).
     *
     * @exception KeyException if (r,n) and (s,n) does not describe a valid
     * pair of RSA keys.
     */
    public static KeyPair createKeys(BigInteger r, BigInteger s, BigInteger n) throws KeyException {
        Key pub = new RSAKey(r,n, false);
        Key pri = new RSAKey(s,n, true);
        //try{
            return new KeyPair(pub,pri);
        //} catch (Exception e) {
        //    throw new KeyException("The (r,s,n) triplet does not specify a matching pair of RSA keys.");
        //}
    }
    
    /** Return the size of the key modulo in bits. */
    public int getSize(){
        return n.bitLength();
    }
    
    /** The name of the algorithm is "RSA". */
    public String getAlgorithm(){
        return ("RSA");
    }

    /** Return the RSA exponent. */
    public BigInteger getExponent(){
	return r;
    }
    
    /** Return the RSA modulus. */
    public BigInteger getModulus(){
	return n;
    }
    
    /**
     * Calculate the fingerprint for this key or the other in the
     * pair.
     *
     * @see org.logi.crypto.K#getFingerprint
     * @see org.logi.crypto.K#matchFingerprint
     */
    protected Fingerprint calcFingerprint(boolean other, String algorithm) throws InvalidCDSException {
        // The key-pair is uniquely defined by n, since it factors uniquely
        // into p and q which are used to calculate both exponents.
        HashState fs=HashState.create(algorithm);
        fs.update(n.toByteArray());
        if(other==pri)
            fs.update("pub");
        else
            fs.update("pri");
        return fs.calculate();
    }
    
    /** Return true iff this is a private key. */
    public boolean isPrivate(){
        return pri;
    }
    
    /**
     * Return a CDS for this key.
     *
     * @see org.logi.crypto.Crypto#fromString
     */
    public String toString(){
        return "RSAKey("+r.toString(16)+','+n.toString(16)+','+(pri?"pri":"pub")+")";
    }
    
    /** Return true iff the two keys are equivalent. */
    public boolean equals(Object o){
        if (o==null)
            return false;
        if((o instanceof RSAKey) || (o instanceof RSAKeyChin)){
            RSAKey rsa = (RSAKey)o;
            return (r.equals(rsa.r) &&
                    n.equals(rsa.n) &&
                    pri==rsa.pri);
        } else
            return false;
    }
    
    /**
     * Check if a key mathces this. This is true if this and key are a matched
     * pair of public/private keys. */
    public final boolean matches(Key key){
        if (key.getClass() != this.getClass())
            return false;
        RSAKey k=(RSAKey)key;
        if (!n.equals(k.n))
            return false;
        return true;
    }
    
    ///////////////////////////////////////////////////////////////////////
    // CIPHER CODE
    
    /**
     * Returns the size of the blocks that can be encrypted in one call
     * to encrypt(). For RSA keys this depends on the size of the key.
     */
    public int plainBlockSize(){
        return (n.bitLength()-1)/8;
    }
    
    /**
     * Returns the size of the blocks that can be decrypted in one call
     * to decrypt(). For RSA keys this depends on the size of the key.
     */
    public int cipherBlockSize(){
        return plainBlockSize()+1;
    }
    
    /**
     * Encrypt one block of data. The plaintext is taken from
     * <code>source</code> starting at offset <code>i</code> and
     * ciphertext is written to <code>dest</code>, starting at
     * offset <code>j</code>.
     * <p>
     * The amount of data read and written will match the values returned
     * by <code>plainBlockSize()</code> and <code>cipherBlockSize()</code>.
     */
    public void encrypt(byte[] source, int i, byte[] dest, int j){
        int plainSize = plainBlockSize();
        byte[] plain = new byte[plainSize];
        System.arraycopy(source,i, plain,0, plainSize);
        BigInteger P = new BigInteger(1,plain);
        BigInteger C = P.modPow(r,n);
        byte[] cipher = C.toByteArray();
        if(cipher.length >= plainSize+1)
            // The output is a full cipher block.
            System.arraycopy(cipher,cipher.length-(plainSize+1), dest, j, plainSize+1);
        else{
            // The output is a bit on the short side
            System.arraycopy(cipher,0, dest, j+(plainSize+1)-cipher.length, cipher.length);
            for (int k=plainSize-cipher.length; k>=0; k--)
                dest[j+k]=0;
        }
    }
    
    /**
     * Decrypt one block of data. The ciphertext is taken from
     * <code>source</code> starting at offset <code>i</code> and
     * plaintext is written to <code>dest</code>, starting at
     * offset <code>j</code>.
     * <p>
     * The amount of data read and written will match the values returned
     * by <code>cipherBlockSize()</code> and <code>plainBlockSize()</code>.
     */
    public void decrypt(byte[] source, int i, byte[] dest, int j){
        int plainSize=plainBlockSize();
        
        byte[] cipher = new byte[plainSize+1];
        
        System.arraycopy(source,i, cipher,0, plainSize+1);
        BigInteger C=new BigInteger(1,cipher);
        BigInteger P=C.modPow(r,n);
        byte[]plain = P.toByteArray();
        if(plain.length >= plainSize)
            // The output is a full plain block
            System.arraycopy(plain,plain.length-plainSize, dest, j, plainSize);
        else {
            // The output is a bit on the short side
            System.arraycopy(plain,0, dest,j+plainSize-plain.length, plain.length);
            for (int k=plainSize-plain.length-1; k>=0; k--)
                dest[j+k]=0;
        }
    }
    
    ///////////////////////////////////////////////////////////////////////
    // SIGNATURE CODE
    
    /**
     * Returns the maximum size in bytes of the fingerprint
     * that can be signed. */
    public int signBlockSize(){
        return plainBlockSize();
    }
    
    /**
     * Returns the length of the signature in bytes. */
    public int signatureSize(){
        return cipherBlockSize();
    }
    
    /**
     * Create a signature for a Fingerprint fith a private key.
     *
     * @exception KeyException if the key modulus is shorter than the signature.
     * @exception KeyException if this is not a private key
     */
    public Signature sign(Fingerprint fp) throws KeyException {
        if(!pri)
            throw new KeyException("Signatures can only be generated with private RSA keys.");
        
        byte[] buf=fp.getBytes();
        byte[] bigBuf=new byte[plainBlockSize()];
        byte[] cipher=new byte[cipherBlockSize()];
        if(bigBuf.length<buf.length)
            throw new KeyException("This key is to short to sign this hash.");
        System.arraycopy(buf,0, bigBuf,bigBuf.length-buf.length, buf.length);
        
        // Pad with random bytes
        int i=bigBuf.length-buf.length-1;
        int n=i%8;
        i=(i/8)*8;
        writeBytes(random.nextLong(), bigBuf, i, n);
        for(i=i-8; i>=0; i-=8)
            writeBytes(random.nextLong(), bigBuf, i, 8);
        
        // Encrypt
        encrypt(bigBuf,0, cipher,0);
        return new Signature(cipher, fp.getName(), matchFingerprint());
    }
    
    /**
     * Verify a Signature on a Fingerprint with a public key.
     * <p>
     * The method returns true iff <code>s</code> is a signature for
     * <code>fp</code> created with the mathcin private key.
     *
     * @exception KeyException if this is not a public key
     */
    public boolean verify(Signature s, Fingerprint fp) throws KeyException{
        if(pri)
            throw new KeyException("Signatures can only be verified with public RSA keys.");
        
        byte[] buf=s.getBytes();
        byte[] bigBuf=new byte[cipherBlockSize()];
        byte[] plain=new byte[plainBlockSize()];
        
        // Decrypt
        System.arraycopy(buf,0, bigBuf,bigBuf.length-buf.length, buf.length);
        decrypt(bigBuf,0,plain,0);
        
        // Check for equality (of the appropriate sub-string)
        byte[] fpb = fp.getBytes();
        return equalSub(plain,plain.length-fpb.length, fpb,0, fpb.length);
    }
    
}
