//
// rmd128.cxx
//
// This algorithm is due to H. Dobbertin, A. Bosselaers, and Bart Preneel,
// and is defined in _RIPE-MD160:_A_Strengthened_Version_of_RIPEMD_
// available at ftp://ftp.esat.kuleuven.ac.be/pub/COSIC/bosselae/ripemd/.
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#include <string.h>
#include "rmd128.hpp"
#include "chmisc.hpp"
#include "clink.h"

const u32 RIPEMD128::H0=0x67452301;
const u32 RIPEMD128::H1=0xefcdab89;
const u32 RIPEMD128::H2=0x98badcfe;
const u32 RIPEMD128::H3=0x10325476;

RIPEMD128::RIPEMD128() : MD4ish(128)
{
  H=new u32[4];

  H[0]=H0;
  H[1]=H1;
  H[2]=H2;
  H[3]=H3;
}
 
RIPEMD128::~RIPEMD128()
{
  delete[] H;
}

void RIPEMD128::ProcessBlock(const u32* block)
{
  RIPEMD128Transform(H,block);
}

void RIPEMD128::Compress(const u32* iv, const u32* block, u32* result)
{
  memcpy(result,iv,16);
  RIPEMD128Transform(result,block);
}

void RIPEMD128::Compress(const void* iv, const void* block, void* result)
{
  u32 IV[4];
  u32 Block[16];
  u32 Res[4];

  memcpy(IV,iv,16);
  memcpy(Block,block,64);

  CHMisc::MemSwap(IV,4);

  Compress(IV,Block,Res);
  memcpy(result,Res,16);
}

void RIPEMD128::Reset()
{
  MD4ish::Reset();

  H[0]=H0;
  H[1]=H1;
  H[2]=H2;
  H[3]=H3;
}
