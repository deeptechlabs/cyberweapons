These tests will only work on a Pentium. I am not sure what will 
happen on other processors. (Maybe they will blow up! :) )
Take your chances, but I am not legally liable. :)

Note that the test is looped over three times for the following reasons:
  1) we want to ensure all instruciton and data are in the cache
     so the first test is no good,
  2) the branch at the end of the for loop will be mispredicted the 
     first time so the second test is no good, and
  3) everything should be cached and the instruction fetch valid 
     on the third iteration, so it should be accurate.

Leonard
