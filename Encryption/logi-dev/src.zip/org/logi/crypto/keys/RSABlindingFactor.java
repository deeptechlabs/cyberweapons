// Copyright (C) 2000 Logi Ragnarsson

package org.logi.crypto.keys;
import org.logi.crypto.*;
import org.logi.crypto.sign.*;

import java.math.BigInteger;

/**
 * Instances of this class hold a blinding factor for use with a particular
 * key-pair. Only use eachblinding factor once!
 
 * @version 1.1.0
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class RSABlindingFactor extends BlindingFactor {

   protected BigInteger factor;

   public RSABlindingFactor(BigInteger factor){
      this.factor=factor;
   }
   
   public BigInteger getFactor(){
      return factor;
   }

   /**
    * Used by Crypto.fromString when parsing a CDS.<p>
    * 
    * A valid CDS can be created by calling the toString() method.
    * 
    * @exception InvalidCDSException if the CDS is malformed.
    * @see org.logi.crypto.Crypto#fromString(String)
    */
   public static RSABlindingFactor parseCDS(String[] param) throws InvalidCDSException{
      if(param.length!=1)
	throw new InvalidCDSException("invalid number of parameters in the CDS RSABlindingFactor(factor)");
	 return new RSABlindingFactor(new BigInteger(param[0],16));
   }
   
   public String toString(){
      return "RSABlindingFactor("+factor.toString(16)+")";
   }

   
}
