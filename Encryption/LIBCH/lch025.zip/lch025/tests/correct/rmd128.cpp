//
// rmd128.cxx
// 
// Test data taken from _RIPEMD-160:_A_Strengthened_Version_of_RIPEMD_
// by Dobbertin, Bossalaers, and Preneel.
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.
 
#include <iostream.h>
#include <iomanip.h>
#include <string.h>
#include <chnhash/rmd128.hpp>

#define BYTES_IN_HASH 16 

int Test0()
{
  const char* t="";
  const u8 exp[BYTES_IN_HASH]={ 0xcd, 0xf2, 0x62, 0x13, 0xa1, 0x50, 0xdc, 0x3e, 0xcb, 0x61, 0x0f, 0x18, 0xf6, 0xb3, 0x8b, 0x46 };
  u8 res[BYTES_IN_HASH];

  RIPEMD128 hashor;

  cout <<"Hashing ->"<<t<<"<-"<<endl;
  hashor.ProcessFinalBlock(t,strlen(t));
  hashor.ChainVariables(res);

  cout <<"res=     0x";
  for (int i=0; i<BYTES_IN_HASH; i++)
    cout <<hex<<setw(2)<<setfill('0')<<int(res[i]);
  cout <<endl;

  if ( memcmp(exp,res,BYTES_IN_HASH) )
    {
      cout <<"*****Failed!*****"<<endl;
      return -1;
    }

 cout <<"*****Passed!*****"<<endl;
 return 0;
}

int Test1()
{
  const char* t="a";
  const u8 exp[BYTES_IN_HASH]={ 0x86, 0xbe, 0x7a, 0xfa, 0x33, 0x9d, 0x0f, 0xc7, 0xcf, 0xc7, 0x85, 0xe7, 0x2f, 0x57, 0x8d, 0x33 };
  u8 res[BYTES_IN_HASH];

  RIPEMD128 hashor;

  cout <<"Hashing ->"<<t<<"<-"<<endl;
  hashor.ProcessFinalBlock(t,strlen(t));
  hashor.ChainVariables(res);

  cout <<"res=     0x";
  for (int i=0; i<BYTES_IN_HASH; i++)
    cout <<hex<<setw(2)<<setfill('0')<<int(res[i]);
  cout <<endl;
  if ( memcmp(exp,res,BYTES_IN_HASH) )
    {
      cout <<"*****Failed!*****"<<endl;
      return -1;
    }

 cout <<"*****Passed!*****"<<endl;
 return 0;
}

int Test2()
{
  const char* t="abc";
  const u8 exp[BYTES_IN_HASH]={ 0xc1, 0x4a, 0x12, 0x19, 0x9c, 0x66, 0xe4, 0xba, 0x84, 0x63, 0x6b, 0x0f, 0x69, 0x14, 0x4c, 0x77 };
  u8 res[BYTES_IN_HASH];

  RIPEMD128 hashor;

  cout <<"Hashing ->"<<t<<"<-"<<endl;
  hashor.ProcessFinalBlock(t,strlen(t));
  hashor.ChainVariables(res);

  cout <<"res=     0x";
  for (int i=0; i<BYTES_IN_HASH; i++)
    cout <<hex<<setw(2)<<setfill('0')<<int(res[i]);
  cout <<endl;

  if ( memcmp(exp,res,BYTES_IN_HASH) )
    {
      cout <<"*****Failed!*****"<<endl;
      return -1;
    }

 cout <<"*****Passed!*****"<<endl;
 return 0;
}

int Test3()
{
  const char* t="message digest";
  const u8 exp[BYTES_IN_HASH]={ 0x9e, 0x32, 0x7b, 0x3d, 0x6e, 0x52, 0x30, 0x62, 0xaf, 0xc1, 0x13, 0x2d, 0x7d, 0xf9, 0xd1, 0xb8 };
  u8 res[BYTES_IN_HASH];

  RIPEMD128 hashor;

  cout <<"Hashing ->"<<t<<"<-"<<endl;
  hashor.ProcessFinalBlock(t,strlen(t));
  hashor.ChainVariables(res);

  cout <<"res=     0x";
  for (int i=0; i<BYTES_IN_HASH; i++)
    cout <<hex<<setw(2)<<setfill('0')<<int(res[i]);
  cout <<endl;

  if ( memcmp(exp,res,BYTES_IN_HASH) )
    {
      cout <<"*****Failed!*****"<<endl;
      return -1;
    }

 cout <<"*****Passed!*****"<<endl;
 return 0;
}

int Test4()
{
  const char* t="abcdefghijklmnopqrstuvwxyz";
  const u8 exp[BYTES_IN_HASH]={ 0xfd, 0x2a, 0xa6, 0x07, 0xf7, 0x1d, 0xc8, 0xf5, 0x10, 0x71, 0x49, 0x22, 0xb3, 0x71, 0x83, 0x4e };
  u8 res[BYTES_IN_HASH];

  RIPEMD128 hashor;

  cout <<"Hashing ->"<<t<<"<-"<<endl;
  hashor.ProcessFinalBlock(t,strlen(t));
  hashor.ChainVariables(res);

  cout <<"res=     0x";
  for (int i=0; i<BYTES_IN_HASH; i++)
    cout <<hex<<setw(2)<<setfill('0')<<int(res[i]);
  cout <<endl;

  if ( memcmp(exp,res,BYTES_IN_HASH) )
    {
      cout <<"*****Failed!*****"<<endl;
      return -1;
    }

 cout <<"*****Passed!*****"<<endl;
 return 0;
}

int Test5()
{
  const char* t="abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq";
  const u8 exp[BYTES_IN_HASH]={ 0xa1, 0xaa, 0x06, 0x89, 0xd0, 0xfa, 0xfa, 0x2d, 0xdc, 0x22, 0xe8, 0x8b, 0x49, 0x13, 0x3a, 0x06 };
  u8 res[BYTES_IN_HASH];

  RIPEMD128 hashor;

  cout <<"Hashing ->"<<t<<"<-"<<endl;
  hashor.ProcessFinalBlock(t,strlen(t));
  hashor.ChainVariables(res);

  cout <<"res=     0x";
  for (int i=0; i<BYTES_IN_HASH; i++)
    cout <<hex<<setw(2)<<setfill('0')<<int(res[i]);
  cout <<endl;

  if ( memcmp(exp,res,BYTES_IN_HASH) )
    {
      cout <<"*****Failed!*****"<<endl;
      return -1;
    }

 cout <<"*****Passed!*****"<<endl;
 return 0;
}

int Test6()
{
  const char* t="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  const u8 exp[BYTES_IN_HASH]={ 0xd1, 0xe9, 0x59, 0xeb, 0x17, 0x9c, 0x91, 0x1f, 0xae, 0xa4, 0x62, 0x4c, 0x60, 0xc5, 0xc7, 0x02 };
  u8 res[BYTES_IN_HASH];

  RIPEMD128 hashor;

  cout <<"Hashing ->"<<t<<"<-"<<endl;
  hashor.ProcessFinalBlock(t,strlen(t));
  hashor.ChainVariables(res);

  cout <<"res=     0x";
  for (int i=0; i<BYTES_IN_HASH; i++)
    cout <<hex<<setw(2)<<setfill('0')<<int(res[i]);
  cout <<endl;

  if ( memcmp(exp,res,BYTES_IN_HASH) )
    {
      cout <<"*****Failed!*****"<<endl;
      return -1;
    }

 cout <<"*****Passed!*****"<<endl;
 return 0;
}

int Test7()
{
  const char* t="12345678901234567890123456789012345678901234567890123456789012345678901234567890";
  const u8 exp[BYTES_IN_HASH]={ 0x3f, 0x45, 0xef, 0x19, 0x47, 0x32, 0xc2, 0xdb, 0xb2, 0xc4, 0xa2, 0xc7, 0x69, 0x79, 0x5f, 0xa3 };
  u8 res[BYTES_IN_HASH];

  RIPEMD128 hashor;

  cout <<"Hashing ->"<<t<<"<-"<<endl;
  hashor.ProcessMiddleBlock(t);
  hashor.ProcessFinalBlock(t+64,16);
  hashor.ChainVariables(res);

  cout <<"res=     0x";
  for (int i=0; i<BYTES_IN_HASH; i++)
    cout <<hex<<setw(2)<<setfill('0')<<int(res[i]);
  cout <<endl;

  if ( memcmp(exp,res,BYTES_IN_HASH) )
    {
      cout <<"*****Failed!*****"<<endl;
      return -1;
    }

 cout <<"*****Passed!*****"<<endl;
 return 0;
}

int Test8()
{
  u8 t[64];
  const u8 exp[BYTES_IN_HASH]={ 0x4a, 0x7f, 0x57, 0x23, 0xf9, 0x54, 0xeb, 0xa1, 0x21, 0x6c, 0x9d, 0x8f, 0x63, 0x20, 0x43, 0x1f };
  u8 res[BYTES_IN_HASH];
  int i;

  RIPEMD128 hashor;
  
  for (i=0; i<64; i++)
    t[i]='a';

  cout <<"Hashing ->one million 'a' 's<-"<<endl;
  for (i=0; i<15625; i++)
    hashor.ProcessMiddleBlock(t);
  hashor.ProcessFinalBlock(NULL,0);
  hashor.ChainVariables(res);

  cout <<"res=     0x";
  for (i=0; i<BYTES_IN_HASH; i++)
    cout <<hex<<setw(2)<<setfill('0')<<int(res[i]);
  cout <<endl;

  if ( memcmp(exp,res,BYTES_IN_HASH) )
    {
      cout <<"*****Failed!*****"<<endl;
      return -1;
    }

 cout <<"*****Passed!*****"<<endl;
 return 0;
}


int main(int, char**)
{
  int failedATest=0;

  cout <<"Testing the RIPEMD128 hash function..."<<endl;
  cout <<endl;
  failedATest|=Test0(); cout <<endl;
  failedATest|=Test1(); cout <<endl;
  failedATest|=Test2(); cout <<endl;
  failedATest|=Test3(); cout <<endl;
  failedATest|=Test4(); cout <<endl;
  failedATest|=Test5(); cout <<endl;
  failedATest|=Test6(); cout <<endl;
  failedATest|=Test7(); cout <<endl;
  failedATest|=Test8(); cout <<endl;

  if ( failedATest )
    {
      cout <<"Oh, oh! Failed a test!"<<endl;
      return(-1);
    }

  cout <<"Passed all tests!"<<endl;
  return(0);
}
