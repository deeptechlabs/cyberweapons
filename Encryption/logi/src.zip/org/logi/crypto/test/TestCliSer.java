// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.test;
import org.logi.crypto.*;
import org.logi.crypto.keys.*;
import org.logi.crypto.modes.*;
import org.logi.crypto.protocols.*;
import org.logi.crypto.io.*;

import java.util.Random;
import java.io.*;
import java.net.*;
import java.util.*;

/**
 * This application tests multiple client threads connecting to a server
 * thread, using key-exchange and encryption in OFB mode.
 * <p>
 * This makes use of the EncryptStream DecryptStream, EncryptOFB, DecryptOFB,
 * TriDES, DHKeyExClient and DHKeyExServer classes.
 * <p>
 * 10 client threads are created which each repeatedly connects to the
 * main server thread. The main server thread spawns a sub-thread for
 * each connection. Each client thread negotiates a TriDES session key
 * with its corresponding server thread using the Diffie-Hellman protocol
 * and uses this key in OFB mode to send a number to the server thread and
 * receive the number squared. The result is then printed to the screen.
 * <p>
 * Since each EncryptOFB and DecryptOFB object launches a thread to
 * pre-calculate an xor-stream, more than 60 threads are created to perform
 * the calculations.
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 *
 * @see org.logi.crypto.modes.EncryptMode
 */
public class TestCliSer extends Crypto{
    
    private TestCliSer(){}
    
    static int serverPort;
    static Random rand = new Random();
    
    // Used for DH-EKE, SendHash and QRAuth protocols
    static CipherKey secret;

    // Used for EncryptedKeyExchange protocol
    static KeyPair serverKeys;
    static KeyPair clientKeys;
   
    // Should we perform separate authentication?
    static boolean auth;
    
    // The key-exchange protocol to use. Is one of DH, EncryptedKey, SendHash
    static String keyEx; 
    
    static class ClientThread extends Thread{
        int id;
        
        public ClientThread(int id){
            this.id = id;
        }
        
        public CipherStreamClient makeCS(Socket s) throws Exception{
            if(keyEx.equals("DH"))
                return new CipherStreamClient(s.getInputStream(),
                                              s.getOutputStream(),
                                              new DHKeyExClient(512,"TriDESKey"),
                                              new EncryptOFB(64),
                                              new DecryptOFB(64)
                                             );
            if(keyEx.equals("EncryptedKey"))
                return new CipherStreamClient(s.getInputStream(),
                                              s.getOutputStream(),
                                              new EncryptedKeyExClient((CipherKey)serverKeys.getPublic(),
								       (SignatureKey)clientKeys.getPrivate(),
								       new TriDESKey()),
                                              new EncryptOFB(64),
                                              new DecryptOFB(64)
                                             );
            if(keyEx.equals("SendHash")){
                return new CipherStreamClient(s.getInputStream(),
                                              s.getOutputStream(),
                                              new SendHashKeyExClient(secret),
                                              new EncryptOFB(64),
                                              new DecryptOFB(64)
                                             );
            }
            if(keyEx.equals("DHEKE")){
                return new CipherStreamClient(s.getInputStream(),
                                              s.getOutputStream(),
                                              new DHEKEKeyExClient(512,"TriDESKey",secret),
                                              new EncryptOFB(64),
                                              new DecryptOFB(64)
                                             );
            }
            return null;
        }
        
        public void run() {
            while(true){
                Socket s=null;
                try {
                    System.err.println("C("+id+")\tCreating CipherStreamClient");
                    s = new Socket("127.0.0.1",serverPort);
                    CipherStreamClient csc = makeCS(s);
                    if(auth){
                        System.err.println("S\tAuthenticating");
                        csc.execute(new QRAuthClient(secret));
                    }
                    DataInputStream  in  = new DataInputStream (csc.getInputStream() );
                    DataOutputStream out = new DataOutputStream(csc.getOutputStream());
                    do {
                        int n = rand.nextInt() % 50 + 50;
                        out.writeInt(n);
                        int n2=in.readInt();
                        System.err.println("C("+id+")\t"+n+"^2="+n2);
                    } while (rand.nextInt() % 50 != 0);
                    s.close();
                } catch (Exception e) {
                    System.err.println("C("+id+")\tDied with an exception");
                    e.printStackTrace(System.err);
                    try {
                        s.close(); 
                    } catch (Exception e2) {};
                }
            }
        }
        
    }
    
    static class ServerThread extends Thread{
        Socket s;
        
        public ServerThread(Socket s){
            this.s = s;
        }
        
        public CipherStreamServer makeCS(Socket s) throws Exception{
            if(keyEx.equals("DH"))
                return new CipherStreamServer(s.getInputStream(),
                                              s.getOutputStream(),
                                              new DHKeyExServer(512,"TriDESKey"),
                                              new EncryptOFB(64),
                                              new DecryptOFB(64)
                                             );
            if(keyEx.equals("EncryptedKey"))
                return new CipherStreamServer(s.getInputStream(),
                                              s.getOutputStream(),
                                              new EncryptedKeyExServer((CipherKey)serverKeys.getPrivate(),
								       (SignatureKey)clientKeys.getPublic()),
                                              new EncryptOFB(64),
                                              new DecryptOFB(64)
                                             );
            if(keyEx.equals("SendHash")){
                return new CipherStreamServer(s.getInputStream(),
                                              s.getOutputStream(),
                                              new SendHashKeyExServer(),
                                              new EncryptOFB(64),
                                              new DecryptOFB(64)
                                             );
            }
            if(keyEx.equals("DHEKE")){
                return new CipherStreamServer(s.getInputStream(),
                                              s.getOutputStream(),
                                              new DHEKEKeyExServer(512,"TriDESKey",secret),
                                              new EncryptOFB(64),
                                              new DecryptOFB(64)
                                             );
            }
            return null;
        }
        
        public void run() {
            try{
                System.err.println("S\tCreating CipherStreamServer");
                CipherStreamServer css = makeCS(s);
                if(auth){
                    System.err.println("S\tAuthenticating");
                    css.execute(new QRAuthServer(secret));
                }
                DataInputStream  in  = new DataInputStream (css.getInputStream() );
                DataOutputStream out = new DataOutputStream(css.getOutputStream());
                while(true){
                    int n = in.readInt();
                    out.writeInt(n*n);
                }
            } catch (Exception e) {
                if(!(e instanceof java.io.EOFException)){
                    System.err.println("S\tDied with an exception");
                    e.printStackTrace();
                }
                try { s.close(); } catch (Exception e2) {};
            }
            System.err.println("S\tclosing connection");
        }
    }
    
    private static void help(){
        System.err.println("Use: java org.logi.crypto.test.TestCliSer <key-ex> [auth]");
        System.err.println("where <key-ex> is one of DH, EncryptedKey or SendHash.");
        System.err.println();
        System.err.println("DH             Diffie-Hellman. Encryption but no authentication.");
        System.err.println("DHEKE          DH-EKE key-exchange and authentication. Encryption and authentication.");
        System.err.println("EncryptedKey   Encrypted key sent. Encryption and implicit authentication.");
        System.err.println("SendHash       Send hash of key to use. Encryption and implicit authentication.");
        System.err.println("");
        System.err.println("auth           Use the query-responce protocol for authentication.");
    }
    
    public static void main(String[] arg){
        Crypto.initRandom();
        
        if(arg.length<1){
            help();
            return;
        }
        keyEx = arg[0];
        if(!keyEx.equals("DH") &&
           !keyEx.equals("DHEKE") &&
           !keyEx.equals("EncryptedKey") &&
           !keyEx.equals("SendHash")) {
            help();
            return;
        }

        if(arg.length>1){
            if(arg[1].equals("auth"))
                auth=true;
            else {
                help();
                return;
            }
        }
        
        // Create secret key and put it in the default key-ring
        secret=new DESKey();
        KeyRing kr  = new KeyRing();
        kr.insert(secret);
        keySource = kr;
        
        // If we are using encrypted key exchange,
        // then we'll need two key-pairs.
        if(keyEx.equals("EncryptedKey")){
	    clientKeys = RSAKey.createKeys(256);	     
	    serverKeys = RSAKey.createKeys(256);
	}
       
        // Create server socket on random port (and save the port number)
        ServerSocket ss;
        Crypto.random = new Random();
        do {
            try{
                serverPort = rand.nextInt() % 32768 + 32768;
                System.out.println("Server on port "+serverPort);
                ss = new ServerSocket(serverPort);
            } catch (Throwable e) {
                System.err.println("Failed to open server port "+serverPort);
                ss = null;
            }
        } while(ss==null);
        
        // Crate 10 client threads
        for (int id=0; id<10; id++)
            new ClientThread(id).start();
        
        // Loop to wait for connections and create a thread for each
        while(true){
            try {
                System.err.println("S\twaiting for connection");
                new ServerThread(ss.accept()).start();
            } catch (IOException e){
                System.err.println("S\tConnection threw an exception");
            }
        }
    }
    
}
