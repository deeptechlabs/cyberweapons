// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.protocols;

/**
 * This exception is thrown if data can't be validated, f.ex in
 * VerifyStream.
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a> (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class ValidationException extends CryptoProtocolException{

    /** Create a new ValidationException with no message. */
    public ValidationException(){
    }

    /** Create a new ValidationException with the message msg. */
    public ValidationException(String msg){
        super(msg);
    }
    
}
