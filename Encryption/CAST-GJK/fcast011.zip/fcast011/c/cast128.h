
/* Implementation of the CAST-128 cipher as described in "Constructing
   Symmetric Ciphers Using the CAST Design Procedure" by Carlisle Adams.
   Nortel, under whose aegis the CAST-128 algorithm was developed, have
   allowed free use of the algorithm for any purpose.  This implementation of
   CAST-128 is copyright 1996 Peter Gutmann, and may be used freely for any
   purpose provided you don't claim you wrote it.

   This code was written for use with cryptlib, my free encryption library
   which provides conventional and public-key encryption, key management, and
   encrypted data management functions.  You can find out more about cryptlib
   from http://www.cs.auckland.ac.nz/~pgut001/cryptlib.html */

/***************************************************************************/

/*  Modifications and additions by Leonard Janke for use with FastCAST. */ 

/***************************************************************************/

#ifndef _CAST_DEFINED
#define _CAST_DEFINED

#define USE_486_ASM_CAST 

#ifdef __cplusplus
extern "C" {
#endif

#ifndef LONGDEFINED
typedef unsigned long LONG;
#define LONGDEFINED
#endif

#ifndef BYTEDEFINED
typedef unsigned char BYTE;
#define BYTEDEFINED
#endif

/* CAST-128 global constants */

#define CAST_BLOCKSIZE			8

/* CAST-128 constants */

#define CAST_KEYSIZE		( 16 + 16 )		/* Masking and rotate subkeys */
#define CAST_KEYSIZE_BYTES	( CAST_KEYSIZE * 4 )
#define CAST_USERKEY_SIZE	16

/* Prototypes for functions in CAST128.C */

#if defined(USE_486_ASM_CAST)
#if defined(__WATCOMC__) && defined(__SW_3S)
#define CAST_CALLCONV __cdecl
#elif defined(_MSC_VER) 
#define CAST_CALLCONV __fastcall
#else
#define CAST_CALLCONV
#endif
#else
#define CAST_CALLCONV
#endif

void CAST_CALLCONV castEncrypt( LONG *key, BYTE *data );
void CAST_CALLCONV castDecrypt( LONG *key, BYTE *data );

/* Make sure noBytes > 0 for CBC functions !!! */
/* iv will be updated by these functions */
void CAST_CALLCONV castEncryptCBC(BYTE *in, BYTE *out, int noBytes, 
                                  LONG *key, BYTE *iv);
void CAST_CALLCONV castDecryptCBC(BYTE *in, BYTE *out, int noBytes, 
                                  LONG *key, BYTE *iv);

void castKeyInit( LONG *key, BYTE *userKey );

extern LONG S1[ 256 ];
extern LONG S2[ 256 ];
extern LONG S3[ 256 ];
extern LONG S4[ 256 ];
extern LONG S5[ 256 ];
extern LONG S6[ 256 ];
extern LONG S7[ 256 ];
extern LONG S8[ 256 ];

#if defined(__WATCOMC__) && defined(__SW_3S)
#pragma aux S1 "_*";
#pragma aux S2 "_*";
#pragma aux S3 "_*";
#pragma aux S4 "_*";
#pragma aux S5 "_*";
#pragma aux S6 "_*";
#pragma aux S7 "_*";
#pragma aux S8 "_*";
#endif

#ifdef __cplusplus
}
#endif

#endif
