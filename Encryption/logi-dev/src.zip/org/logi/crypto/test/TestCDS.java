// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.test;

import org.logi.crypto.*;

import java.io.*;

/**
 * Parse the CDS from the command line and print out the object it
 * represents or an error mesage.
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 *
 * @see org.logi.crypto.modes.EncryptMode
 */
public class TestCDS extends Crypto{

   private TestCDS(){}
   
   /**
    * The CDS on the command-line is parsed into an object and promptly
    * written back to standard output. This is useful for testing CDS's
    * and for generating CDS's with constructs like <code>DES(?)</code>.
    *
    * @exception Throwable Something went wrong
    */
   public static void main(String[] arg) throws Throwable{
      Crypto.initRandom();
      
      if(arg.length==0){
	 System.err.println("use    : TestCDS CDS, CDS, ...");
	 System.err.println("example: TestCDS 'TriDESKey(?)' 'RSAKey(1,1,pri)'");
	 System.err.println("example: TestCDS 'KeyRecord(DESKey(?),\"name\",\"mail\",\"notes\")'");
      } else {
	 PrintWriter w = new PrintWriter(System.out, true);
	 for(int i=0; i<arg.length; i++) {
	    //System.out.println(fromString(arg[i]).toString());
	    ((Crypto)fromString(arg[i])).prettyPrint(w);
	    w.println();
	 }
      }
   }
   
}
