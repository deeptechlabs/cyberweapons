//
// md5.hpp
// This algorithm is due to R. Rivest and is defined in RFC 1321.
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#ifndef _MD5_HPP
#define _MD5_HPP

#include <chnhash/md4ish.hpp>

class MD5 : public MD4ish 
{
 protected:
  void ProcessBlock(const u32* block);
 public:
  MD5();
  ~MD5();

  static void Compress(const u32* iv, const u32* block, u32* result);
  static void Compress(const void* iv, const void* block, void* result);

  void Reset();

  static const u32 H0;
  static const u32 H1;
  static const u32 H2;
  static const u32 H3;
};     

#endif
