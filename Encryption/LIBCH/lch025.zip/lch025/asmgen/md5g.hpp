//
// md5g.hpp
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#ifndef _MD5G_HPP
#define _MD5G_HPP

#include "asmgen.hpp"

class MD5AsmGenerator : public AsmGenerator
{
public:
  static const u32 K[64];
  static const int r[64];
  static const int s[64];

  MD5AsmGenerator(ostream& os);

  void PrintRound1();
  void PrintRound2();
  void PrintRound3();
  void PrintRound4();

  void Startup();
  void Body();
  void Cleanup();
};

#endif
