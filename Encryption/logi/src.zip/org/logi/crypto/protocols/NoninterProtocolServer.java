// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.protocols;

/**
 * This interface is implemented by classes for the server portion of a
 * non-interactive protocol.
 *
 * @see org.logi.crypto.protocols.NoninterProtocolClient
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public interface NoninterProtocolServer extends InterProtocolServer{

}
