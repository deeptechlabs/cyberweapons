//
// rmd160g.cpp
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#include <stdlib.h>
#include <iomanip.h>
#include "a2r160.hpp"
#include "rmd160g.hpp"

RMD160AsmGenerator::RMD160AsmGenerator(ostream& os) : AsmGenerator(os)
{
}

void RMD160AsmGenerator::Startup()
{
  Push(ebp);
  Push(esi);
  Push(edi);
  Push(ebx);
  switch ( callingConvention )
  {
  case WATCOMREGISTER:
    Push(ecx);
    Push(eax);
    break;
  case FASTCALL:
    Push(ecx);
    Mov(eax,ecx);
    break;
  case CDECL:
    Mov(eax,esp,4+16);
    Mov(edx,esp,8+16);
    break;
  default:
    cerr <<"Unrecognized calling convention"<<endl;
    exit(-1);
  }
 
  Sub(esp,64);

  for(int i=0; i<16; i+=2)
  {
     Mov(edi,edx,4*i);
     Mov(ebp,edx,4*(i+1));
     Mov(esp,4*i,edi);
     Mov(esp,4*(i+1),ebp);
  }

  Mov(edi,eax,16);
  Mov(edx,eax,12);
  Mov(ecx,eax,8);
  Mov(ebx,eax,4);
  Mov(eax,eax,0);

  Push(edi);
  Push(edx);
  Push(ecx);
  Push(ebx);
  Push(eax);
}

void RMD160AsmGenerator::PrintSaveLeftResult()
{
  Push(edi);
  Push(edx);
  Push(ecx);
  Push(ebx);
  Push(eax);
}

void RMD160AsmGenerator::PrintReload()
{
  Mov(edi,esp,36);
  Mov(edx,esp,32);
  Mov(ecx,esp,28);
  Mov(ebx,esp,24);
  Mov(eax,esp,20);
}

void RMD160AsmGenerator::PrintCombineHalves()
{
  Push(ecx);

#define EPOS 40
#define DPOS 36
#define CPOS 32 
#define BPOS 28
#define APOS 24
#define ELPOS 20 
#define DLPOS 16
#define CLPOS 12
#define BLPOS 8
#define ALPOS 4
#define CRPOS 0
 
  // T=B+cl+dr;
  // ecx=D+el+ar;
  // eax=T;
  // edx=E+al+br;
  // ebx=C+dl+er;
  // edi=A+bl+cr;

  Mov(esi,esp,CLPOS);   // T=cl
  Mov(ecx,esp,ELPOS);   // ecx=el 
  
  Add(ecx,eax);         // ecx+=ar
  Mov(eax,esi);         // eax=T(=cl) 
  
  Mov(esi,esp,BPOS); 
  Mov(ebp,esp,DPOS); 

  Add(eax,esi);         // eax+=B
  Add(ecx,ebp);         // ecx+=D

  Add(eax,edx);         // eax+=dr
  Mov(ebp,esp,ALPOS);    

  Mov(edx,ebx);         // edx=br
  Mov(esi,esp,DLPOS);

  Mov(ebx,edi);         // ebx=er 
  Add(edx,ebp);         // edx+=al

  Add(ebx,esi);         // ebx+=dl
  Mov(ebp,esp,CPOS);

  Add(ebx,ebp);         // ebx+=C
  Mov(ebp,esp,EPOS);     
  
  Add(edx,ebp);         // edx+=E
  Mov(edi,esp,CRPOS);   // edi=cr

  Add(edi,esp,BLPOS);   // edi+=bl (2 cycles)
  Mov(ebp,esp,APOS);

  Add(edi,ebp);         // edi+=A
  Add(esp,44);

  // T=B+cl+dr;
  // ecx=D+el+ar;
  // eax=T;
  // edx=E+al+br;
  // ebx=C+dl+er;
  // edi=A+bl+cr;
}

void RMD160AsmGenerator::Body()
{
  Comment("left half");
  PrintLeftRound1();
  PrintLeftRound2();
  PrintLeftRound3();
  PrintLeftRound4();
  PrintLeftRound5();

  Comment("save left result");
  PrintSaveLeftResult();
  Comment("reloading chain variables");
  PrintReload();

  Comment("right half");
  PrintRightRound1();
  PrintRightRound2();
  PrintRightRound3();
  PrintRightRound4();
  PrintRightRound5();

  Comment("combine");
  PrintCombineHalves();
}

void RMD160AsmGenerator::Cleanup()
{
  switch ( callingConvention )
  {
  case WATCOMREGISTER: 
  case FASTCALL:
    Mov(esi,esp,0+64);
    Add(esp,4+64);
    break;
  case CDECL:
    Mov(esi,esp,4+16+64);
    Add(esp,64);
    break;
  default:
    cerr <<"Unrecognized calling convention"<<endl;
    break;
  }
  Mov(esi,0,eax);
  Mov(esi,4,ebx);
  Mov(esi,8,ecx);
  Mov(esi,12,edx);
  Mov(esi,16,edi);
  os <<endl;
  if ( callingConvention==WATCOMREGISTER )
    Pop(ecx);
  Pop(ebx);
  Pop(edi);
  Pop(esi);
  Pop(ebp);
  os <<endl;
  Ret();
}

const u32 RMD160AsmGenerator::KL[80]={
  0x00000000, 0x00000000, 0x00000000, 0x00000000,
  0x00000000, 0x00000000, 0x00000000, 0x00000000,
  0x00000000, 0x00000000, 0x00000000, 0x00000000,
  0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x5a827999, 0x5a827999, 0x5a827999, 0x5a827999,
  0x5a827999, 0x5a827999, 0x5a827999, 0x5a827999,
  0x5a827999, 0x5a827999, 0x5a827999, 0x5a827999,
  0x5a827999, 0x5a827999, 0x5a827999, 0x5a827999,
  0x6ed9eba1, 0x6ed9eba1, 0x6ed9eba1, 0x6ed9eba1,
  0x6ed9eba1, 0x6ed9eba1, 0x6ed9eba1, 0x6ed9eba1,
  0x6ed9eba1, 0x6ed9eba1, 0x6ed9eba1, 0x6ed9eba1,
  0x6ed9eba1, 0x6ed9eba1, 0x6ed9eba1, 0x6ed9eba1,
  0x8f1bbcdc, 0x8f1bbcdc, 0x8f1bbcdc, 0x8f1bbcdc,
  0x8f1bbcdc, 0x8f1bbcdc, 0x8f1bbcdc, 0x8f1bbcdc,
  0x8f1bbcdc, 0x8f1bbcdc, 0x8f1bbcdc, 0x8f1bbcdc,
  0x8f1bbcdc, 0x8f1bbcdc, 0x8f1bbcdc, 0x8f1bbcdc,
  0xa953fd4e, 0xa953fd4e, 0xa953fd4e, 0xa953fd4e,
  0xa953fd4e, 0xa953fd4e, 0xa953fd4e, 0xa953fd4e,
  0xa953fd4e, 0xa953fd4e, 0xa953fd4e, 0xa953fd4e,
  0xa953fd4e, 0xa953fd4e, 0xa953fd4e, 0xa953fd4e
};


const int RMD160AsmGenerator::rl[80]={
  0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
  7, 4, 13, 1, 10, 6, 15, 3, 12, 0, 9, 5, 2, 14, 11, 8,
  3, 10, 14, 4, 9, 15, 8, 1, 2, 7, 0, 6, 13, 11, 5, 12,
  1, 9, 11, 10, 0, 8, 12, 4, 13, 3, 7, 15, 14, 5, 6, 2,
  4, 0, 5, 9, 7, 12, 2, 10, 14, 1, 3, 8, 11, 6, 15, 13
};

const int RMD160AsmGenerator::sl[80]={
  11, 14, 15, 12, 5, 8, 7, 9, 11, 13, 14, 15, 6, 7, 9, 8,
  7, 6, 8, 13, 11, 9, 7, 15, 7, 12, 15, 9, 11, 7, 13, 12,
  11, 13, 6, 7, 14, 9, 13, 15, 14, 8, 13, 6, 5, 12, 7, 5,
  11, 12, 14, 15, 14, 15, 9, 8, 9, 14, 5, 6, 8, 6, 5, 12,
  9, 15, 5, 11, 6, 8, 13, 12, 5, 12, 13, 14, 11, 8, 5, 6
};

void RMD160AsmGenerator::PrintLeftRound1()
{
  Mov(ebp,reg[C]);
  Mov(esi,esp,rl[0]*4+20);
  for (int i=0; i<16; i+=2)
    {
      // a=e+(a+(c^d^b)+M)<<<s 
      int subround=i;

      Subround(subround);
      Xor(ebp,reg[D]);
      
      Xor(ebp,reg[B]);
      Add(reg[A],esi);
      
      Rol(reg[C],10);

      Add(reg[A],ebp);
      Mov(ebp,reg[B]);

      Rol(reg[A],sl[subround]);
      
      Mov(esi,esp,rl[subround+1]*4+20);
      Add(reg[A],reg[E]);

      os <<endl;
      reg.Circulate();

      // a=e+(a+(b^c^d)+M)<<<s 
      subround++;

      Subround(subround);
      Xor(ebp,reg[D]);
      Add(reg[A],esi);
      
      Xor(ebp,reg[B]);
      Mov(esi,esp,rl[subround+1]*4+20);
      
      Rol(reg[C],10);

      Add(reg[A],ebp);
      Mov(ebp,reg[B]);

      Rol(reg[A],sl[subround]);
      
      Add(reg[A],reg[E]);

      os <<endl;
      reg.Circulate();
    }
}

void RMD160AsmGenerator::PrintLeftRound2()
{
  for (int i=16; i<32; i++)
    {
      // a=e+(a+(d^(b&(d^c))+M+k)<<<s

      Subround(i);
      Xor(ebp,reg[D]);
      
      And(ebp,reg[B]);
      Mov(esi,esp,rl[i]*4+20);
      
      Xor(ebp,reg[D]);
      Add(reg[A],esi);

      Rol(reg[C],10);

      Lea(reg[A],reg[A],1,ebp,long(KL[i]));
      Mov(ebp,reg[B]);

      Rol(reg[A],sl[i]);
      
      Add(reg[A],reg[E]);
      os <<endl;
      reg.Circulate();
    }
}

void RMD160AsmGenerator::PrintLeftRound3()
{
  for (int i=32; i<48; i++)
    {
      // a=e+(a+(d^(b|~c))+M+k)<<<s

      Subround(i);
      Xor(ebp,-1);
      
      Or(ebp,reg[B]);
      Mov(esi,esp,rl[i]*4+20);
      
      Xor(ebp,reg[D]);
      Add(reg[A],esi);

      Rol(reg[C],10);

      Lea(reg[A],reg[A],1,ebp,long(KL[i]));
      Mov(ebp,reg[B]);

      Rol(reg[A],sl[i]);
      
      Add(reg[A],reg[E]);
      os <<endl;
      reg.Circulate();
    }

}

void RMD160AsmGenerator::PrintLeftRound4()
{
  for (int i=48; i<64; i++)
    {
      // a=e+(a+(c^(d&(b^c)))+M+k)<<<s

      Subround(i);
      Xor(ebp,reg[B]);
      
      And(ebp,reg[D]);
      Mov(esi,esp,rl[i]*4+20);
      
      Xor(ebp,reg[C]);
      Add(reg[A],esi);

      Rol(reg[C],10);

      Lea(reg[A],reg[A],1,ebp,long(KL[i]));
      Mov(ebp,reg[B]);

      Rol(reg[A],sl[i]);
      
      Add(reg[A],reg[E]);
      os <<endl;
      reg.Circulate();
    }
}

void RMD160AsmGenerator::PrintLeftRound5()
{
  Mov(ebp,reg[D]);
  Nop();
  for (int i=64; i<80; i++)
    {
      // a=e+(a+b^(c|~d)+M+k)<<<s

      Subround(i);
      Xor(ebp,-1);

      Or(ebp,reg[C]);
      Mov(esi,esp,rl[i]*4+20);
      
      Xor(ebp,reg[B]);
      Add(reg[A],esi);

      Rol(reg[C],10);

      Lea(reg[A],reg[A],1,ebp,long(KL[i]));
      Mov(ebp,reg[C]);

      Rol(reg[A],sl[i]);
      
      Add(reg[A],reg[E]);
      os <<endl;
      reg.Circulate();
    }
}

const u32 RMD160AsmGenerator::KR[80]={
  0x50a28be6, 0x50a28be6, 0x50a28be6, 0x50a28be6,
  0x50a28be6, 0x50a28be6, 0x50a28be6, 0x50a28be6,
  0x50a28be6, 0x50a28be6, 0x50a28be6, 0x50a28be6,
  0x50a28be6, 0x50a28be6, 0x50a28be6, 0x50a28be6,
  0x5c4dd124, 0x5c4dd124, 0x5c4dd124, 0x5c4dd124,
  0x5c4dd124, 0x5c4dd124, 0x5c4dd124, 0x5c4dd124,
  0x5c4dd124, 0x5c4dd124, 0x5c4dd124, 0x5c4dd124,
  0x5c4dd124, 0x5c4dd124, 0x5c4dd124, 0x5c4dd124,
  0x6d703ef3, 0x6d703ef3, 0x6d703ef3, 0x6d703ef3,
  0x6d703ef3, 0x6d703ef3, 0x6d703ef3, 0x6d703ef3,
  0x6d703ef3, 0x6d703ef3, 0x6d703ef3, 0x6d703ef3,
  0x6d703ef3, 0x6d703ef3, 0x6d703ef3, 0x6d703ef3,
  0x7a6d76e9, 0x7a6d76e9, 0x7a6d76e9, 0x7a6d76e9,
  0x7a6d76e9, 0x7a6d76e9, 0x7a6d76e9, 0x7a6d76e9,
  0x7a6d76e9, 0x7a6d76e9, 0x7a6d76e9, 0x7a6d76e9,
  0x7a6d76e9, 0x7a6d76e9, 0x7a6d76e9, 0x7a6d76e9,
  0x00000000, 0x00000000, 0x00000000, 0x00000000,
  0x00000000, 0x00000000, 0x00000000, 0x00000000,
  0x00000000, 0x00000000, 0x00000000, 0x00000000,
  0x00000000, 0x00000000, 0x00000000, 0x00000000
};

const int RMD160AsmGenerator::rr[80]={
  5, 14, 7, 0, 9, 2, 11, 4, 13, 6, 15, 8, 1, 10, 3, 12,
  6, 11, 3, 7, 0, 13, 5, 10, 14, 15, 8, 12, 4, 9, 1, 2,
  15, 5, 1, 3, 7, 14, 6, 9, 11, 8, 12, 2, 10, 0, 4, 13,
  8, 6, 4, 1, 3, 11, 15, 0, 5, 12, 2, 13, 9, 7, 10, 14,
  12, 15, 10, 4, 1, 5, 8, 7, 6, 2, 13, 14, 0, 3, 9, 11
};

const int RMD160AsmGenerator::sr[80]={
  8, 9, 9, 11, 13, 15, 15, 5, 7, 7, 8, 11, 14, 14, 12, 6,
  9, 13, 15, 7, 12, 8, 9, 11, 7, 7, 12, 7, 6, 15, 13, 11,
  9, 7, 15, 11, 8, 6, 6, 14, 12, 13, 5, 14, 13, 13, 7, 5,
  15, 5, 8, 11, 14, 14, 6, 14, 6, 9, 12, 9, 12, 5, 15, 8,
  8, 5, 12, 9, 12, 5, 14, 6, 8, 13, 6, 5, 15, 13, 11, 11
};

void RMD160AsmGenerator::PrintRightRound1()
{
  Mov(ebp,reg[D]);
  for (int i=0; i<16; i++)
    {
      // a=e+(a+b^(c|~d)+M+k)<<<s

      Subround(i);
      
      Xor(ebp,-1);

      Or(ebp,reg[C]);
      Mov(esi,esp,rr[i]*4+20+20);
      
      Xor(ebp,reg[B]);
      Add(reg[A],esi);

      Rol(reg[C],10);

      Lea(reg[A],reg[A],1,ebp,long(KR[i]));
      Mov(ebp,reg[C]);

      Rol(reg[A],sr[i]);
      
      Add(reg[A],reg[E]);
      os <<endl;
      reg.Circulate();
    }
}

void RMD160AsmGenerator::PrintRightRound2()
{
  Mov(ebp,reg[C]);
  Nop();
  for (int i=16; i<32; i++)
    {
      // a=e+(a+(c^(d&(b^c)))+M+k)<<<s

      Subround(i);
      Xor(ebp,reg[B]);
      
      And(ebp,reg[D]);
      Mov(esi,esp,rr[i]*4+20+20);
      
      Xor(ebp,reg[C]);
      Add(reg[A],esi);

      Rol(reg[C],10);

      Lea(reg[A],reg[A],1,ebp,long(KR[i]));
      Mov(ebp,reg[B]);

      Rol(reg[A],sr[i]);
      
      Add(reg[A],reg[E]);
      os <<endl;
      reg.Circulate();
    }
}

void RMD160AsmGenerator::PrintRightRound3()
{
  for (int i=32; i<48; i++)
    {
      // a=e+(a+(d^(b|~c))+M+k)<<<s

      Subround(i);
      Xor(ebp,-1);
      
      Or(ebp,reg[B]);
      Mov(esi,esp,rr[i]*4+20+20);
      
      Xor(ebp,reg[D]);
      Add(reg[A],esi);

      Rol(reg[C],10);

      Lea(reg[A],reg[A],1,ebp,long(KR[i]));
      Mov(ebp,reg[B]);

      Rol(reg[A],sr[i]);
      
      Add(reg[A],reg[E]);
      os <<endl;
      reg.Circulate();
    }
}
 
void RMD160AsmGenerator::PrintRightRound4()
{
  for (int i=48; i<64; i++)
    {
      // a=e+(a+(d^(b&(d^c))+M+k)<<<s

      Subround(i);
      Xor(ebp,reg[D]);
      
      And(ebp,reg[B]);
      Mov(esi,esp,rr[i]*4+20+20);
      
      Xor(ebp,reg[D]);
      Add(reg[A],esi);

      Rol(reg[C],10);

      Lea(reg[A],reg[A],1,ebp,long(KR[i]));
      Mov(ebp,reg[B]);

      Rol(reg[A],sr[i]);
      
      Add(reg[A],reg[E]);
      os <<endl;
      reg.Circulate();
    }
}

void RMD160AsmGenerator::PrintRightRound5()
{
  Mov(esi,esp,rr[64]*4+20+20);
  for (int i=64; i<80; i+=2)
    {
      // a=e+(a+(c^d^b)+M)<<<s 
      int subround=i;

      Subround(subround);
      Xor(ebp,reg[D]);
      
      Xor(ebp,reg[B]);
      Add(reg[A],esi);
      
      Rol(reg[C],10);

      Add(reg[A],ebp);
      Mov(ebp,reg[B]);

      Rol(reg[A],sr[subround]);
      
      Mov(esi,esp,rr[subround+1]*4+20+20);
      Add(reg[A],reg[E]);

      os <<endl;
      reg.Circulate();

      // a=e+(a+(b^c^d)+M)<<<s 
      subround++;

      Subround(subround);
      Xor(ebp,reg[D]);
      Add(reg[A],esi);
      
      Xor(ebp,reg[B]);
      if ( subround != 79 )
        Mov(esi,esp,rr[subround+1]*4+20+20);
      
      Rol(reg[C],10);

      Add(reg[A],ebp);
      Mov(ebp,reg[B]);

      Rol(reg[A],sr[subround]);
      
      Add(reg[A],reg[E]);

      os <<endl;
      reg.Circulate();
    }
}
