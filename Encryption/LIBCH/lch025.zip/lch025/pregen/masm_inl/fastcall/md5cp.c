#include "clink.h"

void __declspec(naked) __fastcall MD5Transform(u32* H, const u32* X)
{
  __asm{

	push ebp
	push esi
	push edi
	push ebx
	push ecx
	mov edi, ecx
	mov esi, edx

	mov eax, [edi]
	mov ebx, [edi+4]
	mov ecx, [edi+8]
	mov edx, [edi+12]
	mov edi, ecx
	mov ebp, [esi]
/* Subround 0 */
	xor edi, edx
	and edi, ebx
	lea eax, [eax+ebp+-680876936]
	xor edi, edx
	mov ebp, [esi+4]
	add eax, edi
	mov edi, ebx
	rol eax, 7
	add eax, ebx

/* Subround 1 */
	xor edi, ecx
	and edi, eax
	lea edx, [edx+ebp+-389564586]
	xor edi, ecx
	mov ebp, [esi+8]
	add edx, edi
	mov edi, eax
	rol edx, 12
	add edx, eax

/* Subround 2 */
	xor edi, ebx
	and edi, edx
	lea ecx, [ecx+ebp+606105819]
	xor edi, ebx
	mov ebp, [esi+12]
	add ecx, edi
	mov edi, edx
	rol ecx, 17
	add ecx, edx

/* Subround 3 */
	xor edi, eax
	and edi, ecx
	lea ebx, [ebx+ebp+-1044525330]
	xor edi, eax
	mov ebp, [esi+16]
	add ebx, edi
	mov edi, ecx
	rol ebx, 22
	add ebx, ecx

/* Subround 4 */
	xor edi, edx
	and edi, ebx
	lea eax, [eax+ebp+-176418897]
	xor edi, edx
	mov ebp, [esi+20]
	add eax, edi
	mov edi, ebx
	rol eax, 7
	add eax, ebx

/* Subround 5 */
	xor edi, ecx
	and edi, eax
	lea edx, [edx+ebp+1200080426]
	xor edi, ecx
	mov ebp, [esi+24]
	add edx, edi
	mov edi, eax
	rol edx, 12
	add edx, eax

/* Subround 6 */
	xor edi, ebx
	and edi, edx
	lea ecx, [ecx+ebp+-1473231341]
	xor edi, ebx
	mov ebp, [esi+28]
	add ecx, edi
	mov edi, edx
	rol ecx, 17
	add ecx, edx

/* Subround 7 */
	xor edi, eax
	and edi, ecx
	lea ebx, [ebx+ebp+-45705983]
	xor edi, eax
	mov ebp, [esi+32]
	add ebx, edi
	mov edi, ecx
	rol ebx, 22
	add ebx, ecx

/* Subround 8 */
	xor edi, edx
	and edi, ebx
	lea eax, [eax+ebp+1770035416]
	xor edi, edx
	mov ebp, [esi+36]
	add eax, edi
	mov edi, ebx
	rol eax, 7
	add eax, ebx

/* Subround 9 */
	xor edi, ecx
	and edi, eax
	lea edx, [edx+ebp+-1958414417]
	xor edi, ecx
	mov ebp, [esi+40]
	add edx, edi
	mov edi, eax
	rol edx, 12
	add edx, eax

/* Subround 10 */
	xor edi, ebx
	and edi, edx
	lea ecx, [ecx+ebp+-42063]
	xor edi, ebx
	mov ebp, [esi+44]
	add ecx, edi
	mov edi, edx
	rol ecx, 17
	add ecx, edx

/* Subround 11 */
	xor edi, eax
	and edi, ecx
	lea ebx, [ebx+ebp+-1990404162]
	xor edi, eax
	mov ebp, [esi+48]
	add ebx, edi
	mov edi, ecx
	rol ebx, 22
	add ebx, ecx

/* Subround 12 */
	xor edi, edx
	and edi, ebx
	lea eax, [eax+ebp+1804603682]
	xor edi, edx
	mov ebp, [esi+52]
	add eax, edi
	mov edi, ebx
	rol eax, 7
	add eax, ebx

/* Subround 13 */
	xor edi, ecx
	and edi, eax
	lea edx, [edx+ebp+-40341101]
	xor edi, ecx
	mov ebp, [esi+56]
	add edx, edi
	mov edi, eax
	rol edx, 12
	add edx, eax

/* Subround 14 */
	xor edi, ebx
	and edi, edx
	lea ecx, [ecx+ebp+-1502002290]
	xor edi, ebx
	mov ebp, [esi+60]
	add ecx, edi
	mov edi, edx
	rol ecx, 17
	add ecx, edx

/* Subround 15 */
	xor edi, eax
	and edi, ecx
	lea ebx, [ebx+ebp+1236535329]
	xor edi, eax
	mov ebp, [esi+4]
	add ebx, edi
	mov edi, ecx
	rol ebx, 22
	add ebx, ecx

/* Subround 16 */
	xor edi, ebx
	and edi, edx
	lea eax, [eax+ebp+-165796510]
	xor edi, ecx
	mov ebp, [esi+24]
	add eax, edi
	mov edi, ebx
	rol eax, 5
	add eax, ebx

/* Subround 17 */
	xor edi, eax
	and edi, ecx
	lea edx, [edx+ebp+-1069501632]
	xor edi, ebx
	mov ebp, [esi+44]
	add edx, edi
	mov edi, eax
	rol edx, 9
	add edx, eax

/* Subround 18 */
	xor edi, edx
	and edi, ebx
	lea ecx, [ecx+ebp+643717713]
	xor edi, eax
	mov ebp, [esi]
	add ecx, edi
	mov edi, edx
	rol ecx, 14
	add ecx, edx

/* Subround 19 */
	xor edi, ecx
	and edi, eax
	lea ebx, [ebx+ebp+-373897302]
	xor edi, edx
	mov ebp, [esi+20]
	add ebx, edi
	mov edi, ecx
	rol ebx, 20
	add ebx, ecx

/* Subround 20 */
	xor edi, ebx
	and edi, edx
	lea eax, [eax+ebp+-701558691]
	xor edi, ecx
	mov ebp, [esi+40]
	add eax, edi
	mov edi, ebx
	rol eax, 5
	add eax, ebx

/* Subround 21 */
	xor edi, eax
	and edi, ecx
	lea edx, [edx+ebp+38016083]
	xor edi, ebx
	mov ebp, [esi+60]
	add edx, edi
	mov edi, eax
	rol edx, 9
	add edx, eax

/* Subround 22 */
	xor edi, edx
	and edi, ebx
	lea ecx, [ecx+ebp+-660478335]
	xor edi, eax
	mov ebp, [esi+16]
	add ecx, edi
	mov edi, edx
	rol ecx, 14
	add ecx, edx

/* Subround 23 */
	xor edi, ecx
	and edi, eax
	lea ebx, [ebx+ebp+-405537848]
	xor edi, edx
	mov ebp, [esi+36]
	add ebx, edi
	mov edi, ecx
	rol ebx, 20
	add ebx, ecx

/* Subround 24 */
	xor edi, ebx
	and edi, edx
	lea eax, [eax+ebp+568446438]
	xor edi, ecx
	mov ebp, [esi+56]
	add eax, edi
	mov edi, ebx
	rol eax, 5
	add eax, ebx

/* Subround 25 */
	xor edi, eax
	and edi, ecx
	lea edx, [edx+ebp+-1019803690]
	xor edi, ebx
	mov ebp, [esi+12]
	add edx, edi
	mov edi, eax
	rol edx, 9
	add edx, eax

/* Subround 26 */
	xor edi, edx
	and edi, ebx
	lea ecx, [ecx+ebp+-187363961]
	xor edi, eax
	mov ebp, [esi+32]
	add ecx, edi
	mov edi, edx
	rol ecx, 14
	add ecx, edx

/* Subround 27 */
	xor edi, ecx
	and edi, eax
	lea ebx, [ebx+ebp+1163531501]
	xor edi, edx
	mov ebp, [esi+52]
	add ebx, edi
	mov edi, ecx
	rol ebx, 20
	add ebx, ecx

/* Subround 28 */
	xor edi, ebx
	and edi, edx
	lea eax, [eax+ebp+-1444681467]
	xor edi, ecx
	mov ebp, [esi+8]
	add eax, edi
	mov edi, ebx
	rol eax, 5
	add eax, ebx

/* Subround 29 */
	xor edi, eax
	and edi, ecx
	lea edx, [edx+ebp+-51403784]
	xor edi, ebx
	mov ebp, [esi+28]
	add edx, edi
	mov edi, eax
	rol edx, 9
	add edx, eax

/* Subround 30 */
	xor edi, edx
	and edi, ebx
	lea ecx, [ecx+ebp+1735328473]
	xor edi, eax
	mov ebp, [esi+48]
	add ecx, edi
	mov edi, edx
	rol ecx, 14
	add ecx, edx

/* Subround 31 */
	xor edi, ecx
	and edi, eax
	lea ebx, [ebx+ebp+-1926607734]
	xor edi, edx
	mov ebp, [esi+20]
	add ebx, edi
	mov edi, ecx
	rol ebx, 20
	add ebx, ecx

/* Subround 32 */
	xor edi, edx
	xor edi, ebx
	lea eax, [eax+ebp+-378558]
	add eax, edi
	mov ebp, [esi+32]
	rol eax, 4
	add eax, ebx
	mov edi, ebx

/* Subround 33 */
	xor edi, ecx
	lea edx, [edx+ebp+-2022574463]
	xor edi, eax
	mov ebp, [esi+44]
	add edx, edi
	mov edi, eax
	rol edx, 11
	add edx, eax

/* Subround 34 */
	xor edi, ebx
	xor edi, edx
	lea ecx, [ecx+ebp+1839030562]
	add ecx, edi
	mov ebp, [esi+56]
	rol ecx, 16
	add ecx, edx
	mov edi, edx

/* Subround 35 */
	xor edi, eax
	lea ebx, [ebx+ebp+-35309556]
	xor edi, ecx
	mov ebp, [esi+4]
	add ebx, edi
	mov edi, ecx
	rol ebx, 23
	add ebx, ecx

/* Subround 36 */
	xor edi, edx
	xor edi, ebx
	lea eax, [eax+ebp+-1530992060]
	add eax, edi
	mov ebp, [esi+16]
	rol eax, 4
	add eax, ebx
	mov edi, ebx

/* Subround 37 */
	xor edi, ecx
	lea edx, [edx+ebp+1272893353]
	xor edi, eax
	mov ebp, [esi+28]
	add edx, edi
	mov edi, eax
	rol edx, 11
	add edx, eax

/* Subround 38 */
	xor edi, ebx
	xor edi, edx
	lea ecx, [ecx+ebp+-155497632]
	add ecx, edi
	mov ebp, [esi+40]
	rol ecx, 16
	add ecx, edx
	mov edi, edx

/* Subround 39 */
	xor edi, eax
	lea ebx, [ebx+ebp+-1094730640]
	xor edi, ecx
	mov ebp, [esi+52]
	add ebx, edi
	mov edi, ecx
	rol ebx, 23
	add ebx, ecx

/* Subround 40 */
	xor edi, edx
	xor edi, ebx
	lea eax, [eax+ebp+681279174]
	add eax, edi
	mov ebp, [esi]
	rol eax, 4
	add eax, ebx
	mov edi, ebx

/* Subround 41 */
	xor edi, ecx
	lea edx, [edx+ebp+-358537222]
	xor edi, eax
	mov ebp, [esi+12]
	add edx, edi
	mov edi, eax
	rol edx, 11
	add edx, eax

/* Subround 42 */
	xor edi, ebx
	xor edi, edx
	lea ecx, [ecx+ebp+-722521979]
	add ecx, edi
	mov ebp, [esi+24]
	rol ecx, 16
	add ecx, edx
	mov edi, edx

/* Subround 43 */
	xor edi, eax
	lea ebx, [ebx+ebp+76029189]
	xor edi, ecx
	mov ebp, [esi+36]
	add ebx, edi
	mov edi, ecx
	rol ebx, 23
	add ebx, ecx

/* Subround 44 */
	xor edi, edx
	xor edi, ebx
	lea eax, [eax+ebp+-640364487]
	add eax, edi
	mov ebp, [esi+48]
	rol eax, 4
	add eax, ebx
	mov edi, ebx

/* Subround 45 */
	xor edi, ecx
	lea edx, [edx+ebp+-421815835]
	xor edi, eax
	mov ebp, [esi+60]
	add edx, edi
	mov edi, eax
	rol edx, 11
	add edx, eax

/* Subround 46 */
	xor edi, ebx
	xor edi, edx
	lea ecx, [ecx+ebp+530742520]
	add ecx, edi
	mov ebp, [esi+8]
	rol ecx, 16
	add ecx, edx
	mov edi, edx

/* Subround 47 */
	xor edi, eax
	lea ebx, [ebx+ebp+-995338651]
	xor edi, ecx
	mov ebp, [esi]
	add ebx, edi
	mov edi, edx
	rol ebx, 23
	add ebx, ecx

	nop
/* Subround 48 */
	xor edi, -1
	or edi, ebx
	lea eax, [eax+ebp+-198630844]
	xor edi, ecx
	mov ebp, [esi+28]
	add eax, edi
	mov edi, ecx
	rol eax, 6
	add eax, ebx

/* Subround 49 */
	xor edi, -1
	or edi, eax
	lea edx, [edx+ebp+1126891415]
	xor edi, ebx
	mov ebp, [esi+56]
	add edx, edi
	mov edi, ebx
	rol edx, 10
	add edx, eax

/* Subround 50 */
	xor edi, -1
	or edi, edx
	lea ecx, [ecx+ebp+-1416354905]
	xor edi, eax
	mov ebp, [esi+20]
	add ecx, edi
	mov edi, eax
	rol ecx, 15
	add ecx, edx

/* Subround 51 */
	xor edi, -1
	or edi, ecx
	lea ebx, [ebx+ebp+-57434055]
	xor edi, edx
	mov ebp, [esi+48]
	add ebx, edi
	mov edi, edx
	rol ebx, 21
	add ebx, ecx

/* Subround 52 */
	xor edi, -1
	or edi, ebx
	lea eax, [eax+ebp+1700485571]
	xor edi, ecx
	mov ebp, [esi+12]
	add eax, edi
	mov edi, ecx
	rol eax, 6
	add eax, ebx

/* Subround 53 */
	xor edi, -1
	or edi, eax
	lea edx, [edx+ebp+-1894986606]
	xor edi, ebx
	mov ebp, [esi+40]
	add edx, edi
	mov edi, ebx
	rol edx, 10
	add edx, eax

/* Subround 54 */
	xor edi, -1
	or edi, edx
	lea ecx, [ecx+ebp+-1051523]
	xor edi, eax
	mov ebp, [esi+4]
	add ecx, edi
	mov edi, eax
	rol ecx, 15
	add ecx, edx

/* Subround 55 */
	xor edi, -1
	or edi, ecx
	lea ebx, [ebx+ebp+-2054922799]
	xor edi, edx
	mov ebp, [esi+32]
	add ebx, edi
	mov edi, edx
	rol ebx, 21
	add ebx, ecx

/* Subround 56 */
	xor edi, -1
	or edi, ebx
	lea eax, [eax+ebp+1873313359]
	xor edi, ecx
	mov ebp, [esi+60]
	add eax, edi
	mov edi, ecx
	rol eax, 6
	add eax, ebx

/* Subround 57 */
	xor edi, -1
	or edi, eax
	lea edx, [edx+ebp+-30611744]
	xor edi, ebx
	mov ebp, [esi+24]
	add edx, edi
	mov edi, ebx
	rol edx, 10
	add edx, eax

/* Subround 58 */
	xor edi, -1
	or edi, edx
	lea ecx, [ecx+ebp+-1560198380]
	xor edi, eax
	mov ebp, [esi+52]
	add ecx, edi
	mov edi, eax
	rol ecx, 15
	add ecx, edx

/* Subround 59 */
	xor edi, -1
	or edi, ecx
	lea ebx, [ebx+ebp+1309151649]
	xor edi, edx
	mov ebp, [esi+16]
	add ebx, edi
	mov edi, edx
	rol ebx, 21
	add ebx, ecx

/* Subround 60 */
	xor edi, -1
	or edi, ebx
	lea eax, [eax+ebp+-145523070]
	xor edi, ecx
	mov ebp, [esi+44]
	add eax, edi
	mov edi, ecx
	rol eax, 6
	add eax, ebx

/* Subround 61 */
	xor edi, -1
	or edi, eax
	lea edx, [edx+ebp+-1120210379]
	xor edi, ebx
	mov ebp, [esi+8]
	add edx, edi
	mov edi, ebx
	rol edx, 10
	add edx, eax

/* Subround 62 */
	xor edi, -1
	or edi, edx
	lea ecx, [ecx+ebp+718787259]
	xor edi, eax
	mov ebp, [esi+36]
	add ecx, edi
	mov edi, eax
	rol ecx, 15
	add ecx, edx

/* Subround 63 */
	xor edi, -1
	or edi, ecx
	lea ebx, [ebx+ebp+-343485551]
	xor edi, edx
	mov ebp, [esi+28]
	add ebx, edi
	mov edi, edx
	rol ebx, 21
	add ebx, ecx

	pop edi
	mov ebp, [edi]
	mov esi, [edi+4]
	add eax, ebp
	add ebx, esi
	mov [edi], eax
	mov [edi+4], ebx
	mov eax, [edi+8]
	mov ebx, [edi+12]
	add ecx, eax
	add edx, ebx
	mov [edi+8], ecx
	mov [edi+12], edx

	pop ebx
	pop edi
	pop esi
	pop ebp

	ret
  }
}
