// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.protocols;

import org.logi.crypto.keys.Key;

/**
 * This interface is implemented by classes for the client portion of an
 * interactive authentication protocol.
 *
 * @see org.logi.crypto.protocols.InterAuthServer
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public interface InterAuthClient extends InterProtocolClient{
    
}
