// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.io;
import org.logi.crypto.*;
import org.logi.crypto.keys.*;
import org.logi.crypto.modes.*;
import org.logi.crypto.protocols.*;

import java.io.*;

/**
 * This class can be used to apply an interactive key exchange protocol
 * to a pair of streams and then encrypt all data going through them with
 * the session key exchanged.
 * <p>
 * It can also execute interactive protocols on the streams once they are
 * initialized.
 * <p>
 * This class expects to talk to an equivalent server class.
 *
 * @see org.logi.crypto.io.CipherStreamServer
 * @version 1.0.6
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class CipherStreamClient extends CipherStream {
    
    /**
     * Create a new CipherStreamClient object and ecxhange keys.
     * <p>
     * Create a new object which uses <code>kex</code> to exchange keys with
     * a remote server and then <code>encrypt</code> to encrypt the data to
     * <code>out</code> and <code>decrypt</code> to decrypt data from
     * <code>in</code> and <code>out</code>.
     * <p>
     * if <code>kex==null</code> then the key-exchange step is skipped and
     * the <code>encrypt</code> and <code>decrypt</code> objects must have
     * been initialized with a key beforethis call.
     *
     * @exception CryptoProtocolException if there is a problem exchanging keys.
     * @exception IOException if there is a problem with the underlying streams.
     */
    public CipherStreamClient(InputStream in, OutputStream out, InterKeyExClient kex, EncryptMode encrypt, DecryptMode decrypt) throws CryptoProtocolException, IOException {
        this.in  = in;
        this.out = out;
        if(kex!=null){
            // We are using key-exchange
            execute(kex);
            CipherKey key;
            try{
                key=(CipherKey)kex.sessionKey();
            } catch (ClassCastException e){
                throw new CryptoProtocolException("The exchanged Key was not a CipherKey.");
            }
            encrypt.setKey(key);
            decrypt.setKey(key);
        }
        cOut = new EncryptStream(out, null, encrypt);
        cIn = new DecryptStream(in, null, decrypt);
        this.encrypt=encrypt;
        this.decrypt=decrypt;
    }
    
    /**
     * Executes an interactive protocol. If the encrypt/decrypt mode objects
     * have been initialized with a session key, such as by executing a
     * key-exchange protocol in the constructor, then the protocol will be
     * executed through the encrypted link.
     *
     * @exception CryptoProtocolException if there is a problem with the protocol keys.
     * @exception IOException if there is a problem with the underlying streams.
     */
    public void execute(InterProtocolClient prot) throws IOException, CryptoProtocolException{
        InputStream  i = (cIn ==null ? in  : cIn );
        OutputStream o = (cOut==null ? out : cOut);
        byte[] msg=prot.message(null);
        while(true){
            if(msg==null)
                break;
            writeInt(o,msg.length);
            o.write(msg);
	    o.flush();
            if(prot.completed())
                break;
            int l=readInt(i);
	    if(l<0 || l>prot.maxMessageSize())
	        throw new CryptoProtocolException(l+" is not a valid message size for this protocol.");
            if(msg.length!=l)
                msg=new byte[l];
	    l=i.read(msg);
            if (l<0)
                throw new CryptoProtocolException("Server broke connection");
            msg=prot.message(msg);
        }
    }
        
}
