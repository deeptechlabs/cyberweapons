//
// rmd160.cxx
//
// This algorithm is due to H. Dobbertin, A. Bosselaers, and Bart Preneel,
// and is defined in _RIPE-MD160:_A_Strengthened_Version_of_RIPEMD_
// available at ftp://ftp.esat.kuleuven.ac.be/pub/COSIC/bosselae/ripemd/.
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#include <string.h>
#include "chmisc.hpp"
#include "rmd160.hpp"
#include "clink.h"

const u32 RIPEMD160::H0=0x67452301;
const u32 RIPEMD160::H1=0xefcdab89;
const u32 RIPEMD160::H2=0x98badcfe;
const u32 RIPEMD160::H3=0x10325476;
const u32 RIPEMD160::H4=0xc3d2e1f0;

RIPEMD160::RIPEMD160() : MD4ish(160)
{
  H=new u32[5];

  H[0]=H0;
  H[1]=H1;
  H[2]=H2;
  H[3]=H3;
  H[4]=H4;
}
 
RIPEMD160::~RIPEMD160()
{
  delete[] H;
}

void RIPEMD160::ProcessBlock(const u32* block)
{
  RIPEMD160Transform(H,block);
}

void RIPEMD160::Compress(const u32* iv, const u32* block, u32* result)
{
  memcpy(result,iv,20);
  RIPEMD160Transform(result,block);
}

void RIPEMD160::Compress(const void* iv, const void* block, void* result)
{
  u32 IV[4];
  u32 Block[16];
  u32 Res[4];

  memcpy(IV,iv,16);
  memcpy(Block,block,64);

  CHMisc::MemSwap(IV,5);

  Compress(IV,Block,Res);
  memcpy(result,Res,20);
}

void RIPEMD160::Reset()
{
  MD4ish::Reset();

  H[0]=H0;
  H[1]=H1;
  H[2]=H2;
  H[3]=H3;
  H[4]=H4;
}
