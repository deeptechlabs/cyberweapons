//
// rmd160g.hpp
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#ifndef _RMD160G_HPP
#define _RMD160G_HPP

#include "asmgen.hpp"
#include "a2r160.hpp"

class RMD160AsmGenerator : public AsmGenerator
{
private:
  a2r160 reg;
public:
  static const u32 KL[80];
  static const int rl[80];
  static const int sl[80];

  static const u32 KR[80];
  static const int rr[80];
  static const int sr[80];

  RMD160AsmGenerator(ostream& os);
  ~RMD160AsmGenerator() {}

  void PrintLeftRound1();
  void PrintLeftRound2();
  void PrintLeftRound3();
  void PrintLeftRound4();
  void PrintLeftRound5();
  
  void PrintReload();
  void PrintSaveLeftResult();

  void PrintRightRound1();
  void PrintRightRound2();
  void PrintRightRound3();
  void PrintRightRound4();
  void PrintRightRound5();

  void PrintCombineHalves();

  void Startup();
  void Body();
  void Cleanup();
};

#endif
