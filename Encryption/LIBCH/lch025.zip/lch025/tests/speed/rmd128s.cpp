//
// rmd128s.cpp
// 
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#include <iostream.h>
#include <iomanip.h>
#include <time.h>
#include <string.h>
#include <chnhash/clink.h>
#include "gettsc.inl"

int main(int, char**)
{
  u32 H[4];
  u32 block[16];
  u32 start1, stop1, start2, stop2, t1, t2;

  for (int i=0; i<3; i++)
  {
    GetTSC(start1);
    RIPEMD128Transform(H,block);
    GetTSC(stop1);
    GetTSC(start2);
    RIPEMD128Transform(H,block);
    RIPEMD128Transform(H,block);
    GetTSC(stop2);
  }
    t1=stop1-start1;
    t2=stop2-start2;

 cout <<(t2-t1)<<" cycles"<<endl;
 return(0);
}
