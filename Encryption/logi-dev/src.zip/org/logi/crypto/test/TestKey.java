// Copyright (C) 1998-2000 Logi Ragnarsson

package org.logi.crypto.test;
import org.logi.crypto.*;
import org.logi.crypto.sign.*;
import org.logi.crypto.keys.*;
import org.logi.crypto.modes.*;

import java.util.*;
import java.io.*;

/**
 * This application tests the various Key classes.
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 *
 * @see org.logi.crypto.keys.Key
 */
public class TestKey extends Crypto{

    private TestKey(){}
    
    // Insecure but fast pseud-random number generator
    private static Random rand=new Random();  
    
    private static void help(PrintWriter writer){
        writer.println("Use: java org.logi.crypto.test.TestKey <Caesar|DES|TriDES|Blowfish|RSA|DH>>");
    }
    
    public static KeyPair createKeys(String keyType, PrintWriter details, PrintWriter summary) throws IOException {
        long start=System.currentTimeMillis();
        KeyPair kp=null;
        details.println();
        summary.println("KEY GENERATION");
        
        if(keyType.equals("DES")){
            Key k = new DESKey();
            kp = new KeyPair(k,k);
        } else if(keyType.equals("TriDES")){
            Key k = new TriDESKey();
            kp = new KeyPair(k,k);
        } else if(keyType.equals("Blowfish")){
            Key k = new BlowfishKey();
            kp = new KeyPair(k,k);
        } else if(keyType.equals("RSA")){
            // This is just a test, so 256 bits is enough.
            kp = RSAKey.createKeys(256);
        } else if(keyType.equals("DH")){
            // This is just a test, so 256 bits is enough.
            DHKey k = new DHKey(256);
            kp = new KeyPair(k.getPublic(),k);
        } else if(keyType.equals("Caesar")){
            Key k = new CaesarKey();
            kp = new KeyPair(k,k);
        } else {
            help(summary);
            return null;
        }
        long stop=System.currentTimeMillis();
        details.println("Time="+TestIterate.metricString(0.001*(stop-start),1000)+"s");
        return kp;
    }
    
   private static void printKeys(Key pub, Key pri, PrintWriter writer) throws IOException {
      if(pri instanceof SymmetricKey){
	 pub.prettyPrint(writer);
	 writer.println();
      } else {
	 pub.prettyPrint(writer);
	 writer.println();
	 pri.prettyPrint(writer);
	 writer.println();
      }
   }

   private static boolean testCDS(Key pub, Key pri, PrintWriter details, PrintWriter summary){
      details.println();
      summary.println("TESTING CONVERSION TO AND FROM STRINGS");
      boolean ok=true;
      try{
	 Key k;
	 String cds,pretty;
	 StringWriter sw;
	 PrintWriter pw;

	 // test toString/fromString
	 cds=pub.toString();
	 details.println(cds);
	 k = (Key)fromString(cds);
	 if(!pub.equals(k)) {
	    ok=false;
	    details.println("not equal!");
	 }

	 // test prettyPrint/fromString
	 sw=new StringWriter();
	 pw=new PrintWriter(sw);
	 pub.prettyPrint(pw);
	 pw.flush();
	 pretty = sw.toString();
	 if(!pretty.equals(cds)) {
	    details.println(pretty);
	    k = (Key)fromString(pretty);
	    if(!pub.equals(k)) {
	       ok=false;
	       details.println("not equal!");
	    }
	 }

	 // now repeat for private key
	 if(!(pri instanceof SymmetricKey)){
	    // test toString/fromString
	    cds=pri.toString();
	    details.println(cds);
	    k = (Key)fromString(cds);
	    if(!pri.equals(k)) {
	       ok=false;
	       details.println("not equal!");
	    }
	    
	    // test prettyPrint/fromString
	    sw=new StringWriter();
	    pw=new PrintWriter(sw);
	    pri.prettyPrint(pw);
	    pw.flush();
	    pretty = sw.toString();
	    if(!pretty.equals(cds)) {
	       details.println(pretty);
	       k = (Key)fromString(pretty);
	       if(!pri.equals(k)) {
		  ok=false;
		  details.println("not equal!");
	       }
	    }
	 }
	 
      } catch (Throwable e){
	 summary.println(e);
	 e.printStackTrace(summary);
	 ok = false;
      }
      if(!ok)
	summary.println("Failed!\07");
      return ok;
   }

    private static boolean testCrypt(CipherKey pub, CipherKey pri, PrintWriter details, PrintWriter summary){
        details.println();
        summary.println("TESTING ENCRYPTION/DECRYPTION");
        boolean ok=true;
        try{
            int pbs = pub.plainBlockSize();
            int cbs = pub.cipherBlockSize();
            
            int size = pub.equals(pri) ? 256*1024 : 8*1024;
            int numBlock = (size+pbs/2)/pbs;
            size = numBlock*pbs;
            
            byte[] plain  = new byte[size];
            byte[] cipher = new byte[numBlock*cbs];
            byte[] plain2 = new byte[size];
            
            java.util.Random rand = new java.util.Random();
            rand.nextBytes(plain);
            rand.nextBytes(cipher);
            
            details.println("Plain/cipher block sizes = "
			    +pub.plainBlockSize()+" B, "
			    +pub.cipherBlockSize()+" B");
            details.println("Buffer size = "+TestIterate.metricString(size,1024)+"B");
	   
            Thread.sleep(1000); // To give the system time to settle down...
            details.print("Encrypting:");
            long start=System.currentTimeMillis();
            for (int i=0; i<numBlock; i++)
                pub.encrypt(plain,i*pbs, cipher,i*cbs);
            long stop=System.currentTimeMillis();
            details.println("\ttime="+TestIterate.metricString(0.001*(stop-start),1000)+
                               "s\t throughput="+TestIterate.metricString(1000.0*size/(stop-start),1024)+"B/s"
                              );
            
            start=System.currentTimeMillis();
            details.print("Decrypting:");
            for (int i=0; i<numBlock; i++)
                pri.decrypt(cipher,i*cbs, plain2,i*pbs);
            stop = System.currentTimeMillis();
            details.println("\ttime="+TestIterate.metricString(0.001*(stop-start),1000)+
			    "s\t throughput="+TestIterate.metricString(1000.0*size/(stop-start),1024)+"B/s"
			    );
            
            details.print("Checking...");
            for(int i=0; i<size; i++)
                if(plain[i] != plain2[i]){
                    summary.println("Error at offset "+i);
                    ok=false;
                    break;
                }
            details.println();
            
        } catch (Throwable e){
            details.println(e);
            e.printStackTrace(details);
            ok = false;
        }
        if(!ok) {
	    summary.println("Failed!\07");
	}
        return ok;
    }

    private static boolean testVector(String algorithm, PrintWriter details, PrintWriter summary){
        details.println();
        summary.println("TESTING AGAINST TEST-VECTORS");
        boolean ok=true;
        Reader in;
        try {
            in = new FileReader("vectors."+algorithm);
        } catch (IOException e) {
            summary.println("Unable to read vectors."+algorithm+" from the current directory.");
            details.println("You may need to run the test program from the test directory.");
	    details.println("Test skipped.");
            return true;
        }
        try {
            StreamTokenizer tok = new StreamTokenizer(in);
            tok.ordinaryChars('0','9');
            tok.wordChars('0','9');
            while(tok.nextToken()==StreamTokenizer.TT_WORD){
                byte[] keyBytes = fromHexString(tok.sval);
                tok.nextToken();
                byte[] plain = fromHexString(tok.sval);
                tok.nextToken();
                byte[] cipher = fromHexString(tok.sval);
                CipherKey key = Crypto.makeSessionKey(algorithm+"Key",keyBytes);
                byte[] cipher2 = new byte[cipher.length];
                key.encrypt(plain,0, cipher2,0);
	        byte[] plain2 = new byte[plain.length];
                key.decrypt(cipher,0, plain2,0);
                if(!equal(cipher,cipher2) || !equal(plain,plain2)){
                    details.print("Failed: ");
		    ok=false;
                } else {
                    details.print("Passed: ");
                }
                details.println(key+"  "+hexString(plain)+"  "+hexString(cipher));
            }
        } catch (IOException e){
            e.printStackTrace(summary);
            return false;
        } catch (InvalidCDSException e){
            e.printStackTrace(summary);
            return false;
        }
        if(!ok) {
	    summary.println("Failed!\07");
	}
        return ok;
    }
    
    private static boolean testSign(SignatureKey pub, SignatureKey pri, PrintWriter details, PrintWriter summary){
        details.println();
        summary.println("TESTING SIGNATURES");
        boolean ok;
        try {
            byte[] buffer = new byte[1024];
            rand.nextBytes(buffer);
            Fingerprint fp=Fingerprint.create(buffer,"SHA1");
            details.println("Good signature:");
            Signature s1=pri.sign(fp);
	    s1.prettyPrint(details);
            details.println();
            boolean m1 = pub.verify(s1,fp);
            details.println("Signature verified: "+(m1?"Yes":"No"));

            details.println("Bogus signature:");
            byte[] bogus = s1.getBytes();
            bogus[3]^=5;
            Signature s2=new Signature("SHA1", bogus);
	    s2.prettyPrint(details);
            details.println();
            boolean m2=pub.verify(s2,fp);
            details.println("Signature verified: "+(m2?"Yes":"No"));

            ok = m1 && !m2 ;
        } catch (Throwable e){
            details.println(e);
            e.printStackTrace(summary);
            ok = false;
        }
        if(!ok) {
	    summary.println("Failed!\07");
	}
        return ok;
    }
    
    private static boolean testBlindSign(BlindSignatureKey pub, BlindSignatureKey pri, PrintWriter details, PrintWriter summary){
       details.println();
       summary.println("TESTING BLIND SIGNATURES");
       boolean ok;
       try {
	  byte[] buffer = new byte[1024];
	  rand.nextBytes(buffer);
	  Fingerprint fp=Fingerprint.create(buffer,"SHA1");
	  fp.prettyPrint(details);
	  details.println();
	  BlindingFactor bf = pub.createBlindingFactor();
	  bf.prettyPrint(details);
	  details.println();
	  BlindFingerprint bfp = pub.blind(fp,bf);
	  bfp.prettyPrint(details);
	  details.println();
	  BlindSignature bs = pri.sign(bfp);
	  bs.prettyPrint(details);
	  details.println();
	  Signature s = pub.unBlind(bs,bf);
	  s.prettyPrint(details);
	  details.println();
	  ok = pub.verify(s,fp);
	  details.println("Signature verified: "+(ok?"Yes":"No"));
       } catch (Throwable e){
	  summary.println(e);
	  e.printStackTrace(summary);
	  ok = false;
       }
       if(!ok) {
	  summary.println("Failed!\07");
       }
       return ok;
    }
   
    private static EncryptSession createEncrypt(String mode, CipherKey pub, CipherKey pri, PrintWriter details, PrintWriter summary) throws CryptoException {
        if (mode.equals("ECB")){
            return new EncryptECB(pub);
        } else if (mode.equals("CBC")){
            return new EncryptCBC(pub);
        } else if (mode.equals("CFB")){
            return new EncryptCFB(pri);
        } else if (mode.equals("OFB")){
            return new EncryptOFB(pri,1024);
        }
       
        help(summary);
        return null;
    }
    
    private static DecryptSession createDecrypt(String mode, CipherKey pub, CipherKey pri, PrintWriter details, PrintWriter summary) throws CryptoException {
        if (mode.equals("ECB")){
            return new DecryptECB(pri);
        } else if (mode.equals("CBC")){
            return new DecryptCBC(pri);
        } else if (mode.equals("CFB")){
            return new DecryptCFB(pri);
        } else if (mode.equals("OFB")){
            return new DecryptOFB(pri,1024);
        }
       
        help(summary);
        return null;
    }
    
   private static boolean testMode(CipherKey pub, CipherKey pri, String mode, PrintWriter details, PrintWriter summary) {
      if(pub.getAlgorithm().equals("Diffie-Hellman")) {
	 if(mode.equals("CFB") || mode.equals("OFB")) {
	    details.println("DH is a probabilistic encryption algorithm and");
	    details.println("can't be used in OFB or CFB mode. This is not a bug.");
	    return true;
	 }
      }
      
      boolean ok=true;
      EncryptSession em = null;
      DecryptSession dm = null;
      
      try {
	 em = createEncrypt(mode,(CipherKey)pub,(CipherKey)pri,details,summary);
	 if (em==null)
	   return false;
	 dm = createDecrypt(mode,(CipherKey)pub,(CipherKey)pri,details,summary);
	 if (dm==null) {
	    em.close();
	    return false;
	 }
	 
	 int size = pub.isPrivate() ? 16384 : 4096;
	 if (mode.equals("CFB"))
	   // CFB takes too long
	   size /= Math.max(1,em.getKey().getSize()/8);
	 
	 long start=System.currentTimeMillis();
	 details.println();
	 summary.println("TESTING "+mode+" MODE");
	 details.println("Plain/cipher block sizes = "
			 +em.getKey().plainBlockSize()+" B, "
			 +em.getKey().cipherBlockSize()+" B");
	 details.println("Buffer size = "+TestIterate.metricString(size,1024)+"B");
	 
	 Random rand = new Random();
	 byte[] plain1  = new byte[size];
	 byte[] plain2  = new byte[size];
	 byte[] cipher = new byte[8];
	 rand.nextBytes(plain1);
	 
	 details.print("Encrypting 0%\r");
	 int i=0;
	 int j=0;
	 while(i<plain1.length){
	    // plain1[0..i-1] has been encrypted and put in cipher[0..j-1]
	    int n = Math.min(rand.nextInt()%32+32, plain1.length-i);
	    byte[] t1;
	    if(i+n<plain1.length) {
	       t1 = em.encrypt(plain1,i,n);
	    } else {
	       t1 = em.flush(plain1,i,n);
	    }
	    i+=n;
	    cipher = ensureArrayLength(cipher, j, j+t1.length);
	    System.arraycopy(t1,0, cipher,j, t1.length);
	    j+=t1.length;
	    details.print("Encrypting "+(100*i/plain1.length)+"%\r");
	    details.flush();
	 }
	 cipher = trimArrayLength(cipher, j);
	 details.println();
	 
	 details.print("Decrypting 0%\r");
	 i=0;
	 j=0;
	 while(j<cipher.length){
	    // cipher[0..j-1] has been encrypted and put in plain2[0..i-1]
	    int n = Math.min(rand.nextInt()%32+32, cipher.length-j);
	    byte[] t1 = dm.decrypt(cipher,j,n);
	    plain2 = ensureArrayLength(plain2, i, i+t1.length);  // to take random padding if any
	    System.arraycopy(t1,0, plain2,i, t1.length);
	    j+=n;
	    i+=t1.length;
	    details.print("Decrypting "+(100*j/cipher.length)+"%\r");
	    details.flush();
	 }
	 details.println();
	 
	 details.print("Checking 0%\r");
	 details.flush();
	 for(i=0; i<plain1.length; i++) {
	    if (plain1[i]!=plain2[i]) {
	       summary.println("Error at offset "+i);
	       em.close();
	       dm.close();
	       return false;
	    }
	    if((plain1.length-i+1)%Math.max(1,(size/100)) == 0) {
	       details.print("Checking "+(100*j/cipher.length)+"%\r");
	       details.flush();
	    }
	 }
	 
	 long stop=System.currentTimeMillis();
	 details.println("\nTime="+(stop-start)+"ms");
	 
      } catch (Throwable e){
	 details.println(e);
	 e.printStackTrace(summary);
	 ok = false;
      } finally {
	 if(em!=null)
	   em.close();
	 if(dm!=null)
	   dm.close();
      }
      return ok;
   }
    
   public static boolean test(String keyType, Hashtable tests, Hashtable modes, PrintWriter details, PrintWriter summary) throws IOException {
      if(details==null)
	details=new PrintWriter(new BitBucket());
      
      summary.println("=================================================");
      summary.println("TESTING LOW LEVEL FUNCTIONS OF "+keyType+" KEYS.");
      
      KeyPair kp = createKeys(keyType, details, summary);
      if (kp==null)
	return false;
      
      Key pub = kp.getPublic();
      Key pri = kp.getPrivate();
      
      boolean ok=true;
      
      if(tests.get("CDS")!=null) {
	 ok &= testCDS(pub,pri,details,summary);
      }
      
      if(pub instanceof CipherKey){
	 if(tests.get("Crypt")!=null)
	   ok &= testCrypt((CipherKey)pub,(CipherKey)pri,details,summary);
	 if(tests.get("Vector")!=null)
	   ok &= testVector(pub.getAlgorithm(),details,summary);

	 Enumeration mit=modes.elements();
	 while(mit.hasMoreElements()) {
	    String mode=(String)mit.nextElement();
	    ok &= testMode((CipherKey)pub, (CipherKey)pri, mode, details, summary);
	 }
      }
      
      
      if(pub instanceof SignatureKey)
	if(tests.get("Sign")!=null)
	  ok &= testSign((SignatureKey)pub,(SignatureKey)pri,details,summary);
      
      if(pub instanceof BlindSignatureKey)
	if(tests.get("BlindSign")!=null)
	  ok &= testBlindSign((BlindSignatureKey)pub,(BlindSignatureKey)pri,details,summary);
      details.flush();
      summary.flush();
      
      return ok;
   }
   
   public static void main(String[] arg) throws Exception {
      Crypto.initRandom();
      PrintWriter w = new PrintWriter(System.out, true);
      if(arg.length==0){
	 help(w);
	 return;
      }

      Hashtable tests=new Hashtable();
      tests.put("CDS","CDS");
      tests.put("Crypt","Crypt");
      tests.put("Vector","Vector");
      tests.put("Sign","Sign");
      tests.put("BlindSign","BlindSign");
      
      Hashtable modes = new Hashtable();
      modes.put("ECB", "ECB");
      modes.put("CBC", "CBC");
      modes.put("CFB", "CFB");
      modes.put("OFB", "OFB");
      
      boolean ok = test(arg[0], tests, modes, w,w);
      System.out.println();
      if(ok)
	System.out.println("All tests passed");
      else
	System.out.println("Some tests failed");
   }
   
}
