// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.keys;
import org.logi.crypto.*;

/**
 * This exception is thrown when there is a problem with a key object. This
 * hapens if a key can't be found, a key is too short for a particular
 * purpose, a public key is used where a private key is expected, etc.
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class KeyException extends CryptoException{

    /** Create a new KeyException with no message. */
    public KeyException(){
    }

    /** Create a new KeyException with the message msg. */
    public KeyException(String msg){
        super(msg);
    }
    
}
