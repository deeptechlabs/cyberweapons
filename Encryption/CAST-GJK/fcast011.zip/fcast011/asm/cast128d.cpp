//
// cast128d.cpp
//
// Copyright (C) 1997 Peter Gutmann (pgut001@cs.auckland.ac.nz) and
//                    Leonard Janke (janke@unixg.ubc.ca)

#include "cast128d.hpp"

CAST128DecryptAsmGenerator::CAST128DecryptAsmGenerator(ostream& os)
 : CAST128AsmGenerator(os)
{
}

void CAST128DecryptAsmGenerator::Body()
{
  OpPtr xor=&AsmGenerator::Xor;
  OpPtr sub=&AsmGenerator::Sub;
  OpPtr add=&AsmGenerator::Add;

  Link(15,xor,sub,add,top);
  Link(14,add,xor,sub,middle);
  Link(13,sub,add,xor,middle);
  Link(12,xor,sub,add,middle);
  Link(11,add,xor,sub,middle);
  Link(10,sub,add,xor,middle);
  Link(9,xor,sub,add,middle);
  Link(8,add,xor,sub,middle);
  Link(7,sub,add,xor,middle);
  Link(6,xor,sub,add,middle);
  Link(5,add,xor,sub,middle);
  Link(4,sub,add,xor,middle);
  Link(3,xor,sub,add,middle);
  Link(2,add,xor,sub,middle);
  Link(1,sub,add,xor,middle);
  Link(0,xor,sub,add,bottom);
}
