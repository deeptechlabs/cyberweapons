/*
 * chtypes.h
 *
 * convenient typedef's 
 *
 * This software was written by Leonard Janke (janke@unixg.ubc.ca)
 * in 1996-7 and is entered, by  him, into the public domain.
 */

#ifndef _CHTYPES_H
#define _CHTYPES_H

#if defined(__WATCOMC__) || defined(_MSC_VER)
typedef unsigned __int64 u64;
#elif defined(__GNUC__)
typedef unsigned long long u64;
#endif
#ifndef U32DEFINED
typedef unsigned long u32;
#define U32DEFINED
#endif
typedef unsigned short u16;
typedef unsigned char u8;


#endif
