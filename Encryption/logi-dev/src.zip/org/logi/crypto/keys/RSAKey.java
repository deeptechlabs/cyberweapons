// Copyright (C) 1997-2000 Logi Ragnarsson

package org.logi.crypto.keys;
import org.logi.crypto.*;
import org.logi.crypto.sign.*;

import java.math.BigInteger;

import java.io.IOException;
import java.io.PrintWriter;

/**
 * An instance of this class handles a single RSA key.<p>
 
 * The RSA algorithm is probably the best known and most widely used public
 * key algorithm. Breaking one RSA key is believed to be as difficult as
 * factoring the modulus (n) of the group in which calculations are done.
 * When speaking of the size of an RSA key, it is understood to be the size
 * of this modulus.<p>
 
 * The first 512 bit number is expected to be factored by the end of 1999.
 * 1024 bits should be more than enough in most cases, but the clinically
 * paranoid may want to use up to 4096 bit keys.<p>
 
 * Each RSA key is a pair (d,n) of integers and matches another key (e,n).
 * If P is a block of plain data represented as an integer smaller than n,
 * then it can be encrypted with the transformation:
 
 * <blockquote>
 *   <code>E = (P^e) mod n</code>
 * </blockquote>
 * which has the inverse transformation:
 * <blockquote>
 *   <code>P = (E^d) mod n</code>
 * </blockquote><p>

 * The keys' owner will keep (d,n) secret and publish (e,n) as widely as
 * possible. This allows anyone who gets hold of the public key to encrypt
 * data which can only be decrypted with the corresponding private key. All
 * public keys generated with this package will use the exponent 65537.<p>
 
 * Data that is encrypted with a private key can similarly only be
 * decrypted with the corresponding public key. This is useful for digital
 * signatures.<p>
 
 * When P is created from an array of bytes, it will correspond to as many
 * bytes of plain data as the bytes needed to store n, less one. When
 * encrypting less than a full block of data, the data should be put in the
 * most significant bytes of the plaintext-block and appended with random
 * data. This is done by all relevant classes in the logi.crypto library.
 * The plaintext block is encrypted to form a ciphertext block with as many
 * bytes as are needed to store the modulus.<p>

 * Note that since signing is the same operation as decryption, you should
 * not sign data from an unknown source with a key also used for decrypting
 * information without hashing it first. I.e. when implementing a system
 * always perform the hashing in a process trusted by the owner of the key,
 * or in speciali circumstances where you wish to sign unknown data, create
 * a separate RSA key-pair for this.
 
 * This implementation was originally done from a description given in
 * Gallian's <i>Contemporary Abstract Algebra</i>, but various changes from
 * various sources have been incorporated.<p>
 
 * When a key-pair is created, the private key will actually be an instance
 * of the RSAKeyChin class, which uses the Chinese Remainder Theorem to
 * speed up exponentiation.<p>
 
 * The CDS for the RSAKey class is <code>RSAKey(r,n,pub)</code> for a
 * public key, <code>RSAKey(r,n,pri)</code> for a private key or
 * <code>RSAKey(r,n,p)</code> for a private key where we know one factor of
 * <code>n</code>. In all cases <code>r</code>, <code>n</code> and
 * <code>p</code> are hexadecimal numbers.
 
 * @see org.logi.crypto.Crypto#fromString(String)
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 * @version 1.1.0
 */
public class RSAKey extends K implements CipherKey,SignatureKey,BlindSignatureKey {
    
    /** <code>R</code> is the exponent used in all created public keys. */
    protected static final BigInteger R=BigInteger.valueOf(65537);
    
    /** The RSA key exponent */
    protected BigInteger r;
    
    /** The RSA key modulus */
    protected BigInteger n;
    
    /** Is it a private key? */
    protected boolean pri;
    
    /** The fingerprint for the other key in the pair, or null. */
    protected Fingerprint matchPrint=null;
    
    ///////////////////////////////////////////////////////////////////////
    // KEY MANAGEMENT CODE
    
    /**
     * Create a new RSA key <code>(r,n)</code>.
     * It is a private key if <code>pri</code> is true.
     */
    public RSAKey(BigInteger r, BigInteger n, boolean pri) {
        super();
        this.pri = pri;
        this.r = r;
        this.n = n;
    }
    
    /**
     * Used by Crypto.fromString when parsing a CDS.<p>

     * A valid CDS can be created by calling the toString() method.

     * @exception InvalidCDSException if the CDS is malformed.
     * @see org.logi.crypto.Crypto#fromString(String)
     */
    public static RSAKey parseCDS(String[] param) throws InvalidCDSException{
       if(param.length!=3)
	 throw new InvalidCDSException("invalid number of parameters in the CDS RSAKey(r,n,pub|pri) or RSAKey(r,n,p)");

       BigInteger r = new BigInteger(param[0],16);
       BigInteger n = new BigInteger(param[1],16);
       if(param[2].equals("pri"))       // private key
	 return new RSAKey(r,n,true);
       if(param[2].equals("pub"))        // public key
	 return new RSAKey(r,n,false);

       // we have a modulus factor, so it must be a private key.
       try{
	  BigInteger p = new BigInteger(param[2],16);
	  return new RSAKeyChin(r,n,p,true);
       } catch (Exception e) {
	  throw new InvalidCDSException(e.getMessage());
       }
    }

    /** Returns the largest prime <code>p &lt;= start</code> */
    public static BigInteger findPrime(BigInteger start){
	BigInteger p = start;
	if(!start.testBit(0))
	    p = p.subtract(ONE);
	while(!p.isProbablePrime(primeCertainty))
	    p = p.subtract(TWO);
	return p;
    }

    // The below re-implementation of createKeys takes more than twice
    // the time of the old implementation. This might change depending
    // on the speed-difference between JIT-compiled java code and
    // native code and the speed of the random number generator.
    // 
    // My testing was done on a non-JIT linux system with a
    // /dev/urandom device which would be the most favourable to the
    // original implementation. A good JIT and a slow PRNG would
    // favour the re-implementation.
   
    /**
     * Create a pair of public/private keys. The key modulo will be
     * <code>bitLength</code> or <code>bitLength-1</code> bits.
     *
    public static KeyPair createKeys(int bitLength){
        if (bitLength<256)
            bitLength=256;
        
	BigInteger p=findPrime(new BigInteger(bitLength/2, random));
	BigInteger q=findPrime(new BigInteger(bitLength/2, random));
	BigInteger m=p.subtract(ONE).multiply(q.subtract(ONE));
	BigInteger s=R.modInverse(m);
	BigInteger n=p.multiply(q);

        Key pub=new RSAKey (R,n,false);
        Key pri=null;
        try {
            pri=new RSAKeyChin(s,n,p, true);
        } catch (KeyException e){
            // Won't happen unless there is a bug in the above, but just in case...
            e.printStackTrace();
            pri=new RSAKey(s,n,true);
        }
        return new KeyPair(pub,pri);
    }*/
    
    /**
     * Create a pair of public/private keys. The key modulo will be
     * <code>bitLength</code> or <code>bitLength-1</code> bits.
     */
    public static KeyPair createKeys(int bitLength){
        if (bitLength<256)
            bitLength=256;
        
        BigInteger p=null;
        BigInteger q=null;
        BigInteger s=null;
        BigInteger n=null;
        while(n==null) {
            try{
                p=new BigInteger(bitLength/2, primeCertainty, random);
                q=new BigInteger(bitLength/2, primeCertainty, random);
                BigInteger m=p.subtract(ONE).multiply(q.subtract(ONE));
                s=R.modInverse(m);
                n=p.multiply(q);
            } catch (ArithmeticException e) {
                // Key generation failed... just try again.
                n=null;
            }
        }

        Key pub=new RSAKey    (R,n,false);
        Key pri=null;
        try {
            pri=new RSAKeyChin(s,n,p, true);
        } catch (KeyException e){
            // Won't happen unless there is a bug in the above, but just in case...
            e.printStackTrace();
            pri=new RSAKey(s,n,true);
        }
        return new KeyPair(pub,pri);
    }
    
    /**
     * Create a pair of public/private keys from a username/password pair.
     * The public exponent will be 65536 and the private exponent will have
     * <code>bitLength</code> or <code>bitLength-1</code> bits.
     
     * <p> The keys are created by hashing the password, appending with
     * <code>0</code>'s until it is <code>bitLength</code> bits long and
     * searching for a prime <code>p</code>by counting down from there.
     * Another prime <code>q</code> is found in the same way, but the
     * username is prepended to the password before hashing. Key-generation
     * proceeds as normally from there.
     
     * <p>The hashFunction parameters directs which hash function to use.
     * It must be the name of a supported hash function, such as MD5 or
     * SHA1.
     
     * <p> The <code>username</code> does not need to be secret and can in
     * fact be a fixed string. It plays a similar role as SALT in unix
     * password systems in protecting against dictionary attacks.
     
     * @exception InvalidCDSException if the specified hash function is not available.
     **/
    public static KeyPair createKeys(String username, String password, String hashFunction, int bitLength) throws InvalidCDSException {
        if (bitLength<256)
            bitLength=256;

	BigInteger p,q;

        byte[] b = Fingerprint.create(password, hashFunction).getBytes();
        p = new BigInteger(1,b);
        p = p.shiftLeft(bitLength/2-p.bitLength());
        p=findPrime(p);

        b = Fingerprint.create(username+":"+password, hashFunction).getBytes();
        q = new BigInteger(1,b);
        q = q.shiftLeft(bitLength/2-q.bitLength());
        q=findPrime(q);

        BigInteger m=p.subtract(ONE).multiply(q.subtract(ONE));
        BigInteger s=R.modInverse(m);
        BigInteger n=p.multiply(q);

        Key pub=new RSAKey (R,n,false);
        Key pri=null;
        try {
            pri=new RSAKeyChin(s,n,p, true);
        } catch (KeyException e){
            // Won't happen unless there is a bug in the above, but just in case...
            e.printStackTrace();
            pri=new RSAKey(s,n,true);
        }
        return new KeyPair(pub,pri);
    }
    
    /**
     * Create a KeyPair object holding objects for the public RSA key
     * <code>(r,n)</code> and the private RSA key (s,n).
     *
     * @exception KeyException if (r,n) and (s,n) does not describe a valid
     * pair of RSA keys.
     */
    public static KeyPair createKeys(BigInteger r, BigInteger s, BigInteger n) throws KeyException {
        Key pub = new RSAKey(r,n, false);
        Key pri = new RSAKey(s,n, true);
        //try{
            return new KeyPair(pub,pri);
        //} catch (Exception e) {
        //    throw new KeyException("The (r,s,n) triplet does not specify a matching pair of RSA keys.");
        //}
    }
    
    /** Return the size of the key modulo in bits. */
    public int getSize(){
        return n.bitLength();
    }
    
    /** The name of the algorithm is "RSA". */
    public String getAlgorithm(){
        return ("RSA");
    }

    /** Return the RSA exponent. */
    public BigInteger getExponent(){
	return r;
    }
    
    /** Return the RSA modulus. */
    public BigInteger getModulus(){
	return n;
    }
    
    /**
     * Calculate the fingerprint for this key or the other in the
     * pair.
     *
     * @see org.logi.crypto.K#getFingerprint
     * @see org.logi.crypto.K#matchFingerprint
     */
    protected Fingerprint calcFingerprint(boolean other, String algorithm) throws InvalidCDSException {
        // The key-pair is uniquely defined by n, since it factors uniquely
        // into p and q which are used to calculate both exponents.
        HashState fs=HashState.create(algorithm);
        fs.update(n.toByteArray());
        if(other==pri)
            fs.update("pub");
        else
            fs.update("pri");
        return fs.calculate();
    }
    
    /** Return true iff this is a private key. */
    public boolean isPrivate(){
        return pri;
    }
    
    /**
     * Return a CDS for this key.
     *
     * @see org.logi.crypto.Crypto#fromString
     */
    public String toString(){
        return "RSAKey("+
	 r.toString(16)+','+
	 n.toString(16)+','+
	 (pri?"pri":"pub")+")";
    }
    
   /**
    * Print this object to out, indented with ind tabs, going down at most
    * rec levels of recursion. */
   public void prettyPrint(PrintWriter out, int ind, int rec) throws IOException {
      if(rec<0)
	return;
      for(int i=0; i<ind; i++)
	out.print('\t');
      out.println("RSAKey(");

      for(int i=0; i<=ind; i++)
	out.print('\t');
      out.print(r.toString(16));
      out.println(",");
      
      for(int i=0; i<=ind; i++)
	out.print('\t');
      out.print(n.toString(16));
      out.println(",");
      
      for(int i=0; i<=ind; i++)
	out.print('\t');
      out.println(pri ?  "pri" : "pub");
      
      for(int i=0; i<ind; i++)
	out.print('\t');
      out.print(")");
    }
   
    /** Return true iff the two keys are equivalent. */
    public boolean equals(Object o){
        if (o==null)
            return false;
        if((o instanceof RSAKey) || (o instanceof RSAKeyChin)){
            RSAKey rsa = (RSAKey)o;
            return (r.equals(rsa.r) &&
                    n.equals(rsa.n) &&
                    pri==rsa.pri);
        } else
            return false;
    }
    
    /**
     * Check if a key mathces this. This is true if this and key are a matched
     * pair of public/private keys. */
    public final boolean matches(Key key){
        if (key.getClass() != this.getClass())
            return false;
        RSAKey k=(RSAKey)key;
        if (!n.equals(k.n))
            return false;
        return true;
    }

   
    ///////////////////////////////////////////////////////////////////////
    // CIPHER CODE
    
    /**
     * Returns the size of the blocks that can be encrypted in one call
     * to encrypt(). For RSA keys this depends on the size of the key.
     */
    public int plainBlockSize(){
        return (n.bitLength()-1)/8;
    }
    
    /**
     * Returns the size of the blocks that can be decrypted in one call
     * to decrypt(). For RSA keys this depends on the size of the key.
     */
    public int cipherBlockSize(){
        return plainBlockSize()+1;
    }
    
    /**
     * Encrypt one block of data. The plaintext is taken from
     * <code>source</code> starting at offset <code>i</code> and
     * ciphertext is written to <code>dest</code>, starting at
     * offset <code>j</code>.
     * <p>
     * The amount of data read and written will match the values returned
     * by <code>plainBlockSize()</code> and <code>cipherBlockSize()</code>.
     */
    public void encrypt(byte[] source, int i, byte[] dest, int j){
       int plainSize = plainBlockSize();
       byte[] plain;
       
       if(i==0 && source.length==plainSize)
	 plain = source;
       else{
	  plain = new byte[plainSize];
	  System.arraycopy(source,i, plain,0, plainSize);
       }
       
       BigInteger P = new BigInteger(1,plain);
       BigInteger C = P.modPow(r,n);

       
       
       
       byte[] cipher = C.toByteArray();
       if(cipher.length >= plainSize+1)
	 // The output is a full cipher block.
	 System.arraycopy(cipher,cipher.length-(plainSize+1), dest, j, plainSize+1);
       else{
	  // The output is a bit on the short side
	  System.arraycopy(cipher,0, dest, j+(plainSize+1)-cipher.length, cipher.length);
	  for (int k=plainSize-cipher.length; k>=0; k--)
	    dest[j+k]=0;
       }
    }
    
    /**
     * Decrypt one block of data. The ciphertext is taken from
     * <code>source</code> starting at offset <code>i</code> and
     * plaintext is written to <code>dest</code>, starting at
     * offset <code>j</code>.
     * <p>
     * The amount of data read and written will match the values returned
     * by <code>cipherBlockSize()</code> and <code>plainBlockSize()</code>.
     */
    public void decrypt(byte[] source, int i, byte[] dest, int j){
       int plainSize = plainBlockSize();
       byte[] cipher;
       
       if(i==0 && source.length==plainSize+1)
	 cipher = source;
       else{
	  cipher = new byte[plainSize+1];
	  System.arraycopy(source,i, cipher,0, plainSize+1);
       }
        
       BigInteger C=new BigInteger(1,cipher);
       BigInteger P=C.modPow(r,n);

       
       

       byte[]plain = P.toByteArray();
       if(plain.length >= plainSize)
	 // The output is a full plain block
	 System.arraycopy(plain,plain.length-plainSize, dest, j, plainSize);
       else {
	  // The output is a bit on the short side
	  System.arraycopy(plain,0, dest,j+plainSize-plain.length, plain.length);
	  for (int k=plainSize-plain.length-1; k>=0; k--)
	    dest[j+k]=0;
       }
    }

   
    ///////////////////////////////////////////////////////////////////////
    // SIGNATURE CODE
    
    /**
     * Returns the maximum size in bytes of the fingerprint
     * that can be signed. */
    public int signBlockSize(){
        return plainBlockSize();
    }
    
    /**
     * Returns the length of the signature in bytes. */
    public int signatureSize(){
        return cipherBlockSize();
    }
    
    /**
     * Create a signature for a Fingerprint with a private key.
     
     * If fp is a BlindFingerprint, then a BlindSignature will be returned,
     * so in this case the return value can be safely typecast to
     * BlindSignature.

     * @exception KeyException if the key modulus is shorter than the signature.
     * @exception KeyException if this is not a private key
     *
    public Signature sign(Fingerprint fp) throws KeyException {
       if(!pri)
	 throw new KeyException("Signatures can only be generated with private RSA keys.");
       
       if(fp instanceof BlindFingerprint)
	  return sign((BlindFingerprint)fp);
       
       byte[] buf=fp.getBytes();
       if(buf.length>plainBlockSize())
	 throw new KeyException("This key is too short to sign this hash.");
       BigInteger P = new BigInteger(1,buf);
       BigInteger C = P.modPow(r,n);
       return new Signature(fp.getHashFunc(), C.toByteArray());
    }
    
    /**
     * Verify a Signature on a Fingerprint with a public key.<p>

     * The method returns true iff <code>s</code> is a signature for
     * <code>fp</code> created with the mathcing private key.

     * @exception KeyException if this is not a public key
     *
    public boolean verify(Signature s, Fingerprint fp) throws KeyException{
       if(pri)
	 throw new KeyException("Signatures can only be verified with public RSA keys.");
       byte[] buf=s.getBytes();
       
       // Decrypt
       BigInteger C=new BigInteger(1,buf);
       BigInteger P=C.modPow(r,n);
       byte[]plain = P.toByteArray();
       
       // Check for equality (of the appropriate sub-string)
       byte[] fpb = fp.getBytes();
       if(plain.length<fpb.length)
	 return false;
       return equalSub(plain,plain.length-fpb.length, fpb,0, fpb.length);
    }
   */
   
  /**
   * Create a signature for a Fingerprint with a private key.
   * 
   * If fp is a BlindFingerprint, then a BlindSignature will be returned,
   * so in this case the return value can be safely typecast to
   * BlindSignature.
   * 
   * @exception KeyException if the key modulus is shorter than the signature.
   * @exception KeyException if this is not a private key
   */
   public Signature sign(Fingerprint fp) throws KeyException {
      if(!pri)
	throw new KeyException("Signatures can only be generated with private RSA keys.");
      
      if(fp instanceof BlindFingerprint)
	return sign((BlindFingerprint)fp);
      byte[] buf=fp.getBytes();
      byte[] bigBuf=new byte[plainBlockSize()];
      byte[] cipher=new byte[cipherBlockSize()];
      if(bigBuf.length<buf.length)
	throw new KeyException("This key is to short to sign this fingerprint.");
      System.arraycopy(buf,0, bigBuf,bigBuf.length-buf.length, buf.length);
      
      // Pad with random bytes
      int i=bigBuf.length-buf.length-1;
      int k=i%8;
      i=(i/8)*8;
      writeBytes(random.nextLong(), bigBuf, i, k);
      for(i=i-8; i>=0; i-=8)
	writeBytes(random.nextLong(), bigBuf, i, 8);
      
      // Encrypt
      encrypt(bigBuf,0, cipher,0);
      return new Signature(fp.getHashFunc(), cipher);
   }
    
    /**
     * Verify a Signature on a Fingerprint with a public key.
     * <p>
     * The method returns true iff <code>s</code> is a signature for
     * <code>fp</code> created with the mathcing private key.
     *
     * @exception KeyException if this is not a public key
     */
    public boolean verify(Signature s, Fingerprint fp) throws KeyException{
        if(pri)
            throw new KeyException("Signatures can only be verified with public RSA keys.");
        
        byte[] buf=s.getBytes();
        byte[] bigBuf=new byte[cipherBlockSize()];
        byte[] plain=new byte[plainBlockSize()];

        // Decrypt
        System.arraycopy(buf,0, bigBuf,bigBuf.length-buf.length, buf.length);
        decrypt(bigBuf,0,plain,0);
        
        // Check for equality (of the appropriate sub-string)
        byte[] fpb = fp.getBytes();
        return equalSub(plain,plain.length-fpb.length, fpb,0, fpb.length);
    }


    ///////////////////////////////////////////////////////////////////////
    // BLIND SIGNATURE CODE

   /**
    * Create a new blinding factor suitable for blinding a fingerprint
    * before being signed with the private key in the pair.
    */
   public BlindingFactor createBlindingFactor(){
      int length = n.bitLength();
      BigInteger factor=new BigInteger(length, random);
      while(factor.compareTo(n)>=0)
	factor=new BigInteger(length, random);
      return new RSABlindingFactor(factor);
   }

   /**
    * Blind a fingerprint with a public key and the given blinding factor
    * in preparation for blindly signing the fingerprint with the private
    * key.
    
    * @exception KeyException if you try to blind with a private key
    * @exception KeyException if the BlindingFactor is not an RSABlindingFactor
    */
   public BlindFingerprint blind(Fingerprint fp, BlindingFactor bf) throws KeyException {
      if(pri)
	throw new KeyException("You can only blind fingerprints with the public key.");
      if(! (bf instanceof RSABlindingFactor))
	throw new KeyException("The blinding factor is not for RSA keys.");
      RSABlindingFactor rbf = (RSABlindingFactor)bf;

      // copy bytes from fp to bigbuf
      byte[] buf=fp.getBytes();
      byte[] bigBuf=new byte[plainBlockSize()];
      if(bigBuf.length<buf.length)
	throw new KeyException("This key is to short to sign this hash.");
      System.arraycopy(buf,0, bigBuf,bigBuf.length-buf.length, buf.length);

      // Pad with random bytes
      int i=bigBuf.length-buf.length-1;
      int k=i%8;
      i=(i/8)*8;
      writeBytes(random.nextLong(), bigBuf, i, k);
      for(i=i-8; i>=0; i-=8)
	writeBytes(random.nextLong(), bigBuf, i, 8);
      BigInteger f=new BigInteger(1,bigBuf);
      
      f=f.multiply(rbf.getFactor().modPow(r,n)).mod(n);
      
      return new BlindFingerprint(fp.getHashFunc(),
				  "RSA",
				  trimLeadingZeroes(f.toByteArray()));
   }
   
   /**
    * Create a signature for a blinded fingerprint with a private key.
    
    * @exception KeyException if there are problems, depending on the implementing class.
    */
   public BlindSignature sign(BlindFingerprint fp) throws KeyException {
      if(!pri)
	throw new KeyException("Signatures can only be generated with private RSA keys.");
      BigInteger s = new BigInteger(1,fp.getBytes()).modPow(r,n);
      return new BlindSignature(fp.getHashFunc(), 
				fp.getBlindFunc(), 
				trimLeadingZeroes(s.toByteArray()));
   }

   /**
    * Unblind a blind signature using the same blinding factor that was
    * used to blind the original fingerprint.
   
    * @exception KeyException if there are problems, depending on the implementing class.
    */
   public Signature unBlind(BlindSignature bs, BlindingFactor bf) throws KeyException {
      if(! (bf instanceof RSABlindingFactor))
	throw new KeyException("The blinding factor is not for RSA keys.");
      RSABlindingFactor rbf = (RSABlindingFactor)bf;
      BigInteger s = new BigInteger(1,bs.getBytes());
      s=s.multiply(rbf.getFactor().modInverse(n)).mod(n);
      return new Signature(bs.getHashFunc(),
			   trimLeadingZeroes(s.toByteArray()));
   }
   
   
}
