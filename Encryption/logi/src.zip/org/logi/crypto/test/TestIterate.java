// Copyright (C) 1998-2000 Logi Ragnarsson

package org.logi.crypto.test;
import org.logi.crypto.*;

import java.io.*;

/**
 * This application runs all the different tests.
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class TestIterate extends Crypto{

   private TestIterate(){}
   
   private static char[] metricPrefix= { 'a', 'p', 'n', 'm', ' ', 'K', 'M', 'G', 'T' };
   private static int prefixNeutral = 4;
   private static int prefixMax     = metricPrefix.length-prefixNeutral-1;
   
   public static String metricString(double x, int base){
      if (x==0)
	return "0";
      int unit = 0;
      while(x>10*base && unit<prefixMax){
	 x/= base;
	 unit+=1;
      }
      while(x<base/10 && unit>-prefixNeutral){
	 x*=base;
	 unit-=1;
      }
      String r = String.valueOf((int)(x+0.5))+" ";
      if (unit==0)
	return r;
      if (-prefixNeutral<unit && unit < prefixMax)
	return r+metricPrefix[unit+prefixNeutral];
      return r+"e"+(3*unit)+" ";
   }
   
   static String[] keyTypes = { 
      "Caesar", "DES", "TriDES",
      "Blowfish", "RSA", "DH"
   };

   static String[] modes = { "ECB", "CBC", "CFB", "OFB" };

   private static void help(){
      System.err.println("Iterate the tests in TestKey and TestMode over");
      System.err.println("all possible key and mode combinations.");
      System.err.println();
      System.err.println("Use: java org.logi.crypto.test.TestIterate <parameter>*");
      System.err.println("  <parameter> ::= -v|-q|-r n|+K|-K|+M|-M");
      System.err.println();
      System.err.println("Where:");
      System.err.println("  -v     changes to verbose mode.");
      System.err.println("  -q     changes to quiet mode.");
      System.err.println("  -r n   specifies to run n iterations.");
      System.err.println("  +K -K  enable/disable calls to TestKey.");
      System.err.println("  +M -M  enable/disable calls to TestMode.");
      System.err.println();
      System.err.println("By default all tests are enabled and iterated once.");
      System.exit(0);
   }
   
   public static void main(String[] arg) throws Exception {
      Crypto.initRandom();
      PrintWriter summary = new PrintWriter(System.out, true);
      PrintWriter details=null;
      
      int repeat=1;
      boolean testKey=true;
      boolean testMode=true;
      
      for(int i=0; i<arg.length; i++) {
	 if(arg[i].equals("-v")) {
	    details=summary;
	 } else if (arg[i].equals("-q")) {
	    details=null;
	 } else if (arg[i].equals("+K")) {
	    testKey=true;
	 } else if (arg[i].equals("-K")) {
	    testKey=false;
	 } else if (arg[i].equals("+M")) {
	    testMode=true;
	 } else if (arg[i].equals("-M")) {
	    testMode=false;
	 } else if (arg[i].equals("-r")) {
	    if(i+1 == arg.length) {
	       System.err.println("Missing value following -r");
	       help();
	    }
	    try {
	       repeat = Integer.parseInt(arg[++i]);
	    } catch (Exception e) {
	       help();
	    }
	 } else {
	    help();
	 }
      }
      
      boolean ok = true;
      
      for(int r=0; r<repeat; r++) {

	 System.out.println();
	 System.out.println("=====================================================");
	 System.out.print("== STARTING ROUND "+(r+1)+"/"+repeat+" OF TESTING, ");
	 if(ok) System.out.print("NO ");
	 System.out.println("ERRORS FOUND");
	 System.out.println("=====================================================");
	 System.out.println();
	 
	 if(testKey) {
	    for(int i=0; i<keyTypes.length; i++) {
	       ok &= TestKey.test(keyTypes[i],  details,summary);
	    }
	 }
	 
	 if(testMode) {
	    for(int i=0; i<keyTypes.length; i++) {
	       for(int j=0; j<modes.length; j++) {
		  ok &= TestMode.test(keyTypes[i], modes[j], details, summary);
	       }
	    }
	 }
      }

      if(ok) {
	 summary.println();
	 summary.println("All tests passed");
      } else {
	 summary.println();
	 summary.println("Some tests failed\07\07\07");
      }

      System.exit(ok ? 0 : 1);
      
   }
    
}
