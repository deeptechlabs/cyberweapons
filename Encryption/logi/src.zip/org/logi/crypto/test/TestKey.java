// Copyright (C) 1998-2000 Logi Ragnarsson

package org.logi.crypto.test;
import org.logi.crypto.*;
import org.logi.crypto.hash.*;
import org.logi.crypto.sign.*;
import org.logi.crypto.keys.*;

import java.util.Random;
import java.io.*;

/**
 * This application tests the various Key classes.
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 *
 * @see org.logi.crypto.keys.Key
 */
public class TestKey extends Crypto{

    private TestKey(){}
    
    // Insecure but fast pseud-random number generator
    private static Random rand=new Random();  
    
    private static void help(PrintWriter writer){
        writer.println("Use: java org.logi.crypto.test.TestKey <Caesar|DES|TriDES|Blowfish|RSA|DH>>");
    }
    
    public static KeyPair createKeys(String keyType, PrintWriter details, PrintWriter summary){
        long start=System.currentTimeMillis();
        KeyPair kp=null;
        details.println();
        summary.println("KEY GENERATION");
        
        if(keyType.equals("DES")){
            Key k = new DESKey();
            kp = new KeyPair(k,k);
        } else if(keyType.equals("TriDES")){
            Key k = new TriDESKey();
            kp = new KeyPair(k,k);
        } else if(keyType.equals("Blowfish")){
            Key k = new BlowfishKey();
            kp = new KeyPair(k,k);
        } else if(keyType.equals("RSA")){
            // This is just a test, so 256 bits is enough.
            kp = RSAKey.createKeys(256);
        } else if(keyType.equals("DH")){
            // This is just a test, so 256 bits is enough.
            DHKey k = new DHKey(256);
            kp = new KeyPair(k.getPublic(),k);
        } else if(keyType.equals("Caesar")){
            Key k = new CaesarKey();
            kp = new KeyPair(k,k);
        } else {
            help(summary);
            return null;
        }
        long stop=System.currentTimeMillis();

        printKeys(kp.getPublic(),kp.getPrivate(),details);
        details.println();
        details.println("Time="+TestIterate.metricString(0.001*(stop-start),1000)+"s");
        
        return kp;
    }
    
    private static void printKeys(Key pub, Key pri, PrintWriter writer){
        if(pri instanceof SymmetricKey){
            writer.print(pub);
        } else {
            writer.print(pub);
            writer.print(pri);
        }
        
    }

    private static boolean testCDS(Key pub, Key pri, PrintWriter details, PrintWriter summary){
        details.println();
        summary.println("TESTING CONVERSION TO AND FROM STRINGS");
        boolean ok;
        try{
            String cds=pub.toString();
            Key k = (Key)fromString(cds);
            details.println(k);
            ok = pub.equals(k);
            if(!(pri instanceof SymmetricKey)){
                cds=pri.toString();
                k = (Key)fromString(cds);
                details.println(k);
                ok = ok && pri.equals(k);
            }
        } catch (Throwable e){
            summary.println(e);
            e.printStackTrace(summary);
            ok = false;
        }
        if(!ok) {
	    summary.println("Failed!\07");
	}
        return ok;
    }

    private static boolean testCrypt(CipherKey pub, CipherKey pri, PrintWriter details, PrintWriter summary){
        details.println();
        summary.println("TESTING ENCRYPTION/DECRYPTION");
        boolean ok=true;
        try{
            int pbs = pub.plainBlockSize();
            int cbs = pub.cipherBlockSize();
            
            int size = pub.equals(pri) ? 256*1024 : 8*1024;
            int numBlock = (size+pbs/2)/pbs;
            size = numBlock*pbs;
            
            byte[] plain  = new byte[size];
            byte[] cipher = new byte[numBlock*cbs];
            byte[] plain2 = new byte[size];
            
            java.util.Random rand = new java.util.Random();
            rand.nextBytes(plain);
            rand.nextBytes(cipher);
            
            details.println("Plain/cipher block sizes = "
			    +pub.plainBlockSize()+" B, "
			    +pub.cipherBlockSize()+" B");
            details.println("Buffer size = "+TestIterate.metricString(size,1024)+"B");
	   
            Thread.sleep(1000); // To give the system time to settle down...
            details.print("Encrypting:");
            long start=System.currentTimeMillis();
            for (int i=0; i<numBlock; i++)
                pub.encrypt(plain,i*pbs, cipher,i*cbs);
            long stop=System.currentTimeMillis();
            details.println("\ttime="+TestIterate.metricString(0.001*(stop-start),1000)+
                               "s\t throughput="+TestIterate.metricString(1000.0*size/(stop-start),1024)+"B/s"
                              );
            
            start=System.currentTimeMillis();
            details.print("Decrypting:");
            for (int i=0; i<numBlock; i++)
                pri.decrypt(cipher,i*cbs, plain2,i*pbs);
            stop = System.currentTimeMillis();
            details.println("\ttime="+TestIterate.metricString(0.001*(stop-start),1000)+
			    "s\t throughput="+TestIterate.metricString(1000.0*size/(stop-start),1024)+"B/s"
			    );
            
            details.print("Checking...");
            for(int i=0; i<size; i++)
                if(plain[i] != plain2[i]){
                    summary.println("Error at offset "+i);
                    ok=false;
                    break;
                }
            details.println();
            
        } catch (Throwable e){
            details.println(e);
            e.printStackTrace(details);
            ok = false;
        }
        if(!ok) {
	    summary.println("Failed!\07");
	}
        return ok;
    }

    private static boolean testVector(String algorithm, PrintWriter details, PrintWriter summary){
        details.println();
        summary.println("TESTING AGAINST TEST-VECTORS");
        boolean ok=true;
        Reader in;
        try {
            in = new FileReader("vectors."+algorithm);
        } catch (IOException e) {
            summary.println("Unable to read vectors."+algorithm+" from the current directory.");
            details.println("You may need to run the test program from the test directory.");
	    details.println("Test skipped.");
            return true;
        }
        try {
            StreamTokenizer tok = new StreamTokenizer(in);
            tok.ordinaryChars('0','9');
            tok.wordChars('0','9');
            while(tok.nextToken()==StreamTokenizer.TT_WORD){
                byte[] keyBytes = fromHexString(tok.sval);
                tok.nextToken();
                byte[] plain = fromHexString(tok.sval);
                tok.nextToken();
                byte[] cipher = fromHexString(tok.sval);
                CipherKey key = Crypto.makeSessionKey(algorithm+"Key",keyBytes);
                byte[] cipher2 = new byte[cipher.length];
                key.encrypt(plain,0, cipher2,0);
	        byte[] plain2 = new byte[plain.length];
                key.decrypt(cipher,0, plain2,0);
                if(!equal(cipher,cipher2) || !equal(plain,plain2)){
                    details.print("Failed: ");
		    ok=false;
                } else {
                    details.print("Passed: ");
                }
                details.println(key+"  "+hexString(plain)+"  "+hexString(cipher));
            }
        } catch (IOException e){
            e.printStackTrace(summary);
            return false;
        } catch (InvalidCDSException e){
            e.printStackTrace(summary);
            return false;
        }
        if(!ok) {
	    summary.println("Failed!\07");
	}
        return ok;
    }
    
    private static boolean testSign(SignatureKey pub, SignatureKey pri, PrintWriter details, PrintWriter summary){
        details.println();
        summary.println("TESTING SIGNATURES");
        boolean ok;
        try {
            byte[] buffer = new byte[1024];
            rand.nextBytes(buffer);
            Fingerprint fp=Fingerprint.create(buffer,"SHA1");
            details.println("Good signature:");
            Signature s1=pri.sign(fp);
            details.println(s1);
            boolean m1 = pub.verify(s1,fp);
            details.println("Signature verified: "+(m1?"Yes":"No"));

            details.println("Bogus signature:");
            byte[] bogus = s1.getBytes();
            bogus[3]^=5;
            Signature s2=new Signature(bogus, "SHA1", pub.getFingerprint());
            details.println(s2);
            boolean m2=pub.verify(s2,fp);
            details.println("Signature verified: "+(m2?"Yes":"No"));

            ok = m1 && !m2 ;
        } catch (Throwable e){
            details.println(e);
            e.printStackTrace(summary);
            ok = false;
        }
        if(!ok) {
	    summary.println("Failed!\07");
	}
        return ok;
    }
    
    public static boolean test(String keyType, PrintWriter details, PrintWriter summary) {
        if(details==null)
	    details=new PrintWriter(new BitBucket());

        summary.println("============================================================");
        summary.println("TESTING LOW LEVEL FUNCTIONS OF KEYS OF TYPE "+keyType);
       
        KeyPair kp = createKeys(keyType, details, summary);
        if (kp==null)
            return false;
        
        Key pub = kp.getPublic();
        Key pri = kp.getPrivate();
        
        boolean ok=true;
        
        ok &= testCDS(pub,pri,details,summary);
        
        if(pub instanceof CipherKey){
            ok &= testCrypt((CipherKey)pub,(CipherKey)pri,details,summary);
            ok &= testVector(pub.getAlgorithm(),details,summary);
        }
        
        if(pub instanceof SignatureKey)
            ok &= testSign((SignatureKey)pub,(SignatureKey)pri,details,summary);

        details.flush();
        summary.flush();
       
        return ok;
    }
   
    public static void main(String[] arg) throws Exception {
        Crypto.initRandom();
        PrintWriter w = new PrintWriter(System.out, true);
        if(arg.length==0){
            help(w);
            return;
        }
       
        boolean ok = test(arg[0], w,w);
        System.out.println();
        if(ok)
            System.out.println("All tests passed");
        else
            System.out.println("Some tests failed");
    }
    
}
