// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.modes;
import org.logi.crypto.*;
import org.logi.crypto.keys.*;

import java.util.Random;

/**
 * DecryptMode objects are used to decrypt ciphertext generated with
 * a correpsonding EncryptMode object. They must in most cases be
 * initialized with the appropriate key.
 *
 * @see org.logi.crypto.modes.EncryptMode
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 *         (<a href="mailto:logir@logi.org">logir@logi.org</a>) */
public abstract class DecryptMode extends Crypto {

  /**
   * Return the key used for decryption.
   */
  public abstract CipherKey getKey();
  
  /**
   * Set the key to use for decryption. The key can only be set once in
   * this version of the library. The 1.1.x and eventually 1.2.x series
   * allows dynamic re-keying. */
  public abstract void setKey(CipherKey key);

  /**
   * Return the size of the blocks of plaintext output by this object.
   */
  public abstract int plainBlockSize();
  
  /**
   * Send bytes to the DecryptMode for decryption.
   * <p>
   * Decrypt <code>length</code> bytes from <code>source</code>,
   * starting at <code>i</code> and return the plaintext. Data may
   * be encrypted in blocks in which case only whole blocks of
   * plaintext are written to <code>dest</code>. Any remaining data
   * will be stored and prepended to <code>source</code> in the next
   * call to <code>decrypt</code>.
   */
  public abstract byte[] decrypt(byte[] source, int i, int length);
  
  /**
   * Close files and kill threads owned by the object. This should
   * be called to make sure all resources are freed.
   */
  public void close(){
  }

  /**
   * This finalizer calls close(). Note, however, that java offers
   * <b>no guarantee</b> that the finalizer is ever called.
   */
  public void finalize(){
    close();
  }
  
}
