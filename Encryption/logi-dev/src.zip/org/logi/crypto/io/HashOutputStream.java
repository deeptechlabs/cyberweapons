// Copyright (C) 1999-2000 Logi Ragnarsson

package org.logi.crypto.io;
import org.logi.crypto.*;
import org.logi.crypto.keys.*;
import org.logi.crypto.sign.*;

import java.io.*;

/**
 * This OutputStream hashes everything written to it and then passes
 * it to an underlying OutputStream. The hash can be retrieved by
 * calling getFingerprint().
 *
 * @see org.logi.crypto.io.HashInputStream
 * @version 1.0.6
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>) */
public class HashOutputStream extends FilterOutputStream{

  private HashState hashState;
  private byte[] oneByte = new byte[1];

  /**
   * Creates a new HashOutputStream around
   * <code>out</code>. <code>hashState</code> will be used to
   * calculate fingerprints.
   */
  public HashOutputStream(OutputStream out, HashState hashState) {
    super(out);
    this.hashState = hashState;
  }

  /**
   * Creates a new HashOutputStream around <code>out</code>. A new
   * SHA1State object will be used to calculate fingerprints.
   *
   * @see org.logi.crypto.sign.SHA1State
   */
  public HashOutputStream(OutputStream out) {
      this(out, new SHA1State());
  }

  /**
   * Return a fingerprint of all data written so far.
   */
  public synchronized Fingerprint getFingerprint(){
    return hashState.calculate();
  }

  /** Writes the specified byte to this output stream. */
  public synchronized void write(int b) throws IOException{
      oneByte[0] = (byte)b;
      hashState.update(oneByte,0,1);
      out.write(b);
  }

  /**
   * Writes <code>len</code> bytes from the specified byte array starting
   * at offset <code>off</code> to this output stream.
   *
   * @exception IOException if there is a problem iwth the underlying stream
   * or the key fails to sign the fingerprint. */
  public synchronized void write(byte[] buf, int off, int len) throws IOException{
      hashState.update(buf, off, len);
      out.write(buf,off,len);
  }

  /**
   * Flushes this output stream and forces any buffered output bytes to
   * be written out to the stream.
   */
  public synchronized void flush() throws IOException{
    out.flush();
  }

  /**
   * Closes this output stream and releases any system resources associated
   * with this stream.
   *
   * @exception IOException if there is a problem with the underlying stream
   * or the key fails to sign the fingerprint.
   */
  public synchronized void close() throws IOException{
    out.close();
  }

}
