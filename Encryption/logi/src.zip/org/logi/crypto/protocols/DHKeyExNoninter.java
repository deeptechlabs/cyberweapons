// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.protocols;
import org.logi.crypto.*;
import org.logi.crypto.keys.*;

import java.math.BigInteger;

/**
 * Diffie-Hellman key exchange without exchanging keys. Both parties
 * need to know the other party's public DHKey. No messages are
 * sent in either direction, but a unique session key is created for each
 * pair of Diffie-Hellman keys used.
 * <p>
 * This class is both the client and server for the protocol.
 *
 * @see org.logi.crypto.protocols.DHKeyExServer
 * @see org.logi.crypto.protocols.DHKeyExClient
 * @see org.logi.crypto.keys.DHKey
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class DHKeyExNoninter extends DHKeyEx implements NoninterKeyExClient, NoninterKeyExServer {
    
    /**
     * Create a new  DHKeyExClient object which uses
     * the private DH key from <code>pri</code> and the public
     * DH key from <code>pri</code> to generate a session key.
     *
     * @exception KeyException if the public/private flag of either key
     *            is wrong.
     * @exception InvalidCDSException if the session key object can not
     *            be created.
     */
    public DHKeyExNoninter(DHKey pri, DHKey pub, String keyType) throws KeyException, InvalidCDSException {
        super(pri,keyType);
        byte[] k=pub.getKey().modPow(pri.getKey(),m).toByteArray();
        sessionKey=makeSessionKey(keyType,k);
        keyDecided=true;
    }
    
    /**
     * Expects and sends null, since no messages are needed for this protocol.
     *
     * @exception CryptoProtocolException if called with a parameter other than null.
     */
    public byte[] message(byte[] received) throws CryptoProtocolException {
        if (received!=null)
            throw new CryptoProtocolException("No messages should be sent or received.");
        return null;
    }
    
}