// Copyright (C) 1998-2000 Logi Ragnarsson

package org.logi.crypto.keys;
import org.logi.crypto.*;
import org.logi.crypto.sign.*;

/**
 * This interface is implemented by keys that can be used to
 * create and validate signatures on fingerprints of data.
 * 
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>) */
public interface SignatureKey extends Key {
    
    /**
     * Returns the maximum size in bytes of the fingerprints
     * that can be signed. */
    public int signBlockSize();
    
    /**
     * Returns the length of a signature in bytes. */
    public int signatureSize();
    
    /**
     * Create a signature for a fingerprint with a private key.
     *
     * @exception KeyException if there are problems, depending on the implementing class.
     */
    public Signature sign(Fingerprint fp) throws KeyException ;
    
    /**
     * Verify a Signature on a Fingerprint.
     * <p>
     * In the case of an asymmetric algorithm, this method can only be called
     * on the public key in a pair and verifies signatures generated with the
     * private key in the pair.
     * <p>
     * In the case of a symmetric algorithm, this method verifies signatures
     * generated with the same key.
     *
     * @exception KeyException if this is a private key for an asymmetric algorithm
     */
    public boolean verify(Signature s, Fingerprint fp) throws KeyException;
    
}
