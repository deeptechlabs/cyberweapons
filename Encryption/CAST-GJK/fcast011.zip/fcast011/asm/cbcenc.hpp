//
// cbcenc.hpp
//
// Copyright (C) 1997 by Leonard Janke (janke@unixg.ubc.ca)

#ifndef _CBCENC_HPP 
#define _CBCENC_HPP

#include "cast128e.hpp"

class CAST128CBCEncryptAsmGenerator : public CAST128EncryptAsmGenerator
{
private:
  static const char* loopBeginLabel;

  int counterLocation;
  int inLocation;
  int outLocation;
  int ivLocation;

  int localVarsSize;
 
  void LoopBegin();
  void LoopEnd();
public:
  CAST128CBCEncryptAsmGenerator(ostream& os);

  void Startup();
  void Body();
  void Cleanup();
};

#endif
