// Copyright (C) 2000 Logi Ragnarsson

package org.logi.crypto.demo;
import org.logi.crypto.*;
import org.logi.crypto.keys.*;
import org.logi.crypto.modes.*;

/**
 * Decrypt standard input with the key given on the command-line and write
 * to standard output. The key is given as a CDS.
 * 
 * @see org.logi.crypto.demo.encrypt
 */
public class decrypt {
   
   public static void help(Object msg) {
      System.err.println(msg);
      System.err.println();
      System.err.println("Use: java org.logi.crypto.decrypt <key> [mode]");
      System.err.println();
      System.err.println("<key> is a CDS for a CipherKey object and mode");
      System.err.println("may be one of ECB, CBC, OFB or CFB. Default is CFB.");
      System.err.println();
      System.err.println("Note that ECB and CBC modes have block sizes greater than");
      System.err.println("one byte and garbage may be appended to the plaintext before");
      System.err.println("encrypting. Use OFB to avoid this.");
      System.err.println();
      System.err.println("Standard input will be read, decrypted with the key");
      System.err.println("in the cosen mode and written to standard output.");
      System.err.println();
      System.err.println("Try something like BlowfishKey(123454321) for the key.");
      System.exit(1);
   }
   
   public static void main(String[] arg) {  
      Crypto.initRandom();
      
      try {
	 if(arg.length<1 || arg.length>2)
	   help("No key given on command line");

	 // key is parsed from the stnig in arg[0] and cast to CipherKey.
	 // Either the cast or the parsing may fail.
	 CipherKey key = (CipherKey)Crypto.fromString(arg[0]);
	 
	 String mode = "CBC";
	 if(arg.length==2)
	   mode=arg[1];

	 // Depending on the value of mode we create a DecryptSession
	 // object to decrypt data with the key.
	 DecryptSession decryptSession=null;
	 if(mode.equals("ECB"))
	   decryptSession = new DecryptECB(key);
	 else if(mode.equals("CBC"))
	   decryptSession = new DecryptCBC(key);
	 else if(mode.equals("OFB"))
	   decryptSession = new DecryptOFB(key,256);
	 else if(mode.equals("CFB"))
	   decryptSession = new DecryptCFB(key);
	 else
	   help("Unknown mode");

	 // Read plaintext from System.in until it runs out, decrypt it
	 // with the decrypt session (and thereby the key) and write to the
	 // output stream.
	 byte[]	ciphertext = new byte[1024];
	 int n=System.in.read(ciphertext);
	 while(n>0) {
	    byte[] plaintext = decryptSession.decrypt(ciphertext,0,n);
	    System.out.write(plaintext);
	    n=System.in.read(ciphertext);
	 }
	 
      } catch (Exception e) {
	 help(e);
      }
   }
   
}
