// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.protocols;

import org.logi.crypto.keys.Key;

/**
 * This interface is implemented by classes for the server portion of an
 * interactive key-exchange protocol.
 *
 * @see org.logi.crypto.protocols.InterKeyExClient
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public interface InterKeyExServer extends InterProtocolServer {
  
    /**
     * Returns the key if it has been decided upon,
     * or <code>null</code> otherwise.
     */
    public Key sessionKey();
    
}
