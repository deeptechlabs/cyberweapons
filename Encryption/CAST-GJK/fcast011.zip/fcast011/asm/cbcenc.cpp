//
// cbcenc.cpp
//
// CBC encryption mode for CAST
//
// Copyright (C) 1997 by Leonard Janke (janke@unixg.ubc.ca)

#include <stdlib.h>
#include <iostream.h>
#include <iomanip.h>

#include "cbcenc.hpp"

// gnu 2.7.2 dies on an internal bug: *puke*

#if defined(__GNUC__)
#define SHOULD_BE_K ebp  
#else
#define SHOULD_BE_K K  
#endif

const char* CAST128CBCEncryptAsmGenerator::loopBeginLabel="CAST128CBCEncryptLoop";

CAST128CBCEncryptAsmGenerator::CAST128CBCEncryptAsmGenerator(ostream& os)
 : CAST128EncryptAsmGenerator(os)
{
}

void CAST128CBCEncryptAsmGenerator::Body()
{
  Label(loopBeginLabel);
  LoopBegin();
  CAST128EncryptAsmGenerator::Body();
  LoopEnd();
}


void CAST128CBCEncryptAsmGenerator::Startup()
{
  Push(ebp);
  Push(esi);
  Push(edi);
  if ( callingConvention != WATCOMREGISTER )
    Push(ebx);
 
  os <<endl;

  // the stack will be organized as follows:
  //
  // Watcom Register
  //
  // esp+28 iv
  // esp+24 return address
  // esp+20 saved ebp
  // esp+16 saved esi
  // esp+12 saved edi
  // esp+8  out
  // esp+4  in
  // esp+0  counter
  //
  // Microsoft's fastcall
  //
  // esp+40 iv
  // esp+36 key
  // esp+32 (length in)
  // esp+28 return address
  // esp+24 saved ebp
  // esp+20 saved esi
  // esp+16 saved edi
  // esp+12 saved ebx
  // esp+8  out
  // esp+4  in
  // esp+0  counter
  //
  // cdecl
  //
  // esp+40 iv
  // esp+36 key
  // esp+32 (length in) 
  // esp+28 out 
  // esp+24 in
  // esp+20 return address
  // esp+16 saved ebp
  // esp+12 saved esi
  // esp+8  saved edi
  // esp+4  saved ebx
  // esp+0  counter

  switch ( callingConvention )
  {
  // when adding new calling conventions be sure that
  // ebx counts the initial byte count
  // eax contains in and
  // edx contains out
  case WATCOMREGISTER:
    Mov(SHOULD_BE_K,ecx);

    counterLocation=0;
    inLocation=4;
    outLocation=8;
    ivLocation=28;
    localVarsSize=12;

    // Mov(eax,eax);
    // Mov(edx,edx);
    // Mov(ebx,ebx);

    Sub(esp,localVarsSize);

    Mov(esp,inLocation,eax);
    Mov(esp,outLocation,edx);

    break;
  case FASTCALL: 
    Mov(SHOULD_BE_K,esp,8+16);

    counterLocation=0;
    inLocation=4;
    outLocation=8;
    ivLocation=40;
    localVarsSize=12;

    Mov(eax,ecx);
    // Mov(edx,edx);
    Mov(ebx,esp,4+16);

    Sub(esp,localVarsSize);

    Mov(esp,inLocation,ecx);
    Mov(esp,outLocation,edx);

    break;
  case CDECL:
    Mov(SHOULD_BE_K,esp,16+16);

    counterLocation=0;
    inLocation=24;
    outLocation=28;
    ivLocation=40;
    localVarsSize=4;

    Mov(eax,esp,4+16);
    Mov(edx,esp,8+16);
    Mov(ebx,esp,12+16);

    Sub(esp,localVarsSize);

    break;
  default:
    cerr <<"Unrecognized calling convention"<<endl;
    exit(-1);
  }

  
  Lea(eax,eax,1,ebx,0);
  Lea(edx,edx,1,ebx,0);
  Shr(ebx,3);
  Mov(ecx,esp,ivLocation);
  Mov(esp,inLocation,eax);
  Neg(ebx);
  Mov(esp,outLocation,edx);
  Mov(esp,counterLocation,ebx);

  Mov(*dst,ecx,0);
  Mov(*src,ecx,4);
  BSwap(*dst);
  BSwap(*src);

  os <<endl;
}

void CAST128CBCEncryptAsmGenerator::LoopBegin()
{
  Mov(ecx,esp,inLocation);
  Mov(ebx,esp,counterLocation);
  Mov(eax,ecx,8,ebx,0);
  Mov(edx,ecx,8,ebx,4);
  BSwap(eax);
  BSwap(edx);
  Xor(*dst,eax);
  Xor(*src,edx);
}

void CAST128CBCEncryptAsmGenerator::LoopEnd()
{
  Mov(ebx,esp,counterLocation);
  Mov(ecx,esp,outLocation);
  Mov(eax,*dst);
  Mov(edx,*src);
  Mov(*dst,edx);
  Mov(*src,eax);
  BSwap(eax);
  BSwap(edx);
  Mov(ecx,8,ebx,0,eax);
  Mov(ecx,8,ebx,4,edx);
  Inc(ebx);
  Mov(esp,counterLocation,ebx);
  Jne(loopBeginLabel,nearJ);
}

void CAST128CBCEncryptAsmGenerator::Cleanup()
{
  Mov(ecx,esp,ivLocation);
  Add(esp,localVarsSize);
  Mov(ecx,0,eax);
  Mov(ecx,4,edx);

  os <<endl;

  if ( callingConvention != WATCOMREGISTER )
    Pop(ebx);
  Pop(edi);
  Pop(esi);
  Pop(ebp);
  os <<endl;
  switch ( callingConvention)
  {
  case WATCOMREGISTER:
    Ret(4);
    break;
  case FASTCALL:
    Ret(12);
    break;
  case CDECL:
    Ret();
    break;
  default:
    cerr <<"Unrecognized calling convention"<<endl;
    exit(-1);
  }
}
