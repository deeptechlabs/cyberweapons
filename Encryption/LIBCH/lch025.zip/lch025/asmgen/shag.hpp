//
// shag.hpp
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#ifndef _SHAG_HPP
#define _SHAG_HPP

#include "asmgen.hpp"

class SHAAsmGenerator : public AsmGenerator
{
private:
  int shaVersion;
public:
  SHAAsmGenerator(ostream& os, const int shaVersion=1);

  void PrintRound1();
  void PrintRound2();
  void PrintRound3();
  void PrintRound4();

  void Startup();
  void Body();
  void Cleanup();
};

#endif
