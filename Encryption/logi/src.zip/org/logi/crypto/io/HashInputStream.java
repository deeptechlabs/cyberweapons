// Copyright (C) 1998 Logi Ragnarsson

package org.logi.crypto.io;
import org.logi.crypto.*;
import org.logi.crypto.keys.*;
import org.logi.crypto.hash.*;
import org.logi.crypto.sign.*;

import java.io.*;

/**
 * This InputStream hashes everything read from an underlying
 * OutputStream and then returns the data. The hash can be retrieved by
 * calling getFingerprint().
 *
 * @see org.logi.crypto.io.HashOutputStream
 * @version 1.0.6
 * 
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>) */
public class HashInputStream extends FilterInputStream{
    
    private HashState hashState;
    private byte[] oneByte = new byte[1];
    
    /**
     * Creates a new HashInputStream around
     * <code>in</code>. <code>hashState</code> will be used to
     * calculate fingerprints.
     */
    public HashInputStream(InputStream in, HashState hashState) {
	super(in);
	this.hashState = hashState;
    }
    
    /**
     * Creates a new HashInputStream around
     * <code>in</code>. A new SHA1State will be used to
     * calculate fingerprints.
     *
     * @see org.logi.crypto.hash.SHA1State
     */
    public HashInputStream(InputStream in) {
	this(in, new SHA1State());
    }
    
    /**
     * Return a fingerprint of all data read so far.
     */
    public synchronized Fingerprint getFingerprint(){
	return hashState.calculate();
    }
    
    /**
     * Reads the next byte of data from this input stream. The value
     * byte is returned as an int in the range 0 to 255. If no byte is
     * available because the end of the stream has been reached, the
     * value -1 is returned. This method blocks until input data is
     * available, the end of the stream is detected, or an exception
     * is thrown.  */
    public synchronized int read() throws IOException{
	int b = in.read();
	if(b>0){
	    oneByte[0] = (byte)b;
	    hashState.update(oneByte,0,1);
	}
	return b;
    }
    
    /**
     * Reads up to len bytes of data from this input stream into an array of
     * bytes. This method blocks until some input is available.
     * <p>
     * The actual number of bytes read is returned or -1 if the end of the
     * stream is reached.
     */
    public synchronized int read(byte b[], int off, int len) throws IOException{
	int i = in.read(b,off,len);
	if(i>0)
	    hashState.update(b,off,i);
	return i;
    }
    
    /**
     * Skips over and discards n bytes of data from the input stream. The
     * skip method may, for a variety of reasons, end up skipping over some
     * smaller number of bytes, possibly 0. The actual number of bytes
     * skipped is returned.
     * <p>
     * The skipped data will <b>NOT</b> be incorporated into the hash.
     */
    public synchronized long skip(long n) throws IOException{
	return in.skip(n);
    }

    /** 
     * Returns the number of bytes that can be read from this input stream
     * without blocking. */
    public int available() throws IOException{
	return in.available();
    }
    
    /** 
     * Returns false. (This could be implemented, but I've never seen it
     * used. Mail me if you want it!) */
    public boolean markSupported(){
        return false;
    }
    
}
