// 
// chnhash.cxx
//
// Abstract base class for chain hash functions
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#include "chnhash.hpp"

ChainHash::ChainHash(const int bitsPerBlock, const int bitsInHash)
  : _bitsPerBlock(bitsPerBlock), _bitsInHash(bitsInHash)
{  
  _bitCount=0; 
}

ChainHash::~ChainHash()
{
}

void ChainHash::Reset()
{
  _bitCount=0;
}
