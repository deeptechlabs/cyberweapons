//
// sha1g.hpp
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#ifndef _SHA1G_HPP
#define _SHA1G_HPP

#include "shag.hpp"

class SHA1AsmGenerator : public SHAAsmGenerator
{
public:
  SHA1AsmGenerator(ostream& os);
};

#endif
