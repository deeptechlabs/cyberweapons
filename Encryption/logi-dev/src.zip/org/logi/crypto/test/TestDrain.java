// Copyright (C) 1999 Logi Ragnarsson

package org.logi.crypto.test;
import org.logi.crypto.*;
import org.logi.crypto.io.*;
import org.logi.crypto.keys.*;
import org.logi.crypto.modes.*;

import java.util.Random;
import java.io.*;
import java.net.*;

/**
 * Tests the DecryptStream.drain() method. One thread writes bytes to an
 * EncryptStream working in a block mode, while another receives the
 * ciphertext, decrypts it and drains in the appropriate places. 
 * <p>
 * 
 * The flush() and drain() methods work correctly iff the program outputs
 * lines of the form <tt>[n] 0 1 2 ... n-1</tt>. The bottleneck will be the
 * random number generator used for padding the blocks and may cause the
 * program to run jerkily while it collects entropy. 
 */
public class TestDrain {

  static Random rand = new Random();

  private static class R extends Thread {

    Socket socket;
    CipherKey key;
    
    public R(Socket socket, CipherKey key) throws IOException {
      this.socket = socket;
      this.key = key;
      start();
    }

    public void run()  {
      try{
	InputStream sin = socket.getInputStream();
	DecryptStream din = new DecryptStream(sin, null, new DecryptCBC(key));
	while(true){
	  int l = din.read();
	  System.out.print("["+l+"] ");
	  for(int i=0; i<l; i++){
	    int j=din.read();
	    System.out.print(j+" ");
	    if(j!=i)
	      throw new Error("Mismatch!");
	  }
	  din.drain();
	  System.out.println();
	}
      } catch (Exception e) {
	e.printStackTrace();
      }
    }

  } 
  
  private static class W extends Thread {

    ServerSocket socket;
    CipherKey key;
    
    public W(ServerSocket socket, CipherKey key) throws IOException {
      this.socket = socket;
      this.key = key;
      start();
    }

    public void run() {
      try{
	OutputStream sout = socket.accept().getOutputStream();
	EncryptStream dout = new EncryptStream(sout, null, new EncryptCBC(key));
	while(true){
	  int l = rand.nextInt()%10+11;
	  dout.write(l);
	  for(int i=0; i<l; i++)
	    dout.write(i);
	  dout.flush();
	}
      } catch (Exception e) {
	e.printStackTrace();
      }
    }

  }
  
  public static void main(String[] arg) throws Exception {
    Crypto.initRandom();
    int port = rand.nextInt()%32768 + 32768;
    CipherKey key = new TriDESKey();
    W w = new W(new ServerSocket(port), key);
    R r = new R(new Socket("localhost", port), key);
  }
  
}




