// Copyright (C) 1998-2000 Logi Ragnarsson

package org.logi.crypto.protocols;
import org.logi.crypto.*;
import org.logi.crypto.keys.*;
import org.logi.crypto.sign.*;

/**
 * Ancestor of SendHashKeyEx classes.
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 * (<a href="mailto:logir@logi.org">logir@logi.org</a>)
 */
public class SendHashKeyEx extends Crypto {
    
    protected boolean keyDecided=false;
    protected Key sessionKey;
    
    /** Create a new SendHashKeyEx with the Key <code>k</code>. */
    protected SendHashKeyEx(Key k){
        sessionKey=k;
    }
    
    /**
     * Returns the key if it has been decided upon,
     * or <code>null</code> otherwise.
     */
    public Key sessionKey(){
        return keyDecided ? sessionKey : null;
    }
    
    /** Returns true iff this end of the protocol i completed. */
    public boolean completed(){
        return keyDecided;
    }

    /**
     * Returns the maximum expected size of a message for this protocol. */
    public int maxMessageSize() {
        return 65536;
    }
   
}
