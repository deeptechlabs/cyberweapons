// Copyright (C) 1998,2000 Logi Ragnarsson

package org.logi.crypto.modes;
import org.logi.crypto.*;
import org.logi.crypto.keys.*;

/**
 * Uninteresting implementation details.
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 *         (<a href="mailto:logir@logi.org">logir@logi.org</a>) 
 */
abstract class DecryptMode extends Crypto implements DecryptSession {

   public void close() {
   }

}
