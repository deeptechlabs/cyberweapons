//
// md4ish.hpp
//
// Abstract base class for chain hash function with the same padding
// algorithm and endianness conventions as MD4
//
// This software was written by Leonard Janke (janke@unixg.ubc.ca)
// in 1996-7 and is entered, by him, into the public domain.

#ifndef _MD4ISH_HPP
#define _MD4ISH_HPP

#include <chnhash/chnhash.hpp>

class MD4ish : public ChainHash
{
protected:
  virtual void ProcessBlock(const u32* block)=0;

  u32* H;
  u32 buf[16];
public:
  MD4ish(const int bitsInHash);
  virtual ~MD4ish();
 
  inline void ProcessMiddleBlock(const void* block, const int aligned=0);
  void ProcessFinalBlock(const void* block, const int bytes);
  
  void ChainVariables(void* buffer) const;
  virtual void Reset();
};     

void MD4ish::ProcessMiddleBlock(const void* block, const int aligned)
{
  if ( aligned )
    ProcessBlock((const u32*) block);
  else
    {
      memcpy(buf,block,64);
      ProcessBlock(buf);
    }
  _bitCount+=512;
}

#endif
