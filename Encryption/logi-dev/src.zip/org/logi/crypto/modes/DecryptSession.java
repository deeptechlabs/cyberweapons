// Copyright (C) 1998,2000 Logi Ragnarsson

package org.logi.crypto.modes;
import org.logi.crypto.*;
import org.logi.crypto.keys.*;

/**
 * DecryptSessions objects are used to decrypt ciphertext generated with a
 * correpsonding EncryptSession object. They must in most cases be
 * initialized with the appropriate key.
 * 
 * @see org.logi.crypto.modes.EncryptSession
 *
 * @author <a href="http://www.logi.org/~logir/">Logi Ragnarsson</a>
 *         (<a href="mailto:logir@logi.org">logir@logi.org</a>) */
public interface DecryptSession {

  /**
   * Return the key used for decryption.
   */
  public CipherKey getKey();
  
  /**
   * Set the key to use for encryption. Do not call this method when
   * there may be data in the internal buffer.
   * 
   * @exception CryptoException if there is data in the internal buffer
   * which should be encrypted with the old key. */
  public void setKey(CipherKey key) throws CryptoException;
  
  /**
   * Return the size of the blocks of plaintext output by this object.
   */
  public int plainBlockSize();

  /**
   * Send bytes to the DecryptMode for decryption.
   * <p>
   * Decrypt <code>length</code> bytes from <code>source</code>,
   * starting at <code>i</code> and return the plaintext. Data may
   * be encrypted in blocks in which case only whole blocks of
   * plaintext are written to <code>dest</code>. Any remaining data
   * will be stored and prepended to <code>source</code> in the next
   * call to <code>decrypt</code>.
   */
  public byte[] decrypt(byte[] source, int i, int length);
  
  /**
   * Close files and kill threads owned by the object. This should
   * be called to make sure all resources are freed.
   */
  public void close();

  
}
